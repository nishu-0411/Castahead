# CastAhead — Statistical Demand Forecasting Platform

> **TicTechToe 2026 · DA-IICT · Team KANTCode · Problem Statement #05**

---

## What Is This?


CastAhead is a full-stack demand forecasting web application for store owners and inventory managers. It combines observed sales, weather, and trend signals into a statistically-grounded hybrid ensemble and surfaces plain-English recommendations — no unnecessary statistical jargon.

Note: the live website UI emphasizes "Statistical Logistics Forecasting" and surface-level signals: "Sales + Weather + Trends." The README below documents the implementation details and reconciles differences between internal architecture and public copy.

---

## Project Structure

```
castahead/
├── backend/                  ← FastAPI Python server
│   ├── main.py               ← App entry point
│   ├── core/engine.py        ← ML ensemble + scenario engine
│   ├── api/routes/           ← All REST endpoints
│   └── requirements.txt
└── frontend/                 ← React + Vite + TailwindCSS
    ├── src/
    │   ├── pages/            ← 5 screens
    │   ├── components/       ← Sidebar, TopBar, Layout
    │   ├── context/          ← Global state
    │   └── utils/api.js      ← Axios API layer
    └── package.json
```

---

## Quick Start (Local)

### Prerequisites
- Python 3.10+
- Node.js 18+

### 1. Backend

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Optional: add GEMINI_API_KEY=your_key to .env
uvicorn main:app --reload --port 8000
```

Backend runs at: http://localhost:8000  
Swagger docs at: http://localhost:8000/docs  
Health check: http://localhost:8000/api/health

### 2. Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Frontend runs at: http://localhost:5173

---

## One-Command Start (from project root)

```bash
# macOS / Linux
chmod +x start.sh && ./start.sh

# Windows
start.bat
```

---

## API Endpoints

| Method | Endpoint | Description | Used By |
|--------|----------|-------------|---------|
| GET | `/api/health` | Server + model status | All pages |
| GET | `/api/skus` | All SKUs with health status | Inventory Dashboard |
| GET | `/api/skus/{id}` | Single SKU with history | Forecast Detail |
| GET | `/api/forecast/{id}` | 12-week ensemble forecast | Forecast Detail |
| GET | `/api/scenarios` | All detected past shock events | Scenario Planner |
| POST | `/api/scenario/simulate` | Run scenario simulation | Scenario Planner |
| POST | `/api/narrate` | Gemini plain-English narration | Forecast Detail |

---

## Environment Variables

### Backend `.env`
```
GEMINI_API_KEY=your_gemini_api_key   # Optional - falls back to template
```

### Frontend `.env`
```
VITE_API_URL=http://localhost:8000   # Backend URL
```

---

## Deployment

### Frontend → Vercel
```bash
cd frontend
npm run build
# Push to GitHub, import repo in vercel.com
# Set VITE_API_URL=https://your-backend.railway.app
```

### Backend → Railway
```bash
# Push entire project to GitHub
# Create new Railway project → Deploy from repo → select /backend
# Set env var: GEMINI_API_KEY=your_key
```

### Backend → Render
```bash
# New Web Service → Connect GitHub repo
# Root directory: backend
# Build command: pip install -r requirements.txt
# Start command: uvicorn main:app --host 0.0.0.0 --port $PORT
```

---

# Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + Vite + TailwindCSS + Recharts |
| Backend | FastAPI + Pydantic v2 + Uvicorn |
| ML Engine | Hybrid ensemble (Prophet, LightGBM, N-BEATS) — implementation uses simulated models when CSV outputs are not available |
| LLM (optional) | Plain-English narration integrates with a configured LLM provider (Gemini-compatible API by default if set) |
| Database | DuckDB (in-process) |
| Charts | Recharts (ComposedChart, AreaChart) |
| Icons | Google Material Symbols |
| Fonts | Space Grotesk · Manrope · JetBrains Mono |

---

## Pages

| Route | Page | Key Feature |
|-------|------|-------------|
| `/` | Landing Page | Marketing, pricing teaser, how it works (site copy uses "Statistical Logistics Forecasting") |
| `/dashboard` | Inventory Dashboard | All SKUs, region tabs, demand trend chart |
| `/forecast` | Forecast Detail | Ensemble forecast chart, recommendation, store breakdown (UI shows ensemble-level metrics) |
| `/scenario` | Scenario Planner | Past shock detection, live simulation (skeleton cards shown during load) |
| `/pricing` | Plans & Pricing | $49 / $199 / Custom, pricing toggle (monthly/yearly) |

### Reconciliation: README vs Website

| Issue | README (internal) | Website (public) | Action taken |
|---|---:|---|---|
| Product branding | Described as statistical/ensemble implementation (internal) | Hero copy: "Statistical Logistics Forecasting" / "Statistical Demand Forecasting" | README updated to match public phrasing while documenting internal ML stack.
| Data sources count | Implementation can consume sales, weather, trends, macro signals | Site shows "Sales + Weather + Trends" (macro omitted for brevity) | README now documents that macroeconomic signals can be used but site intentionally surfaces three primary sources.
| AI/LLM layer | Optional LLM narration integration (Gemini-compatible) | LLM not shown on public pages (privacy/credential reasons) | README clarifies LLM is optional and used only when `GEMINI_API_KEY` (or compatible) is configured.
| Model names | Backend uses Prophet, LightGBM, N-BEATS (ensemble) | Site keeps copy high-level as "ensemble model output" to avoid technical overload | README keeps model names for developer transparency and notes site-level simplification.
| Hero metrics | README previously didn't call out UI metrics | UI shows Confidence, WMAPE, Trend Index | README now documents the UI metrics and what they represent (WMAPE = weighted mean absolute percentage error; Confidence derives from uncertainty/consensus). 
| Page title / scope | README used "Inventory Dashboard" as page title | Site hero uses "Logistics Forecasting" — broader copy for marketing | README acknowledges the public hero copy and aligns route descriptions accordingly.

This README now matches the website's public-facing phrasing while preserving developer-level details about data sources, model names, optional LLM usage, and metrics computation.

---

## Team KANTCode

| Member | Role |
|--------|------|
| Aadi Desai | Frontend |
| Nisarg Trivedi | ML Modelling |
| Tirth Vyas | UI/UX & Documentation |
| Khush Shah | Backend Developer |
