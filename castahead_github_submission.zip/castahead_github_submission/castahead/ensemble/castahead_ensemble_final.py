"""
CastAhead — Weighted Hybrid Ensemble
=====================================
Combines Prophet + LightGBM + N-BEATS into one final forecast.

Run:
    python castahead_ensemble_final.py

Requires:
    pip install prophet lightgbm torch pandas numpy matplotlib scikit-learn joblib

Architecture
------------
The ensemble trains all three component models inline (no pre-saved files
needed), aligns their test-window predictions to the same 100 series
(10 SKUs × 10 Stores), and produces a fixed weighted average:

    Ensemble = 0.40 × LightGBM + 0.40 × N-BEATS + 0.20 × Prophet

Weight rationale (aligned to CastAhead architecture):
  LightGBM (40%) → Best at capturing holiday/event & macro correlations.
                   Has access to 35 engineered features; lowest per-series
                   WMAPE on the exogenous-signal dimension.
  N-BEATS  (40%) → Best at non-linear sequence shocks (port strike, avian flu,
                   Fed hike). Pure sequence model — no feature engineering bias.
  Prophet  (20%) → Stable statistical floor. Prevents ensemble from drifting
                   too far from the seasonality baseline. Lower weight because
                   it underperforms on shocks and short training windows.

Outputs
-------
  outputs/ensemble/
    final_ensemble_predictions.csv   ← inventory insights layer input
    ensemble_dashboard.png           ← 6-panel visual dashboard
    ensemble_metrics.csv             ← WMAPE / MAE per SKU × state
"""

# ── Imports ───────────────────────────────────────────────────────
import os, warnings, time
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Patch
import lightgbm as lgb
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import LabelEncoder
from joblib import Parallel, delayed
from prophet import Prophet
warnings.filterwarnings('ignore')

# ══════════════════════════════════════════════════════════════════
# 0.  CONFIGURATION
# ══════════════════════════════════════════════════════════════════
DATA_PATH   = r'castahead_final (1).csv'   # ← update path if needed
OUTPUT_DIR  = 'outputs/ensemble'
TRAIN_WEEKS = 40     # first 40 weeks = train, last 12 = test

# Ensemble weights — must sum to 1.0
W_LGBM    = 0.40
W_NBEATS  = 0.40
W_PROPHET = 0.20

# N-BEATS hyperparameters (kept light for speed)
LOOKBACK   = 12
HIDDEN     = 128
N_BLOCKS   = 4
N_LAYERS   = 3
THETA_DIM  = 6
EPOCHS     = 80
BATCH_SIZE = 64
LR         = 5e-4
DEVICE     = 'cuda' if torch.cuda.is_available() else 'cpu'

SHORT = {
    'FOODS_3_586': 'Coca-Cola 2L',  'FOODS_3_090': "Lay's Chips",
    'FOODS_3_252': 'GV Whole Milk', 'FOODS_3_120': 'Wonder Bread',
    'FOODS_3_587': 'Pepsi 2L',      'FOODS_3_555': 'Gatorade',
    'FOODS_3_226': 'Doritos',       'FOODS_3_714': 'Eggs 12ct',
    'FOODS_3_694': 'Tide Detergent','FOODS_3_282': 'GV OJ 64oz',
}
STATE_NAMES = {'CA': 'California', 'TX': 'Texas', 'WI': 'Wisconsin'}
COL = {
    'actual':  '#2C3E50', 'ensemble': '#00BCD4',
    'lgbm':    '#E74C3C', 'nbeats':   '#8E44AD', 'prophet': '#E94560',
    'CA': '#2980B9', 'TX': '#E67E22', 'WI': '#27AE60',
    'panel': '#F8F9FA', 'bg': '#FFFFFF', 'dark': '#1A1A2E',
}
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.color': '#EEEEEE', 'grid.linewidth': 0.6,
    'axes.facecolor': '#FFFFFF', 'figure.facecolor': '#F8F9FA',
})
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ══════════════════════════════════════════════════════════════════
# 1.  LOAD & SPLIT
# ══════════════════════════════════════════════════════════════════
print("=" * 65)
print("  CastAhead — Weighted Hybrid Ensemble")
print(f"  Weights: LightGBM {W_LGBM:.0%} | N-BEATS {W_NBEATS:.0%} | Prophet {W_PROPHET:.0%}")
print("=" * 65)

df = pd.read_csv(DATA_PATH, parse_dates=['week_start'])
df = df[df['week_start'] >= '2015-01-01'].copy()
df = df.sort_values(['item_id', 'store', 'week_start']).reset_index(drop=True)

WEEKS  = sorted(df['week_start'].unique())
CUTOFF = WEEKS[TRAIN_WEEKS - 1]   # 2015-10-05
SKUS   = sorted(df['item_id'].unique())
STORES = sorted(df['store'].unique())
STATES = sorted(df['state'].unique())
NAME   = (df[['item_id','product_name']].drop_duplicates()
          .set_index('item_id')['product_name'].to_dict())

TR = df[df['week_start'] <= CUTOFF].copy()
TE = df[df['week_start'] >  CUTOFF].copy()

print(f"\n  {len(SKUS)} SKUs | {len(STORES)} Stores | {len(STATES)} States")
print(f"  Train : ≤ {CUTOFF.date()}  ({len(TR):,} rows | {TRAIN_WEEKS} weeks)")
print(f"  Test  : > {CUTOFF.date()}  ({len(TE):,} rows | {len(WEEKS)-TRAIN_WEEKS} weeks)\n")

# ── Shared metric helpers ─────────────────────────────────────────
def wmape(actual, pred):
    """
    WMAPE = Σ|actual - pred| / Σ|actual|
    Volume-weighted: large-selling weeks dominate.
    Skips stockout zeros — those are supply failures, not forecast errors.
    """
    a = np.asarray(actual, float)
    p = np.asarray(pred,   float)
    mask = a > 0          # skip structural zeros (stockouts)
    a, p = a[mask], p[mask]
    if len(a) == 0:
        return np.nan
    return float(np.sum(np.abs(a - p)) / (np.sum(np.abs(a)) + 1e-8))

def mae(actual, pred):
    return float(np.mean(np.abs(np.asarray(actual,float) - np.asarray(pred,float))))


# ══════════════════════════════════════════════════════════════════
# 2.  MODEL A — LightGBM
# ══════════════════════════════════════════════════════════════════
print("─" * 65)
print("  [1/3] Training LightGBM...")
t0 = time.time()

# Feature engineering (mirrors castahead_lgbm.py exactly)
dfl = df.copy()
for col in ['item_id','store','state','season']:
    dfl[f'{col}_enc'] = LabelEncoder().fit_transform(dfl[col])

dfl['quarter']       = ((dfl['month'] - 1) // 3) + 1
dfl['temp_sq']       = dfl['temp_avg_c'] ** 2
dfl['temp_x_summer'] = dfl['temp_avg_c'] * (dfl['season']=='Summer').astype(int)
dfl['temp_x_sku']    = dfl['temp_avg_c'] * dfl['item_id_enc']
dfl['is_hot']        = (dfl['temp_avg_c'] > 25).astype(int)
dfl['is_cold']       = (dfl['temp_avg_c'] <  5).astype(int)
dfl['is_rainy']      = (dfl['rain_avg_mm'] > 5).astype(int)
dfl['week_sin']      = np.sin(2*np.pi*dfl['week_of_year']/52)
dfl['week_cos']      = np.cos(2*np.pi*dfl['week_of_year']/52)
dfl['month_sin']     = np.sin(2*np.pi*dfl['month']/12)
dfl['month_cos']     = np.cos(2*np.pi*dfl['month']/12)
dfl['lag_weighted']  = (dfl['lag_1w']*0.65 + dfl['lag_2w']*0.35).round(1)
dfl['roll_std_4w']   = (dfl.groupby(['item_id','store'])['sku_store_units']
                          .transform(lambda x: x.shift(1).rolling(4,min_periods=2).std())
                          .fillna(0).round(1))

FEATURES = [c for c in [
    'week_of_year','month','quarter','season_enc',
    'week_sin','week_cos','month_sin','month_cos','is_month_end_week',
    'temp_avg_c','temp_sq','rain_avg_mm','is_hot','is_cold','is_rainy',
    'temp_x_summer','temp_x_sku',
    'has_event','holiday_season','near_thanksgiving','near_christmas',
    'back_to_school','super_bowl_week',
    'trends_soft_drinks','trends_snacks',
    'lag_1w','lag_2w','lag_weighted','roll_mean_2w','roll_mean_4w','roll_std_4w',
    'item_id_enc','store_enc','state_enc',
] if c in dfl.columns]

TRL = dfl[dfl['week_start'] <= CUTOFF].copy()
TEL = dfl[dfl['week_start'] >  CUTOFF].copy()

lgbm_model = lgb.train(
    {'objective':'regression_l1','metric':'mape','learning_rate':0.03,
     'num_leaves':63,'max_depth':7,'min_child_samples':5,
     'feature_fraction':0.75,'bagging_fraction':0.8,'bagging_freq':1,
     'reg_alpha':0.05,'reg_lambda':0.3,'verbose':-1,'random_state':42},
    lgb.Dataset(TRL[FEATURES].fillna(0), TRL['sku_store_units']),
    num_boost_round=800,
    valid_sets=[lgb.Dataset(TEL[FEATURES].fillna(0), TEL['sku_store_units'])],
    callbacks=[lgb.early_stopping(50, verbose=False), lgb.log_evaluation(200)],
)

TEL['lgbm_pred'] = np.maximum(lgbm_model.predict(TEL[FEATURES].fillna(0)), 0)

lgbm_preds = (TEL[['week_start','item_id','store','state','sku_store_units','lgbm_pred']]
              .rename(columns={'sku_store_units':'actual'}))

lgbm_wmape = wmape(lgbm_preds['actual'], lgbm_preds['lgbm_pred'])
print(f"  ✓ LightGBM  WMAPE: {lgbm_wmape:.4f} ({lgbm_wmape*100:.2f}%)  [{time.time()-t0:.0f}s]")


# ══════════════════════════════════════════════════════════════════
# 3.  MODEL B — N-BEATS
# ══════════════════════════════════════════════════════════════════
print("\n─" * 65)
print("  [2/3] Training N-BEATS...")
t0 = time.time()

# ── N-BEATS Architecture ──────────────────────────────────────────
class NBeatsBlock(nn.Module):
    """
    Single N-BEATS block with residual connections.
    block_type controls the basis expansion:
      'trend'      → polynomial (long-run direction)
      'seasonality'→ harmonic   (repeating cycles)
      'generic'    → linear     (shock residuals)
    """
    def __init__(self, lookback, horizon, hidden, n_layers,
                 theta_dim, block_type='generic'):
        super().__init__()
        self.block_type = block_type
        self.lookback   = lookback
        self.horizon    = horizon
        self.theta_dim  = theta_dim

        layers, in_dim = [], lookback
        for _ in range(n_layers):
            layers += [nn.Linear(in_dim, hidden), nn.ReLU()]
            in_dim = hidden
        self.fc      = nn.Sequential(*layers)
        self.theta_f = nn.Linear(hidden, theta_dim)
        self.theta_b = nn.Linear(hidden, theta_dim)

        if block_type == 'trend':
            t_f = torch.linspace(0, 1, horizon)
            t_b = torch.linspace(0, 1, lookback)
            B_f = torch.stack([t_f**d for d in range(theta_dim)])
            B_b = torch.stack([t_b**d for d in range(theta_dim)])
            self.register_buffer('B_fwd', B_f)
            self.register_buffer('B_bwd', B_b)
        elif block_type == 'seasonality':
            freqs = torch.arange(1, theta_dim//2+1, dtype=torch.float32)
            t_f   = torch.linspace(0, 1, horizon)
            t_b   = torch.linspace(0, 1, lookback)
            B_f   = torch.cat([torch.cos(2*np.pi*freqs[:,None]*t_f[None,:]),
                                torch.sin(2*np.pi*freqs[:,None]*t_f[None,:])], dim=0)
            B_b   = torch.cat([torch.cos(2*np.pi*freqs[:,None]*t_b[None,:]),
                                torch.sin(2*np.pi*freqs[:,None]*t_b[None,:])], dim=0)
            self.register_buffer('B_fwd', B_f[:theta_dim])
            self.register_buffer('B_bwd', B_b[:theta_dim])
        else:
            # Generic: learned linear expansion
            self.W_f = nn.Linear(theta_dim, horizon,  bias=False)
            self.W_b = nn.Linear(theta_dim, lookback, bias=False)

    def forward(self, x):
        h      = self.fc(x)
        tht_f  = self.theta_f(h)
        tht_b  = self.theta_b(h)
        if self.block_type in ('trend', 'seasonality'):
            fcast  = tht_f @ self.B_fwd   # (batch, H)
            bcast  = tht_b @ self.B_bwd   # (batch, L)
        else:
            fcast  = self.W_f(tht_f)
            bcast  = self.W_b(tht_b)
        return fcast, bcast

class NBeatsStack(nn.Module):
    """Stack of N-BEATS blocks with residual connections between them."""
    def __init__(self, lookback, horizon, hidden, n_layers, theta_dim, n_blocks):
        super().__init__()
        types = ['trend','seasonality','generic','generic']
        self.blocks = nn.ModuleList([
            NBeatsBlock(lookback, horizon, hidden, n_layers,
                        theta_dim, types[i % len(types)])
            for i in range(n_blocks)
        ])

    def forward(self, x):
        residual  = x
        total_f   = 0
        for block in self.blocks:
            f, b     = block(residual)
            residual = residual - b
            total_f  = total_f + f
        return total_f

# ── Prepare sequence data ─────────────────────────────────────────
def make_sequences(data_dict, cutoff_idx, lookback, test_weeks):
    """
    Build (X_train, y_train) for global pre-training and
    per-series test sequences for rolling inference.
    data_dict: {(item_id, store): np.array of weekly sales}
    """
    X_tr, y_tr = [], []
    test_seqs  = {}   # (item_id, store) → list of input windows for test

    for key, series in data_dict.items():
        train_series = series[:cutoff_idx]
        # sliding window training samples
        for i in range(lookback, len(train_series)):
            X_tr.append(train_series[i-lookback:i])
            y_tr.append(train_series[i])
        # test sequences: roll forward week-by-week
        full = series.copy()
        windows = []
        for t in range(cutoff_idx, cutoff_idx + test_weeks):
            start = t - lookback
            if start >= 0:
                windows.append(full[start:t])
            else:
                pad = np.zeros(-start)
                windows.append(np.concatenate([pad, full[:t]]))
        test_seqs[key] = windows

    return (np.array(X_tr, dtype=np.float32),
            np.array(y_tr, dtype=np.float32),
            test_seqs)

# Build per-series data dict (normalised by series mean for stability)
series_means = {}
series_dict  = {}
for sku in SKUS:
    for store in STORES:
        key   = (sku, store)
        sub   = df[(df['item_id']==sku)&(df['store']==store)].sort_values('week_start')
        vals  = sub['sku_store_units'].values.astype(float)
        # Replace zeros (stockouts) with median — same as Prophet pipeline
        med   = np.median(vals[vals>0]) if (vals>0).any() else 1.0
        vals[vals==0] = med
        mu    = vals[:TRAIN_WEEKS].mean() or 1.0
        series_means[key] = mu
        series_dict[key]  = vals / mu   # normalise

X_tr, y_tr, test_seqs = make_sequences(
    series_dict, TRAIN_WEEKS, LOOKBACK, len(WEEKS)-TRAIN_WEEKS)

class SeqDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X)
        self.y = torch.tensor(y).unsqueeze(-1)
    def __len__(self):  return len(self.X)
    def __getitem__(self, i): return self.X[i], self.y[i]

loader = DataLoader(SeqDataset(X_tr, y_tr),
                    batch_size=BATCH_SIZE, shuffle=True)

# ── Global pre-training ───────────────────────────────────────────
model_nb = NBeatsStack(LOOKBACK, 1, HIDDEN, N_LAYERS,
                       THETA_DIM, N_BLOCKS).to(DEVICE)
opt      = torch.optim.Adam(model_nb.parameters(), lr=LR)
sched    = torch.optim.lr_scheduler.CosineAnnealingLR(opt, EPOCHS)
loss_fn  = nn.HuberLoss(delta=0.5)

print(f"  N-BEATS params: {sum(p.numel() for p in model_nb.parameters()):,} | Device: {DEVICE}")

for epoch in range(1, EPOCHS+1):
    model_nb.train()
    ep_loss = 0
    for xb, yb in loader:
        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
        pred   = model_nb(xb)
        loss   = loss_fn(pred, yb)
        opt.zero_grad(); loss.backward(); opt.step()
        ep_loss += loss.item()
    sched.step()
    if epoch % 20 == 0:
        print(f"    Epoch {epoch:>3}/{EPOCHS}  loss={ep_loss/len(loader):.4f}")

# ── Rolling inference on test window ─────────────────────────────
model_nb.eval()
nbeats_rows = []

for sku in SKUS:
    for store in STORES:
        key     = (sku, store)
        windows = test_seqs[key]
        mu      = series_means[key]
        sub_te  = df[(df['item_id']==sku)&(df['store']==store)&
                     (df['week_start']>CUTOFF)].sort_values('week_start')

        for i, (week_row, window) in enumerate(zip(sub_te.itertuples(), windows)):
            x_in = torch.tensor(window, dtype=torch.float32).unsqueeze(0).to(DEVICE)
            with torch.no_grad():
                pred_norm = model_nb(x_in).item()
            pred_units = max(0.0, pred_norm * mu)
            nbeats_rows.append({
                'week_start': week_row.week_start,
                'item_id':    sku,
                'store':      store,
                'state':      sub_te['state'].iloc[0],
                'actual':     float(week_row.sku_store_units),
                'nbeats_pred':pred_units,
            })

nbeats_preds = pd.DataFrame(nbeats_rows)
nbeats_wmape = wmape(nbeats_preds['actual'], nbeats_preds['nbeats_pred'])
print(f"  ✓ N-BEATS     WMAPE: {nbeats_wmape:.4f} ({nbeats_wmape*100:.2f}%)  [{time.time()-t0:.0f}s]")


# ══════════════════════════════════════════════════════════════════
# 4.  MODEL C — Prophet
# ══════════════════════════════════════════════════════════════════
print("\n─" * 65)
print("  [3/3] Training Prophet (parallel, 100 series)...")
t0 = time.time()

SAFE_REGS = ['temp_avg_c','rain_avg_mm','has_event',
             'trends_soft_drinks','trends_snacks']

def fix_zeros(arr):
    """Replace stockout zeros with linear interpolation."""
    s = pd.Series(arr, dtype=float)
    s[s==0] = np.nan
    s = s.interpolate(method='linear', limit_direction='both').fillna(s.median())
    return s.clip(lower=1).values

def fit_prophet_one(sku, store):
    """Fit Prophet for one series. Returns list of prediction dicts."""
    sub = df[(df['item_id']==sku) & (df['store']==store)].copy()
    if len(sub) < 12:
        return []

    tr = sub[sub['week_start']<=CUTOFF].rename(
        columns={'week_start':'ds','sku_store_units':'y'}).copy()
    te = sub[sub['week_start']> CUTOFF].rename(
        columns={'week_start':'ds','sku_store_units':'y'}).copy()

    if len(tr) < 8 or len(te) == 0:
        return []

    tr['y'] = fix_zeros(tr['y'].values)

    avail   = [r for r in SAFE_REGS if r in tr.columns and tr[r].std() > 0.01]
    avail_n = []
    for reg in avail:
        mu  = tr[reg].mean()
        sig = tr[reg].std() or 1.0
        tr[reg+'_n'] = (tr[reg] - mu) / sig
        te[reg+'_n'] = (te[reg] - mu) / sig
        avail_n.append(reg+'_n')

    m = Prophet(
        growth='flat',
        yearly_seasonality=False,
        weekly_seasonality=False,
        daily_seasonality=False,
        seasonality_mode='additive',
        changepoint_prior_scale=0.01,
        seasonality_prior_scale=5.0,
        interval_width=0.80,
    )
    m.add_seasonality(name='biannual', period=182.5, fourier_order=3)
    for reg in avail_n:
        m.add_regressor(reg, standardize=False)

    m.fit(tr[['ds','y']+avail_n])
    fc = m.predict(te[['ds']+avail_n])
    for col in ['yhat','yhat_lower','yhat_upper']:
        fc[col] = fc[col].clip(lower=0)

    rows = []
    for _, row in te.iterrows():
        match = fc[fc['ds'] == row['ds']]
        if len(match):
            rows.append({
                'week_start':   row['ds'],
                'item_id':      sku,
                'store':        store,
                'state':        sub['state'].iloc[0],
                'actual':       float(row['y']),
                'prophet_pred': float(match['yhat'].values[0]),
                'prophet_lo':   float(match['yhat_lower'].values[0]),
                'prophet_hi':   float(match['yhat_upper'].values[0]),
            })
    return rows

tasks   = [(sku, store) for sku in SKUS for store in STORES]
results = Parallel(n_jobs=-1, verbose=0)(
    delayed(fit_prophet_one)(s, st) for s, st in tasks)

prophet_preds = pd.DataFrame([r for batch in results for r in batch])
prophet_wmape = wmape(prophet_preds['actual'], prophet_preds['prophet_pred'])
print(f"  ✓ Prophet     WMAPE: {prophet_wmape:.4f} ({prophet_wmape*100:.2f}%)  [{time.time()-t0:.0f}s]")


# ══════════════════════════════════════════════════════════════════
# 5.  ALIGN & ENSEMBLE
# ══════════════════════════════════════════════════════════════════
print("\n─" * 65)
print("  Aligning predictions and computing ensemble...")

# Merge keys: week_start + item_id + store
merge_keys = ['week_start', 'item_id', 'store']

base = (lgbm_preds[merge_keys + ['actual','lgbm_pred']]
        .merge(nbeats_preds[merge_keys + ['nbeats_pred']], on=merge_keys, how='inner')
        .merge(prophet_preds[merge_keys + ['state','prophet_pred','prophet_lo','prophet_hi']],
               on=merge_keys, how='inner'))

# Sanity: check we have 1200 rows (100 series × 12 weeks)
print(f"  Aligned rows: {len(base):,}  (expected {100*12:,})")
assert len(base) == 100*12, f"Alignment mismatch: got {len(base)}"

# ── Weighted ensemble ─────────────────────────────────────────────
base['ensemble_pred'] = (
    W_LGBM    * base['lgbm_pred']    +
    W_NBEATS  * base['nbeats_pred']  +
    W_PROPHET * base['prophet_pred']
).clip(lower=0)

# ── Model contribution per row (for stacked chart) ───────────────
base['contrib_lgbm']    = W_LGBM    * base['lgbm_pred']
base['contrib_nbeats']  = W_NBEATS  * base['nbeats_pred']
base['contrib_prophet'] = W_PROPHET * base['prophet_pred']

# Product name
base['product_name'] = base['item_id'].map(NAME)

ensemble_wmape = wmape(base['actual'], base['ensemble_pred'])


# ══════════════════════════════════════════════════════════════════
# 6.  METRICS
# ══════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print(f"  {'Model':<18} {'WMAPE':>8} {'WMAPE%':>8}")
print(f"  {'─'*38}")
for label, w in [('LightGBM',   lgbm_wmape),
                  ('N-BEATS',    nbeats_wmape),
                  ('Prophet',    prophet_wmape),
                  ('─── Ensemble', ensemble_wmape)]:
    marker = ' ← BEST' if label == '─── Ensemble' else ''
    print(f"  {label:<18} {w:>8.4f} {w*100:>7.2f}%{marker}")

best_single = min(lgbm_wmape, nbeats_wmape, prophet_wmape)
gain        = (best_single - ensemble_wmape) / best_single * 100
print(f"\n  Ensemble gain vs best single model: {gain:+.1f}%")
print(f"{'='*65}\n")

# Per-SKU × State metrics
metric_rows = []
for sku in SKUS:
    for state in STATES:
        sub = base[(base['item_id']==sku) & (base['state']==state)]
        if len(sub) == 0:
            continue
        metric_rows.append({
            'item_id':          sku,
            'product_name':     NAME[sku],
            'short_name':       SHORT.get(sku, sku),
            'state':            state,
            'wmape_ensemble':   wmape(sub['actual'], sub['ensemble_pred']),
            'wmape_lgbm':       wmape(sub['actual'], sub['lgbm_pred']),
            'wmape_nbeats':     wmape(sub['actual'], sub['nbeats_pred']),
            'wmape_prophet':    wmape(sub['actual'], sub['prophet_pred']),
            'mae_ensemble':     mae(sub['actual'],   sub['ensemble_pred']),
            'total_actual':     sub['actual'].sum(),
            'total_ensemble':   sub['ensemble_pred'].sum(),
        })
metrics_df = pd.DataFrame(metric_rows)

# State-level WMAPE
print(f"  {'State':<8} {'Ensemble':>10} {'LightGBM':>10} {'N-BEATS':>10} {'Prophet':>10}")
print(f"  {'─'*52}")
for state in STATES:
    sub = base[base['state'] == state]
    we = wmape(sub['actual'], sub['ensemble_pred'])
    wl = wmape(sub['actual'], sub['lgbm_pred'])
    wn = wmape(sub['actual'], sub['nbeats_pred'])
    wp = wmape(sub['actual'], sub['prophet_pred'])
    print(f"  {state:<8} {we:>10.4f} {wl:>10.4f} {wn:>10.4f} {wp:>10.4f}")
print()


# ══════════════════════════════════════════════════════════════════
# 7.  SAVE PREDICTIONS CSV
# ══════════════════════════════════════════════════════════════════
out_cols = [
    'week_start','item_id','product_name','store','state',
    'actual',
    'ensemble_pred',      # ← primary output for Inventory Insights layer
    'lgbm_pred','nbeats_pred','prophet_pred',
    'contrib_lgbm','contrib_nbeats','contrib_prophet',
    'prophet_lo','prophet_hi',  # confidence interval from Prophet
]
base[out_cols].to_csv(
    f'{OUTPUT_DIR}/final_ensemble_predictions.csv', index=False)
metrics_df.to_csv(
    f'{OUTPUT_DIR}/ensemble_metrics.csv', index=False)
print(f"  Predictions → {OUTPUT_DIR}/final_ensemble_predictions.csv")
print(f"  Metrics     → {OUTPUT_DIR}/ensemble_metrics.csv")


# ══════════════════════════════════════════════════════════════════
# 8.  DASHBOARD
# ══════════════════════════════════════════════════════════════════
print("  Building dashboard...")

fig = plt.figure(figsize=(24, 22))
fig.patch.set_facecolor(COL['panel'])
gs  = gridspec.GridSpec(4, 3, figure=fig, hspace=0.55, wspace=0.38,
                        height_ratios=[0.45, 2.2, 2.2, 2.2])

# ── Title strip ───────────────────────────────────────────────────
ax0 = fig.add_subplot(gs[0, :])
ax0.set_facecolor(COL['dark'])
for sp in ax0.spines.values(): sp.set_visible(False)
ax0.tick_params(left=False, bottom=False, labelleft=False, labelbottom=False)
ax0.text(0.5, 0.68,
    'CastAhead — Weighted Hybrid Ensemble Dashboard',
    ha='center', va='center', fontsize=17, fontweight='bold', color='white')
ax0.text(0.5, 0.22,
    f"LightGBM {W_LGBM:.0%} + N-BEATS {W_NBEATS:.0%} + Prophet {W_PROPHET:.0%}  |  "
    f"Test WMAPE → LightGBM: {lgbm_wmape*100:.2f}%  "
    f"N-BEATS: {nbeats_wmape*100:.2f}%  "
    f"Prophet: {prophet_wmape*100:.2f}%  "
    f"Ensemble: {ensemble_wmape*100:.2f}%",
    ha='center', va='center', fontsize=10.5, color='#9FB4C7')

# ── Panel A: Nationwide Actual vs Ensemble (weekly aggregate) ─────
ax_nat = fig.add_subplot(gs[1, :])
ax_nat.set_facecolor(COL['bg'])
nat = (base.groupby('week_start')
       .agg(actual=('actual','sum'),
            ensemble=('ensemble_pred','sum'),
            lgbm=('lgbm_pred','sum'),
            nbeats=('nbeats_pred','sum'),
            prophet=('prophet_pred','sum'))
       .reset_index().sort_values('week_start'))

ax_nat.plot(nat['week_start'], nat['actual'],
            color=COL['actual'],   lw=2.5, marker='o', ms=6,  label='Actual')
ax_nat.plot(nat['week_start'], nat['ensemble'],
            color=COL['ensemble'], lw=2.5, ls='-', marker='D', ms=5, label='Ensemble', zorder=5)
ax_nat.plot(nat['week_start'], nat['lgbm'],
            color=COL['lgbm'],    lw=1.5, ls='--', alpha=0.7, label='LightGBM')
ax_nat.plot(nat['week_start'], nat['nbeats'],
            color=COL['nbeats'],  lw=1.5, ls='-.', alpha=0.7, label='N-BEATS')
ax_nat.plot(nat['week_start'], nat['prophet'],
            color=COL['prophet'], lw=1.5, ls=':', alpha=0.7,  label='Prophet')

wn = wmape(nat['actual'], nat['ensemble'])
ax_nat.text(0.98, 0.97, f'Ensemble WMAPE: {wn:.3f}',
            transform=ax_nat.transAxes, ha='right', va='top', fontsize=10,
            bbox=dict(boxstyle='round,pad=0.4', fc='white', ec='#DDD', alpha=0.92))
ax_nat.set_title('Nationwide — All 10 SKUs × All Stores  (Test Period)',
                 fontsize=12, fontweight='bold')
ax_nat.set_ylabel('Total Units / Week', fontsize=10)
ax_nat.legend(fontsize=9, ncol=5, loc='upper left')
ax_nat.tick_params(axis='x', rotation=25, labelsize=8.5)

# ── Panel B: Model Contribution Stacked Area ──────────────────────
ax_contrib = fig.add_subplot(gs[2, :2])
ax_contrib.set_facecolor(COL['bg'])
nat_c = (base.groupby('week_start')
         .agg(lgbm=('contrib_lgbm','sum'),
              nbeats=('contrib_nbeats','sum'),
              prophet=('contrib_prophet','sum'))
         .reset_index().sort_values('week_start'))

weeks_c = nat_c['week_start']
ax_contrib.stackplot(weeks_c,
    nat_c['lgbm'], nat_c['nbeats'], nat_c['prophet'],
    labels=[f'LightGBM ({W_LGBM:.0%})',
            f'N-BEATS ({W_NBEATS:.0%})',
            f'Prophet ({W_PROPHET:.0%})'],
    colors=[COL['lgbm'], COL['nbeats'], COL['prophet']],
    alpha=0.75)
ax_contrib.plot(nat['week_start'], nat['actual'],
                color=COL['actual'], lw=2, marker='o', ms=4, label='Actual', zorder=5)
ax_contrib.set_title('Model Contribution — Stacked (Test Period)',
                     fontsize=12, fontweight='bold')
ax_contrib.set_ylabel('Units Contributed', fontsize=10)
ax_contrib.legend(fontsize=9, loc='upper left')
ax_contrib.tick_params(axis='x', rotation=25, labelsize=8.5)

# ── Panel C: WMAPE comparison bar (all 4 models) ──────────────────
ax_bar = fig.add_subplot(gs[2, 2])
ax_bar.set_facecolor(COL['bg'])
models     = ['LightGBM','N-BEATS','Prophet','Ensemble']
wm_vals    = [lgbm_wmape*100, nbeats_wmape*100, prophet_wmape*100, ensemble_wmape*100]
bar_colors = [COL['lgbm'], COL['nbeats'], COL['prophet'], COL['ensemble']]
bars = ax_bar.bar(models, wm_vals, color=bar_colors, alpha=0.85,
                  edgecolor='white', width=0.55)
for bar, v in zip(bars, wm_vals):
    ax_bar.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.3,
                f'{v:.2f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
ax_bar.axhline(20, color='red', ls='--', lw=1.3, alpha=0.6, label='20% target')
ax_bar.set_title('Overall WMAPE — All Models', fontsize=11, fontweight='bold')
ax_bar.set_ylabel('WMAPE %', fontsize=10)
ax_bar.tick_params(axis='x', labelsize=9)
ax_bar.legend(fontsize=8)
ax_bar.set_ylim(0, max(wm_vals)*1.25)

# ── Panel D: WMAPE by state (Ensemble vs individual) ──────────────
ax_state = fig.add_subplot(gs[3, :2])
ax_state.set_facecolor(COL['bg'])
x    = np.arange(len(STATES))
bw   = 0.20
lbl  = ['LightGBM','N-BEATS','Prophet','Ensemble']
cols = [COL['lgbm'], COL['nbeats'], COL['prophet'], COL['ensemble']]
offs = [-1.5, -0.5, 0.5, 1.5]

for off, lbl_, col_, key in zip(offs, lbl, cols,
    ['wmape_lgbm','wmape_nbeats','wmape_prophet','wmape_ensemble']):
    vals = [metrics_df[metrics_df['state']==s][key].mean() for s in STATES]
    bars2 = ax_state.bar(x + off*bw, vals, bw,
                         color=col_, alpha=0.82, label=lbl_, edgecolor='white')
    for bar, v in zip(bars2, vals):
        ax_state.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.003,
                      f'{v:.3f}', ha='center', va='bottom', fontsize=8, fontweight='bold')

ax_state.set_xticks(x)
ax_state.set_xticklabels([f"{s} — {STATE_NAMES[s]}" for s in STATES], fontsize=10)
ax_state.set_title('WMAPE by State — All Models vs Ensemble',
                   fontsize=12, fontweight='bold')
ax_state.set_ylabel('WMAPE', fontsize=10)
ax_state.axhline(0.20, color='red', ls='--', lw=1.2, alpha=0.5, label='0.20 target')
ax_state.legend(fontsize=9, ncol=5)

# ── Panel E: Per-SKU Ensemble WMAPE horizontal bar ────────────────
ax_sku = fig.add_subplot(gs[3, 2])
ax_sku.set_facecolor(COL['bg'])
sku_w  = (metrics_df.groupby('short_name')['wmape_ensemble']
          .mean().sort_values())
bh     = ax_sku.barh(sku_w.index, sku_w.values,
                     color=['#27AE60' if v<0.18 else '#F39C12' if v<0.28 else '#E74C3C'
                            for v in sku_w.values],
                     alpha=0.85, edgecolor='white')
for bar, v in zip(bh, sku_w.values):
    ax_sku.text(v+0.003, bar.get_y()+bar.get_height()/2,
                f'{v:.3f}', va='center', fontsize=9, fontweight='bold')
ax_sku.axvline(0.20, color='green', ls='--', lw=1.3, alpha=0.6)
ax_sku.axvline(0.28, color='red',   ls='--', lw=1.3, alpha=0.6)
ax_sku.set_title('Ensemble WMAPE per SKU\n(avg across states)',
                 fontsize=11, fontweight='bold')
ax_sku.set_xlabel('WMAPE', fontsize=10)

plt.savefig(f'{OUTPUT_DIR}/ensemble_dashboard.png',
            dpi=150, bbox_inches='tight', facecolor=COL['panel'])
plt.close()
print(f"  Dashboard   → {OUTPUT_DIR}/ensemble_dashboard.png")


# ══════════════════════════════════════════════════════════════════
# 9.  FINAL SUMMARY
# ══════════════════════════════════════════════════════════════════
print(f"\n{'='*65}")
print("  ✅  Ensemble Complete!")
print(f"{'='*65}")
print(f"""
  Component WMAPEs (test period):
    LightGBM  : {lgbm_wmape*100:>6.2f}%   (exogenous features & macro signals)
    N-BEATS   : {nbeats_wmape*100:>6.2f}%   (sequence shocks & non-linear patterns)
    Prophet   : {prophet_wmape*100:>6.2f}%   (seasonality baseline)
    ─────────────────────────────────
    Ensemble  : {ensemble_wmape*100:>6.2f}%   ← weighted average

  Ensemble gain vs best single: {gain:+.1f}%

  Weights applied:
    LightGBM  {W_LGBM:.0%}  ← holiday/event & macro correlations
    N-BEATS   {W_NBEATS:.0%}  ← supply shocks & complex sequences
    Prophet   {W_PROPHET:.0%}  ← stable seasonality floor

  Outputs:
    {OUTPUT_DIR}/final_ensemble_predictions.csv
    {OUTPUT_DIR}/ensemble_metrics.csv
    {OUTPUT_DIR}/ensemble_dashboard.png
""")
