#!/bin/bash
# CastAhead — Start both backend and frontend
set -e

echo ""
echo "╔═══════════════════════════════════════╗"
echo "║       CastAhead — Starting Up         ║"
echo "╚═══════════════════════════════════════╝"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌  Python 3 not found. Please install Python 3.10+"
    exit 1
fi

# Check Node
if ! command -v node &> /dev/null; then
    echo "❌  Node.js not found. Please install Node.js 18+"
    exit 1
fi

# Backend setup
echo "⚙️  Setting up backend..."
cd backend

if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "📄  Created backend/.env from example"
fi

pip install -r requirements.txt --quiet

echo "🚀  Starting FastAPI backend on port 8000..."
uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!

cd ..

# Frontend setup
echo "⚙️  Setting up frontend..."
cd frontend

if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "📄  Created frontend/.env from example"
fi

if [ ! -d "node_modules" ]; then
    echo "📦  Installing npm dependencies..."
    npm install --silent
fi

echo "🚀  Starting React frontend on port 5173..."
npm run dev &
FRONTEND_PID=$!

cd ..

echo ""
echo "╔═══════════════════════════════════════╗"
echo "║         ✅  Both Servers Running       ║"
echo "╠═══════════════════════════════════════╣"
echo "║  Frontend  → http://localhost:5173    ║"
echo "║  Backend   → http://localhost:8000    ║"
echo "║  API Docs  → http://localhost:8000/docs║"
echo "╚═══════════════════════════════════════╝"
echo ""
echo "Press Ctrl+C to stop both servers"

# Wait for both processes, clean up on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'Servers stopped.'" EXIT
wait
