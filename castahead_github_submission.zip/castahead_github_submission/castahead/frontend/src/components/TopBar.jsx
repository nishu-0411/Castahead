import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import AccountModal from './AccountModal'

export default function TopBar({ title, subtitle, onMenuClick }) {
  const navigate = useNavigate()
  const { backendOnline } = useApp()
  const [accountModalOpen, setAccountModalOpen] = useState(false)

  return (
    <>
    <header className="w-full sticky top-0 z-40 bg-white/80 backdrop-blur-md shadow-sm border-b border-slate-200">
      <div className="flex items-center justify-between px-4 md:px-8 py-3">
        <div className="flex items-center gap-4 md:gap-8">
          {/* Mobile menu button */}
          <button onClick={onMenuClick} className="lg:hidden text-slate-600 hover:text-[#00D4AA] transition-colors">
            <span className="material-symbols-outlined text-2xl">menu</span>
          </button>
          <div className="flex items-center gap-4 md:gap-6">
            <span className="text-slate-900 font-headline font-bold text-sm tracking-tight hidden md:block">CastAhead</span>
            <div className="h-4 w-px bg-slate-200 hidden md:block" />
            <span className="text-slate-400 font-mono text-[10px] font-bold tracking-widest uppercase">
              {title}
            </span>
          </div>
          {subtitle && <span className="hidden lg:block text-[#00D4AA] font-semibold text-sm tracking-tight font-brand">{subtitle}</span>}
        </div>
        <div className="flex items-center gap-3 md:gap-5">
          {/* Live API status indicator */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-full border border-slate-100">
            <div className={`w-1.5 h-1.5 rounded-full ${backendOnline ? 'bg-green-500' : backendOnline === false ? 'bg-red-400' : 'bg-amber-400'}`}
                 style={backendOnline ? {animation:'pulse 2s infinite'} : {}} />
            <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">
              {backendOnline === null ? 'Connecting' : backendOnline ? 'Live' : 'Offline'}
            </span>
          </div>
          <div className="h-6 w-px bg-slate-200 hidden sm:block" />
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => setAccountModalOpen(true)}>
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-slate-900 group-hover:text-[#006b55] transition-colors">Alex Stratton</p>
              <p className="text-[10px] text-slate-500 font-medium">Supply Chain Lead</p>
            </div>
            <div className="w-9 h-9 rounded-full bg-[#00D4AA] flex items-center justify-center text-white font-bold text-sm group-hover:ring-2 group-hover:ring-[#00D4AA]/30 transition-all">A</div>
          </div>
        </div>
      </div>
    </header>
    <AccountModal isOpen={accountModalOpen} onClose={() => setAccountModalOpen(false)} />
    </>
  )
}
