import { useState } from 'react'
import Sidebar from './Sidebar'
import TopBar from './TopBar'

export default function AppLayout({ children, topTitle, topSubtitle }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="flex min-h-screen">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/30 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
      <Sidebar mobileOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <main className="lg:ml-64 flex-1 flex flex-col min-h-screen">
        <TopBar title={topTitle} subtitle={topSubtitle} onMenuClick={() => setSidebarOpen(v => !v)} />
        <div className="flex-1 page-enter">
          {children}
        </div>
      </main>
    </div>
  )
}
