import { NavLink, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'

const NAV = [
  { to: '/',            icon: 'home',        label: 'Home' },
  { to: '/dashboard',   icon: 'dashboard',   label: 'Inventory Dashboard' },
  { to: '/forecast',    icon: 'analytics',   label: 'Forecast Detail' },
  { to: '/scenario',    icon: 'query_stats', label: 'Scenario Planner' },
  { to: '/pricing',     icon: 'payments',    label: 'Plans & Pricing' },
]

export default function Sidebar({ mobileOpen, onClose }) {
  const { backendOnline } = useApp()
  const navigate = useNavigate()

  const handleNav = (to) => {
    navigate(to)
    if (onClose) onClose()
  }

  return (
    <aside className={`fixed left-0 top-0 h-full w-64 z-50 bg-[#f2f4f6] shadow-[4px_0_24px_rgba(0,0,0,0.02)] border-r border-slate-200/50 flex flex-col
      transition-transform duration-300 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex flex-col h-full py-6 px-4">

        {/* Brand + mobile close */}
        <div className="mb-10 px-4 flex items-center justify-between">
          <div>
            <h1 className="font-headline font-bold text-[#00D4AA] text-xl tracking-tighter cursor-pointer"
                onClick={() => handleNav('/')}>CastAhead</h1>
            <p className="text-[10px] font-medium text-slate-500 uppercase tracking-[0.2em] mt-1">
              Statistical Forecaster
            </p>
          </div>
          <button onClick={onClose} className="lg:hidden text-slate-500 hover:text-slate-700">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-1">
          {NAV.map(({ to, icon, label }) => (
            <NavLink key={to} to={to} end={to === '/'}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm font-body ` +
                (isActive
                  ? 'bg-white text-[#006b55] shadow-sm font-bold border border-slate-200/50'
                  : 'text-slate-600 hover:bg-white/50 hover:text-[#00D4AA]')
              }>
              {({ isActive }) => <>
                <span className={`material-symbols-outlined text-xl ${isActive ? 'font-fill' : ''}`}>{icon}</span>
                <span>{label}</span>
              </>}
            </NavLink>
          ))}
        </nav>

        {/* Bottom */}
        <div className="mt-auto px-2 space-y-1">
          <a
            href="mailto:concierge@castahead.io"
            className="flex items-center gap-3 text-slate-500 px-4 py-2 hover:text-[#00D4AA] transition-all">
            <span className="material-symbols-outlined text-xl">help</span>
            <span className="font-body text-[11px] font-bold uppercase tracking-wider">Support</span>
          </a>

          {/* Status badge */}
          <div className="mt-3 mx-2 px-3 py-2 bg-white rounded-xl border border-slate-200 flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${backendOnline ? 'bg-green-500' : backendOnline === false ? 'bg-red-400' : 'bg-amber-400'}`}
                 style={backendOnline ? {animation:'pulse 2s infinite'} : {}} />
            <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">
              {backendOnline === null ? 'Connecting…' : backendOnline ? 'API Online' : 'API Offline'}
            </span>
          </div>

          {/* Current plan */}
          <div className="mx-2 px-3 py-2 bg-white rounded-xl border border-slate-200">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Current Tier</p>
            <p className="text-sm font-bold text-[#006b55]">Pro Plan <span className="inline-block w-2 h-2 rounded-full bg-[#00D4AA] ml-1 align-middle" /></p>
          </div>
        </div>
      </div>
    </aside>
  )
}
