export default function Spinner({ text = 'Loading…' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-20">
      <div className="w-10 h-10 border-4 border-slate-200 border-t-[#00D4AA] rounded-full animate-spin" />
      <p className="text-sm font-mono text-slate-500 uppercase tracking-widest">{text}</p>
    </div>
  )
}
