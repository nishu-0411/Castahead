import { createContext, useContext, useState, useEffect } from 'react'
import { getHealth, getSkus } from '../utils/api'

const AppCtx = createContext(null)

export function AppProvider({ children }) {
  const [skus, setSkus]               = useState([])
  const [selectedSku, setSelectedSku] = useState(null)
  const [skusLoading, setSkusLoading] = useState(true)
  const [backendOnline, setBackendOnline] = useState(null)

  useEffect(() => {
    // Fast health ping resolves the status indicator before the heavier SKU fetch
    getHealth()
      .then(() => setBackendOnline(true))
      .catch(() => {}) // SKU result below is ground truth — don't flip offline prematurely

    getSkus()
      .then(r => { setSkus(r.data.skus); setBackendOnline(true); setSkusLoading(false) })
      .catch(() => { setBackendOnline(false); setSkusLoading(false) })
  }, [])

  return (
    <AppCtx.Provider value={{ skus, selectedSku, setSelectedSku, skusLoading, backendOnline }}>
      {children}
    </AppCtx.Provider>
  )
}

export const useApp = () => useContext(AppCtx)
