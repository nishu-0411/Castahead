import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  ComposedChart, Line, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, ReferenceLine, Legend
} from 'recharts'
import AppLayout from '../components/AppLayout'
import Spinner from '../components/Spinner'
import { getForecast, getSku, narrate } from '../utils/api'
import { useApp } from '../context/AppContext'

const RISK_COLORS = {
  CRITICAL: { bg:'bg-red-50', text:'text-red-600', border:'border-red-200', label:'CRITICAL' },
  MODERATE: { bg:'bg-amber-50',text:'text-amber-600',border:'border-amber-200',label:'MODERATE' },
  LOW:      { bg:'bg-green-50',text:'text-green-600',border:'border-green-200',label:'LOW' },
}

function buildChartData(skuDetail, forecast) {
  const hist = skuDetail?.history?.slice(-8) || []
  const histPoints = hist.map((h,i) => ({
    label: `W-${8-i}`, actual: h.sales, forecast: null, lower: null, upper: null, stock: null,
  }))
  const forePoints = forecast?.dates?.map((d,i) => ({
    label: `W+${i+1}`,
    actual: null,
    forecast: forecast.forecast[i],
    lower: forecast.lower_bound[i],
    upper: forecast.upper_bound[i],
    stock: forecast.stock_level?.[i],
  })) || []
  return [...histPoints, ...forePoints]
}

function buildAxisDomains(chartData) {
  const demandVals = []
  const stockVals = []

  chartData.forEach((row) => {
    ;['actual', 'forecast', 'lower', 'upper'].forEach((k) => {
      const v = row[k]
      if (v != null && Number.isFinite(v)) demandVals.push(Number(v))
    })
    if (row.stock != null && Number.isFinite(row.stock)) stockVals.push(Number(row.stock))
  })

  const buildDomain = (vals, floorAtZero = true) => {
    if (!vals.length) return [0, 100]
    const min = Math.min(...vals)
    const max = Math.max(...vals)
    if (min === max) {
      const pad = Math.max(1, Math.abs(max) * 0.15)
      const lo = floorAtZero ? Math.max(0, min - pad) : min - pad
      return [Math.floor(lo), Math.ceil(max + pad)]
    }
    const span = max - min
    const pad = Math.max(1, span * 0.12)
    const lo = floorAtZero ? Math.max(0, min - pad) : min - pad
    return [Math.floor(lo), Math.ceil(max + pad)]
  }

  return {
    demand: buildDomain(demandVals, true),
    stock: buildDomain(stockVals, true),
  }
}

function computeTrendDirection(forecastArr) {
  if (!forecastArr || forecastArr.length < 2) return 'stable'
  const first = forecastArr[0]
  const last = forecastArr[forecastArr.length - 1]
  const pctChange = (last - first) / first
  if (pctChange > 0.05) return 'increasing'
  if (pctChange < -0.05) return 'decreasing'
  return 'stable'
}

function buildPlanningDemandSummary(forecastArr, planningWeeks = 4) {
  if (!Array.isArray(forecastArr) || forecastArr.length === 0) {
    return {
      minimum_required: 0,
      most_likely: 0,
      max_capacity: 0,
      planning_weeks: Math.max(1, planningWeeks),
    }
  }

  const window = Math.max(1, Math.min(planningWeeks, forecastArr.length))
  const vals = forecastArr
    .slice(0, window)
    .map(v => (Number.isFinite(Number(v)) ? Math.max(0, Number(v)) : 0))

  const total = vals.reduce((acc, v) => acc + v, 0)
  return {
    minimum_required: Math.round(total * 0.85),
    most_likely: Math.round(total),
    max_capacity: Math.round(total * 1.15),
    planning_weeks: window,
  }
}

function computeRecoveredRevenue(sku, demandSummary) {
  const stock = Number(sku?.current_stock) || 0
  const target = Number(demandSummary?.most_likely) || 0
  const gapUnits = Math.max(0, target - stock)

  const reorderQty = Number(sku?.reorder_qty) || 0
  const modelRoi = Number(sku?.estimated_roi) || 0
  const impliedUnitValue = reorderQty > 0 && modelRoi > 0 ? (modelRoi / reorderQty) : 6

  const gapRoi = Math.round(gapUnits * impliedUnitValue)
  return Math.max(0, modelRoi, gapRoi)
}

// WMAPE helpers — clamp raw fractions to [0, 1] before display so that
// models trained on sparse data never show negative accuracy or >100% error.
const clampWmape  = (v) => Math.max(0, Math.min(1, v || 0))
const fmtWmape    = (v) => (clampWmape(v) * 100).toFixed(1) + '%'
const fmtAccuracy = (wmape) => Math.max(0, (1 - clampWmape(wmape)) * 100).toFixed(1) + '%'
const toWeightPct = (weight) => {
  const w = Math.max(0, Number(weight) || 0)
  const pct = w > 1 ? w : w * 100
  return Math.max(0, Math.min(100, Number(pct.toFixed(1))))
}

const MODEL_DRIVER_META = {
  lgbm: {
    name: 'LightGBM',
    color: 'secondary',
    icon: 'hub',
    description: 'Feature and event signals are currently carrying a strong share of this SKU forecast.',
  },
  nbeats: {
    name: 'N-BEATS',
    color: 'tertiary',
    icon: 'timeline',
    description: 'Temporal demand-shock patterns are a key dependency for this item right now.',
  },
  prophet: {
    name: 'Prophet',
    color: 'primary',
    icon: 'insights',
    description: 'Seasonality and trend structure are anchoring this SKU baseline forecast.',
  },
}

const MODEL_WEIGHT_ORDER = ['prophet', 'lgbm', 'nbeats']

function impactTierFromPct(pct) {
  if (pct >= 45) return 'HIGH IMPACT'
  if (pct >= 25) return 'MODERATE IMPACT'
  return 'LOW IMPACT'
}

function buildModelWeightRows(forecast) {
  const raw = forecast?.model_weights
  if (!raw) return []

  return MODEL_WEIGHT_ORDER
    .filter((k) => raw[k] != null)
    .map((k) => ({
      key: k,
      pct: toWeightPct(raw[k]),
      wmape: forecast?.metrics?.[`wmape_${k}`],
    }))
}

function buildModelDrivers(modelWeightRows) {
  if (!modelWeightRows?.length) return null

  return modelWeightRows.map((row) => {
    const meta = MODEL_DRIVER_META[row.key]
    const pct = row.pct
    return {
      name: meta.name,
      impact: impactTierFromPct(pct),
      impact_label: `${pct.toFixed(1)}% dependency`,
      description: meta.description,
      bar_pct: Math.max(0, Math.min(100, pct)),
      color: meta.color,
      icon: meta.icon,
      key: row.key,
    }
  })
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-slate-900 text-white p-3 rounded-lg shadow-2xl text-xs font-mono">
      <p className="text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      {payload.map(p => p.value != null && (
        <p key={p.name} style={{color:p.color}}>{p.name}: <strong>{Math.round(p.value)}</strong></p>
      ))}
    </div>
  )
}

export default function ForecastDetail() {
  const { skuId: urlSkuId } = useParams()
  const { selectedSku, skus, setSelectedSku } = useApp()
  const [skuDetail, setSkuDetail]   = useState(null)
  const [forecast,  setForecast]    = useState(null)
  const [loading,   setLoading]     = useState(true)
  const [narration, setNarration]   = useState('')
  const [narrateLoading, setNarrateLoading] = useState(false)
  const [activeTab, setActiveTab]   = useState('STORE LEVEL')
  const navigate = useNavigate()

  // Resolve the current SKU: URL param > selectedSku > first from list
  const resolvedSkuId = urlSkuId || selectedSku?.sku_id || (skus.length > 0 ? skus[0].sku_id : null)
  const currentSkuMeta = skus.find(s => s.sku_id === resolvedSkuId) || selectedSku

  useEffect(() => {
    if (!resolvedSkuId) return
    setLoading(true)
    setNarration('')
    Promise.all([getSku(resolvedSkuId), getForecast(resolvedSkuId)])
      .then(([skuRes, fcRes]) => {
        setSkuDetail(skuRes.data)
        setForecast(fcRes.data)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [resolvedSkuId])

  const handleNarrate = async () => {
    if (!forecast || !resolvedSkuId) return
    setNarrateLoading(true)
    const trendDir = computeTrendDirection(forecast.forecast)
    // Find which model has best WMAPE (lowest)
    const metrics = forecast.metrics || {}
    const models = [
      { name: 'prophet', wmape: metrics.wmape_prophet },
      { name: 'lgbm',    wmape: metrics.wmape_lgbm },
      { name: 'nbeats',  wmape: metrics.wmape_nbeats },
    ].filter(m => m.wmape != null)
    const dominant = models.length > 0
      ? models.reduce((a, b) => a.wmape < b.wmape ? a : b).name
      : 'ensemble'
    try {
      const r = await narrate({
        sku_id: resolvedSkuId,
        sku_name: skuDetail?.name || currentSkuMeta?.name || resolvedSkuId,
        wmape_ensemble: metrics.wmape_ensemble || 0.09,
        trend_direction: trendDir,
        dominant_model: dominant,
        reorder_qty: skuDetail?.reorder_qty || 0,
        reorder_deadline: skuDetail?.reorder_deadline || '',
        estimated_roi: recoveredRevenue,
      })
      setNarration(r.data.narration)
    } catch { setNarration('Demand forecasting complete. Please proceed with the recommended action.') }
    setNarrateLoading(false)
  }

  if (!resolvedSkuId) return (
    <AppLayout topTitle="Forecast Detail">
      <div className="p-10 text-center">
        <p className="text-slate-500 mb-4">No SKU selected.</p>
        <button onClick={()=>navigate('/dashboard')} className="px-6 py-3 bg-[#006b55] text-white rounded font-bold">← Back to Dashboard</button>
      </div>
    </AppLayout>
  )

  const chartData = buildChartData(skuDetail, forecast)
  const axisDomains = buildAxisDomains(chartData)
  const futureLabels = chartData.filter(d => d.label?.startsWith('W+')).map(d => d.label)
  const riskRefLabel = futureLabels.length ? futureLabels[Math.min(3, futureLabels.length - 1)] : null
  const sku = skuDetail || currentSkuMeta || {}
  const factors = sku.factors || []
  const modelWeightRows = buildModelWeightRows(forecast)
  const modelDrivers = buildModelDrivers(modelWeightRows)
  const locations = sku.location_breakdown || []
  const apiDemand = forecast?.demand_summary || {}
  const preferredWindow = Number.isFinite(apiDemand?.planning_weeks) ? Number(apiDemand.planning_weeks) : 4
  const computedDemand = buildPlanningDemandSummary(forecast?.forecast || [], preferredWindow)
  const demand = forecast?.forecast?.length ? { ...apiDemand, ...computedDemand } : apiDemand
  const planningWeeks = Number.isFinite(demand?.planning_weeks) ? demand.planning_weeks : Math.min(4, forecast?.dates?.length || 4)
  const recoveredRevenue = computeRecoveredRevenue(sku, demand)

  return (
    <AppLayout topTitle="Forecast Detail">
      <div className="p-8 max-w-[1400px] mx-auto w-full">

        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-slate-500 mb-8 font-mono">
          <button onClick={()=>navigate('/dashboard')} className="hover:text-[#006b55] transition-colors">All SKUs</button>
          <span className="material-symbols-outlined text-base">chevron_right</span>
          <span className="text-slate-900 font-bold">{sku.name || resolvedSkuId}</span>
        </div>

        {/* SKU Hero Row */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-3 mb-2">
              <span className="px-2.5 py-1 bg-slate-100 text-slate-600 text-[10px] font-bold uppercase tracking-widest rounded">{sku.category || 'SKU'}</span>
              <span className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest rounded ${sku.status === 'AT_RISK' ? 'bg-red-50 text-red-600 border border-red-200' : sku.status === 'NEEDS_ATTENTION' ? 'bg-amber-50 text-amber-600 border border-amber-200' : 'bg-green-50 text-green-600 border border-green-200'}`}>
                {sku.risk_label || sku.status || 'Loading…'}
              </span>
            </div>

            {/* SKU selector */}
            <div className="flex flex-col lg:flex-row lg:items-center gap-3 mb-3">
              <h2
                className="font-headline text-4xl md:text-5xl font-bold tracking-tight text-slate-900 leading-[1.05] min-w-0 max-w-full lg:max-w-[760px] truncate"
                title={sku.name || 'Loading...'}>
                {sku.name || 'Loading…'}
              </h2>
              {skus.length > 0 && (
                <div className="w-full lg:w-[360px] shrink-0">
                  <select
                    value={resolvedSkuId}
                    onChange={e => { const s = skus.find(x=>x.sku_id===e.target.value); setSelectedSku(s); navigate(`/forecast/${e.target.value}`) }}
                    className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 font-mono text-slate-600 bg-white focus:outline-none focus:border-[#00D4AA]">
                    {skus.map(s => <option key={s.sku_id} value={s.sku_id}>{s.name}</option>)}
                  </select>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col items-end bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-1">Current Availability</span>
            <div className="flex items-center gap-2">
              <span className="text-3xl font-headline font-bold text-[#00D4AA]">{(sku.current_stock||0).toLocaleString()} units</span>
              <span className="material-symbols-outlined text-[#00D4AA] font-fill">inventory_2</span>
            </div>
                <span className="text-[10px] font-mono text-slate-400">on-hand right now</span>
          </div>
        </div>

        {loading ? <Spinner text="Running forecast models…" /> : (
          <>
            {/* KEY PERFORMANCE DRIVERS */}
            <section className="mb-12">
              <h3 className="font-headline text-xs font-bold mb-6 flex items-center gap-2 uppercase tracking-widest text-slate-400">
                <span className="w-1 h-4 bg-[#00D4AA] rounded-full" />Key Performance Drivers
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {(modelDrivers || factors).map(f => (
                  <div key={f.name} className="bg-white p-6 border border-slate-200 rounded-xl card-shadow group hover:border-[#006b55]/30 transition-colors">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-2 bg-amber-50 rounded-lg">
                        <span className="material-symbols-outlined text-amber-600 text-xl">
                          {f.icon || (f.name.includes('Weather') ? 'sunny' : f.name.includes('Market') ? 'trending_up' : f.name.includes('Supply') ? 'local_shipping' : 'local_gas_station')}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className={`block text-[10px] font-bold uppercase tracking-widest ${f.impact.includes('HIGH') ? 'text-red-500' : f.impact.includes('MODERATE') ? 'text-blue-500' : 'text-amber-500'}`}>
                          {f.impact}
                        </span>
                        {f.impact_label && (
                          <span className="block text-[10px] font-mono text-slate-400 mt-1">{f.impact_label}</span>
                        )}
                      </div>
                    </div>
                    <h4 className="font-headline text-lg font-bold mb-2 text-slate-900">{f.name}</h4>
                    <p className="text-sm text-slate-500 mb-4">{f.description}</p>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full transition-all duration-700 ${f.color === 'primary' ? 'bg-[#006b55]' : f.color === 'secondary' ? 'bg-[#0062A0]' : f.color === 'error' ? 'bg-red-500' : 'bg-amber-500'}`}
                           style={{width:`${f.bar_pct}%`}} />
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* DEMAND FORECAST CHART */}
            <section className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-headline text-xs font-bold flex items-center gap-2 uppercase tracking-widest text-slate-400">
                  <span className="w-1 h-4 bg-[#00D4AA] rounded-full" />Demand Forecast Baseline
                </h3>
                <div className="flex items-center gap-6 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                  <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-[#006b55]" />Forecasted</div>
                  <div className="flex items-center gap-2"><div className="w-4 h-0.5 bg-slate-400 border-t border-dashed" />Stock Level</div>
                </div>
              </div>

              <div className="bg-white p-6 border border-slate-200 rounded-xl card-shadow relative">
                <ResponsiveContainer width="100%" height={280}>
                  <ComposedChart data={chartData} margin={{top:20,right:20,left:-10,bottom:0}}>
                    <defs>
                      <linearGradient id="forecastGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%"  stopColor="#006b55" stopOpacity={0.15}/>
                        <stop offset="95%" stopColor="#006b55" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="4 4" stroke="#f1f5f9" />
                    <XAxis
                      dataKey="label"
                      tick={{fontSize:9,fontFamily:'JetBrains Mono',fill:'#94a3b8'}}
                      interval="preserveStartEnd"
                    />
                    <YAxis
                      yAxisId="demand"
                      domain={axisDomains.demand}
                      tick={{fontSize:9,fontFamily:'JetBrains Mono',fill:'#94a3b8'}}
                      tickFormatter={(v)=>Number(v).toLocaleString()}
                    />
                    <YAxis
                      yAxisId="stock"
                      orientation="right"
                      domain={axisDomains.stock}
                      tick={{fontSize:9,fontFamily:'JetBrains Mono',fill:'#cbd5e1'}}
                      tickFormatter={(v)=>Number(v).toLocaleString()}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Area yAxisId="demand" type="monotone" dataKey="upper" stroke="none" fill="url(#forecastGrad)" />
                    <Area yAxisId="demand" type="monotone" dataKey="lower" stroke="none" fill="#ffffff" />
                    <Line yAxisId="demand" type="monotone" dataKey="actual"   stroke="#94a3b8" strokeWidth={2} dot={false} name="Actual" />
                    <Line yAxisId="demand" type="monotone" dataKey="forecast" stroke="#006b55" strokeWidth={2.5} dot={false} name="Forecast" />
                    <Line yAxisId="stock"  type="monotone" dataKey="stock"    stroke="#cbd5e1" strokeWidth={1.5} strokeDasharray="6 3" dot={false} name="Stock" />
                    {riskRefLabel && (
                      <ReferenceLine x={riskRefLabel} yAxisId="demand" stroke="#BA1A1A" strokeDasharray="4 3" strokeOpacity={0.6}
                        label={{value:`STOCKOUT RISK: ${riskRefLabel}`,position:'insideTopRight',fontSize:9,fill:'#BA1A1A',fontWeight:'bold'}} />
                    )}
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Model Weights Card */}
              {modelWeightRows.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
                  {modelWeightRows.map((row) => {
                    const weightPct = row.pct
                    const model = row.key
                    return (
                      <div key={model} className="bg-white p-4 rounded-xl border border-slate-200 card-shadow">
                        <p className="text-[10px] font-label font-bold text-slate-400 uppercase tracking-[0.2em] mb-1">{model}</p>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-headline font-bold text-slate-900">{weightPct.toFixed(1)}%</span>
                          <span className="text-xs text-slate-400 font-mono">weight</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mt-2">
                          <div className="h-full bg-[#006b55] rounded-full transition-all duration-700" style={{width:`${weightPct}%`}} />
                        </div>
                        <p className="text-[10px] text-slate-400 font-mono mt-1">WMAPE: {fmtWmape(row.wmape)}</p>
                      </div>
                    )
                  })}
                  <div className="bg-[#006b55]/5 p-4 rounded-xl border border-[#006b55]/20">
                    <p className="text-[10px] font-label font-bold text-[#006b55] uppercase tracking-[0.2em] mb-1">Ensemble</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-headline font-bold text-[#006b55]">{fmtAccuracy(forecast.metrics?.wmape_ensemble)}</span>
                      <span className="text-xs text-slate-400 font-mono">accuracy</span>
                    </div>
                    <div className="w-full bg-[#006b55]/20 h-1.5 rounded-full overflow-hidden mt-2">
                      <div className="h-full bg-[#006b55] rounded-full"
                           style={{width:`${Math.max(0, (1 - clampWmape(forecast.metrics?.wmape_ensemble)) * 100)}%`}} />
                    </div>
                    <p className="text-[10px] text-[#006b55]/70 font-mono mt-1">WMAPE: {fmtWmape(forecast.metrics?.wmape_ensemble)}</p>
                  </div>
                </div>
              )}

              {/* Min / Most Likely / Max */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                {[
                  { label:`MINIMUM REQUIRED (${planningWeeks}W)`, value:demand.minimum_required, sub:'Lower bound for the near-term planning window.', highlight:false },
                  { label:`TARGET FORECAST (${planningWeeks}W)`,  value:demand.most_likely,      sub:`${fmtAccuracy(forecast?.metrics?.wmape_ensemble ?? 0.08)} confidence level over next ${planningWeeks} weeks.`, highlight:true },
                  { label:`UPPER BOUNDARY (${planningWeeks}W)`,   value:demand.max_capacity,     sub:'Upper envelope for near-term replenishment.',       highlight:false },
                ].map(c=>(
                  <div key={c.label} className={`p-6 rounded-xl border ${c.highlight ? 'bg-[#006b55]/5 border-[#006b55]/20' : 'bg-white border-slate-200'}`}>
                    <p className="text-[10px] font-label font-bold text-slate-400 uppercase tracking-[0.2em] mb-2">{c.label}</p>
                    <div className="flex items-baseline gap-2">
                      <span className={`text-4xl font-headline font-bold ${c.highlight ? 'text-[#006b55]' : 'text-slate-900'}`}>{(c.value||0).toLocaleString()}</span>
                      <span className="text-sm text-slate-400 font-label">units</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-2 font-mono">{c.sub}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* RECOMMENDATION CARD */}
            <section className="mb-12">
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xl shadow-slate-200/50">
                <div className="grid grid-cols-1 lg:grid-cols-12">
                  <div className="lg:col-span-7 p-10 lg:p-12">
                    <div className="flex items-center gap-2 mb-4">
                      <span className="material-symbols-outlined text-[#00D4AA] text-sm font-fill">auto_awesome</span>
                      <span className="text-[10px] font-bold text-[#00D4AA] uppercase tracking-[0.2em]">CastAhead Recommendation</span>
                    </div>
                    <h3 className="font-headline text-3xl font-bold text-slate-900 mb-6 leading-tight">
                      {sku.reorder_qty > 0
                        ? `Reorder ${sku.reorder_qty} units by ${sku.reorder_deadline || 'next week'}`
                        : 'Hold current stock levels'}
                    </h3>

                    {/* AI narration */}
                    {narration ? (
                      <div className="bg-[#006b55]/5 p-4 rounded-xl border border-[#006b55]/20 mb-6">
                        <p className="text-sm text-slate-700 leading-relaxed">{narration}</p>
                      </div>
                    ) : (
                      <p className="text-sm text-slate-500 mb-6 leading-relaxed">
                        CastAhead's recommendation based on historical demand patterns confirms a supply gap in Week 4.
                        Ordering now minimises per-unit freight costs while ensuring 99% shelf availability.
                      </p>
                    )}

                    <div className="bg-slate-50 p-5 rounded-xl border border-slate-100 flex items-center gap-5 mb-8">
                      <div className="h-12 w-12 bg-[#006b55]/10 flex items-center justify-center rounded-xl flex-shrink-0">
                        <span className="material-symbols-outlined text-[#006b55] font-fill">savings</span>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Calculated ROI</p>
                        <p className="text-xl font-headline font-bold text-[#006b55]">+${recoveredRevenue.toLocaleString()} Recovered Revenue</p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4">
                      <button onClick={handleNarrate} disabled={narrateLoading}
                        className="px-8 py-3.5 bg-slate-900 text-white font-bold text-sm rounded-lg hover:bg-slate-800 transition-all shadow-lg active:scale-95 disabled:opacity-60 flex items-center gap-2">
                        {narrateLoading
                          ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"/><span>Generating…</span></>
                          : <><span className="material-symbols-outlined text-base font-fill">auto_awesome</span><span>Generate AI Insight</span></>}
                      </button>
                      <button onClick={()=>navigate(`/scenario/${resolvedSkuId}`)}
                        className="px-8 py-3.5 border border-slate-200 text-slate-700 font-bold text-sm rounded-lg hover:bg-slate-50 transition-all active:scale-95">
                        Run Scenario Analysis
                      </button>
                    </div>
                  </div>

                  {/* Mini bar chart */}
                  <div className="lg:col-span-5 bg-slate-50 flex flex-col items-center justify-center border-l border-slate-100 p-8">
                    <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-6">Historical Demand Distribution</p>
                    <div className="w-full flex items-end justify-between h-32 gap-2 mb-3">
                      {(skuDetail?.history?.slice(-6) || [60,80,100,70,50,40].map(h=>({sales:h}))).map((h,i)=>{
                        const maxVal = Math.max(...(skuDetail?.history?.slice(-6)?.map(x=>x.sales) || [100]))
                        const pct = typeof h === 'object' ? (h.sales / maxVal) * 100 : h
                        return (
                          <div key={i} className={`flex-1 rounded-t transition-all duration-500 ${i===2?'bg-[#006b55]':i===1?'bg-[#006b55]/40':'bg-slate-200'}`}
                               style={{height:`${pct}%`}} />
                        )
                      })}
                    </div>
                    <p className="text-xs text-slate-400 font-mono">Last 6 demand cycles</p>
                  </div>
                </div>
              </div>
            </section>

            {/* REGIONAL DISTRIBUTION */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-headline text-xs font-bold flex items-center gap-2 uppercase tracking-widest text-slate-400">
                  <span className="w-1 h-4 bg-[#00D4AA] rounded-full" />Regional Distribution
                </h3>
                <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
                  {['NATIONAL','REGIONAL','STORE LEVEL'].map(t=>(
                    <button key={t} onClick={()=>setActiveTab(t)}
                      className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab===t ? 'bg-[#006b55] text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl card-shadow overflow-hidden">
                {activeTab === 'NATIONAL' && (
                  <div className="p-8 text-center">
                    <p className="text-4xl font-headline font-bold text-[#006b55] mb-2">{(sku.current_stock||0).toLocaleString()} units</p>
                    <p className="text-slate-500 font-mono text-sm">Total National Stock</p>
                    <div className="mt-6 w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                      <div className="h-full bg-[#006b55] rounded-full transition-all duration-1000" style={{width:'68%'}} />
                    </div>
                    <p className="text-xs text-slate-400 font-mono mt-2">68% of target stock level</p>
                  </div>
                )}
                {activeTab === 'REGIONAL' && (
                  <div className="grid grid-cols-2 gap-4 p-6">
                    {['North','South','East','West'].map((reg,i)=>(
                      <div key={reg} className="bg-slate-50 rounded-xl p-5 border border-slate-100">
                        <div className="flex justify-between items-start mb-3">
                          <span className="font-headline font-bold text-slate-900">{reg} Region</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${i===0?'bg-red-50 text-red-600':i===1?'bg-amber-50 text-amber-600':'bg-green-50 text-green-600'}`}>
                            {['At Risk','Watch','On Track','On Track'][i]}
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className="h-full bg-[#006b55] rounded-full" style={{width:`${[35,55,72,80][i]}%`}} />
                        </div>
                        <p className="text-xs text-slate-400 font-mono mt-1">{[35,55,72,80][i]}% stocked</p>
                      </div>
                    ))}
                  </div>
                )}
                {activeTab === 'STORE LEVEL' && (
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-100">
                        {['Location','On Hand','14 Days Forecast','Risk Assessment'].map(h=>(
                          <th key={h} className="px-6 py-4 text-[10px] font-label font-bold text-slate-400 uppercase tracking-[0.15em] text-left">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {locations.map(loc=>{
                        const r = RISK_COLORS[loc.risk] || RISK_COLORS.LOW
                        return (
                          <tr key={loc.store} className="border-b border-slate-50 hover:bg-slate-50/80 transition-colors">
                            <td className="px-6 py-4 font-medium text-slate-800 text-sm">{loc.store}</td>
                            <td className="px-6 py-4 font-mono text-slate-700">{loc.stock}</td>
                            <td className="px-6 py-4 font-mono text-slate-700">{loc.forecast_14d}</td>
                            <td className="px-6 py-4">
                              <span className={`inline-block px-3 py-1 rounded text-[10px] font-bold uppercase tracking-widest border ${r.bg} ${r.text} ${r.border}`}>
                                {r.label} ({loc.days} DAYS)
                              </span>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </section>
          </>
        )}
      </div>
    </AppLayout>
  )
}
