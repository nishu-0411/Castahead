import { useState } from 'react'
import AppLayout from '../components/AppLayout'

const PLANS = [
  {
    id:'starter', name:'STARTER', monthly:49, yearly:39,
    features:[
      { text:'Standard Statistical Demand Analysis', included:true },
      { text:'Inventory Health Dashboard',            included:true },
      { text:'Up to 500 SKUs tracked',                included:true },
      { text:'Scenario Planner (Statistical Simulation)', included:false },
      { text:'Regional Performance View',             included:false },
      { text:'Up to 5,000 SKUs tracked',              included:false },
      { text:'API Access for Integrations',           included:false },
    ],
    cta:'Get Started', highlight:false,
  },
  {
    id:'pro', name:'PRO', monthly:199, yearly:159,
    features:[
      { text:'Everything in Starter',                  included:true },
      { text:'Scenario Planner (Statistical Simulation)', included:true },
      { text:'Regional Performance View',              included:true },
      { text:'Up to 5,000 SKUs tracked',               included:true },
      { text:'API Access for Integrations',            included:true },
    ],
    cta:'Upgrade Now', highlight:true,
  },
  {
    id:'enterprise', name:'ENTERPRISE', monthly:null, yearly:null,
    features:[
      { text:'Infinite SKU tracking',            included:true },
      { text:'Dedicated Statistical Consultant', included:true },
      { text:'On-premise Deployment',            included:true },
      { text:'Custom Statistical Model Tuning',  included:true },
    ],
    cta:'Contact Sales', highlight:false,
  },
]

const FAQS = [
  { q:'Can I change plans at any time?',
    a:"Yes, you can upgrade or downgrade your plan instantly. If you upgrade, the new pricing will be prorated for the remainder of the month. Downgrades take effect at the start of the next billing cycle." },
  { q:'How accurate is the Statistical Scenario Planner?',
    a:"Our scenario planner achieves 88–94% accuracy on historical event simulations, verified across 50,000+ demand shock events in our training dataset." },
  { q:'Do you offer discounts for non-profits?',
    a:"Yes — we offer a 40% discount for registered non-profit organisations. Please contact our sales team with your registration details." },
  { q:'What happens to my data if I cancel?',
    a:"Your data is retained for 90 days after cancellation. You can export all historical forecasts and SKU data at any time during this window." },
]

export default function PricingPage() {
  const [yearly, setYearly] = useState(false)
  const [openFaq, setOpenFaq] = useState(null)

  return (
    <AppLayout topTitle="Plans & Pricing">
      <div className="p-10 space-y-16 max-w-[1200px] mx-auto w-full">

        {/* Header */}
        <div className="text-center">
          <h2 className="text-5xl font-headline font-bold tracking-tight text-slate-900 mb-4">Scale with Precision</h2>
          <p className="text-slate-500 text-lg max-w-xl mx-auto">
            Choose the forecasting precision that matches your business velocity.<br/>
            From lean startups to large-scale enterprises.
          </p>

          {/* Toggle */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <span className={`text-sm font-bold transition-colors ${!yearly ? 'text-slate-900' : 'text-slate-400'}`}>Monthly</span>
            <button onClick={() => setYearly(v => !v)}
              className={`w-12 h-6 rounded-full transition-colors relative ${yearly ? 'bg-[#00D4AA]' : 'bg-slate-200'}`}>
              <div className={`w-5 h-5 bg-white rounded-full shadow-sm absolute top-0.5 transition-transform ${yearly ? 'translate-x-6' : 'translate-x-0.5'}`} />
            </button>
            <span className={`text-sm font-bold transition-colors ${yearly ? 'text-slate-900' : 'text-slate-400'}`}>
              Yearly
            </span>
            <span className="text-[10px] font-bold text-[#00D4AA] bg-[#00D4AA]/10 px-2 py-1 rounded-full uppercase tracking-widest">Save 20%</span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
          {PLANS.map(p => {
            const price = p.monthly ? (yearly ? p.yearly : p.monthly) : null
            return (
              <div key={p.id}
                className={`bg-white rounded-2xl p-8 flex flex-col transition-all
                  ${p.highlight
                    ? 'border-2 border-[#00D4AA] shadow-2xl shadow-[#00D4AA]/10 scale-[1.02]'
                    : 'border border-slate-200 card-shadow'}`}>
                {p.highlight && (
                  <div className="text-[10px] font-bold text-[#006b55] uppercase tracking-widest bg-[#00D4AA]/10 px-3 py-1 rounded-full self-start mb-4">
                    ⭐ Most Popular
                  </div>
                )}
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">{p.name}</div>
                <div className="mb-6">
                  {price ? (
                    <div className="flex items-baseline gap-1">
                      <span className="text-sm text-slate-500">$</span>
                      <span className="text-5xl font-headline font-bold text-slate-900">{price}</span>
                      <span className="text-slate-400 text-sm">/mo</span>
                    </div>
                  ) : (
                    <span className="text-4xl font-headline font-bold text-slate-900">Custom</span>
                  )}
                  {yearly && price && (
                    <p className="text-xs text-slate-400 font-mono mt-1">Billed ${(price*12).toLocaleString()}/year</p>
                  )}
                </div>
                <ul className="space-y-3 flex-1 mb-8">
                  {p.features.map(f=>(
                    <li key={f.text} className={`flex items-start gap-3 text-sm ${f.included ? 'text-slate-700' : 'text-slate-300'}`}>
                      <span className={`material-symbols-outlined text-base flex-shrink-0 mt-0.5 ${f.included ? 'text-[#00D4AA] font-fill' : 'text-slate-300'}`}>
                        {f.included ? 'check_circle' : 'cancel'}
                      </span>
                      {f.text}
                    </li>
                  ))}
                </ul>
                <button className={`py-3 rounded-xl font-bold text-sm transition-all active:scale-95 w-full
                  ${p.highlight
                    ? 'bg-[#00D4AA] text-white hover:opacity-90 shadow-lg'
                    : p.id === 'enterprise'
                    ? 'border border-slate-200 text-slate-700 hover:bg-slate-50'
                    : 'border border-slate-900 text-slate-900 hover:bg-slate-50'}`}>
                  {p.cta}
                </button>
              </div>
            )
          })}
        </div>

        {/* Trust row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-8 border-y border-slate-200">
          <div className="flex items-center gap-4">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Trusted Transaction Partner</div>
            <div className="flex items-center gap-3">
              <span className="font-headline font-bold text-slate-900 text-lg">Stripe</span>
              <div className="flex items-center gap-1 text-green-600 text-xs font-bold bg-green-50 border border-green-200 px-2 py-1 rounded">
                <span className="material-symbols-outlined text-sm font-fill">verified_user</span>
                PCI-DSS Level 1 Security
              </div>
            </div>
          </div>
          <div className="flex items-center justify-end gap-4">
            <div className="text-right">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Enterprise Support</div>
              <div className="text-sm font-mono text-slate-700">concierge@castahead.io</div>
              <div className="text-[10px] text-slate-400">Average response: 45 mins</div>
            </div>
            <div className="w-10 h-10 bg-[#00D4AA] rounded-full flex items-center justify-center">
              <span className="material-symbols-outlined text-white text-xl">chat</span>
            </div>
          </div>
        </div>

        {/* FAQ */}
        <div>
          <h3 className="font-headline text-3xl font-bold text-slate-900 text-center mb-10">Frequently Asked Questions</h3>
          <div className="max-w-2xl mx-auto space-y-3">
            {FAQS.map((f,i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-xl overflow-hidden card-shadow">
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-6 py-5 text-left hover:bg-slate-50 transition-colors">
                  <span className="font-body font-bold text-slate-800 text-sm">{f.q}</span>
                  <span className={`material-symbols-outlined text-slate-400 transition-transform ${openFaq===i ? 'rotate-45' : ''}`}>add</span>
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-5 text-sm text-slate-500 leading-relaxed border-t border-slate-100 pt-4">
                    {f.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>
    </AppLayout>
  )
}
