import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import AppLayout from '../components/AppLayout'
import Spinner from '../components/Spinner'
import { getDemandTrend } from '../utils/api'
import { useApp } from '../context/AppContext'

const REGION_TABS = ['All Regions', 'North', 'South', 'East', 'West']

const REC_CONFIG = {
  'ORDER NOW':  'bg-red-600 text-white',
  'EXPEDITE':   'bg-amber-500 text-white',
  'HOLD STOCK': 'bg-slate-200 text-slate-700',
}

function getWeekRange() {
  const now = new Date()
  const startOfWeek = new Date(now)
  startOfWeek.setDate(now.getDate() - now.getDay() + 1) // Monday
  const endOfWeek = new Date(startOfWeek)
  endOfWeek.setDate(startOfWeek.getDate() + 6)
  const fmt = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  return `${fmt(startOfWeek)} — ${fmt(endOfWeek)}, ${now.getFullYear()}`
}

export default function InventoryDashboard() {
  // SKUs come exclusively from shared context — no duplicate fetch
  const { skus, skusLoading, setSelectedSku } = useApp()
  const [activeTab,    setActiveTab]    = useState('All Regions')
  const [trendData,    setTrendData]    = useState([])
  const [trendLoading, setTrendLoading] = useState(true)
  const navigate = useNavigate()

  // Fetch aggregate demand trend from the backend
  useEffect(() => {
    getDemandTrend()
      .then(r => { setTrendData(r.data.trend); setTrendLoading(false) })
      .catch(() => setTrendLoading(false))
  }, [])

  const filtered = activeTab === 'All Regions'
    ? skus
    : skus.filter(s => s.region === activeTab)

  const counts = {
    on_track:  skus.filter(s => s.status === 'ON_TRACK').length,
    attention: skus.filter(s => s.status === 'NEEDS_ATTENTION').length,
    risk:      skus.filter(s => s.status === 'AT_RISK').length,
  }

  const handleView = (sku) => { setSelectedSku(sku); navigate(`/forecast/${sku.sku_id}`) }

  return (
    <AppLayout topTitle="Operational Dashboard">
      <div className="p-10 space-y-12 max-w-[1400px] mx-auto w-full">

        {/* Header */}
        <section className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold font-headline leading-tight tracking-tight text-slate-900">
              Good morning —<br />here's your demand outlook for this week.
            </h2>
            <div className="mt-6 inline-flex items-center gap-2 px-3 py-1.5 bg-white rounded border border-slate-200 shadow-sm">
              <span className="material-symbols-outlined text-sm text-[#006b55]">calendar_today</span>
              <span className="text-xs font-mono text-slate-600 uppercase tracking-wider">{getWeekRange()}</span>
            </div>
          </div>
          <button
            onClick={() => navigate('/forecast')}
            className="flex items-center gap-2 px-5 py-2.5 text-white bg-[#006b55] rounded shadow-md hover:bg-[#00513f] transition-all text-sm font-bold self-start">
            <span className="material-symbols-outlined text-lg">add</span>Add SKU
          </button>
        </section>

        {/* Summary Cards */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { key: 'on_track',  label: 'Inventory Health',        count: counts.on_track,  sub: 'On Track',        border: '#006b55', icon: 'check_circle', subColor: 'text-green-600' },
            { key: 'attention', label: 'Replenishment Alert',     count: counts.attention, sub: 'Needs Attention',  border: '#F59E0B', icon: 'warning',       subColor: 'text-amber-600' },
            { key: 'risk',      label: 'Critical Stock-Out Risk', count: counts.risk,      sub: 'Action Required', border: '#BA1A1A', icon: 'error',         subColor: 'text-red-600' },
          ].map(c => (
            <div key={c.key} className="bg-white p-8 border border-slate-200 rounded-lg card-shadow hover:shadow-md transition-shadow relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full" style={{ background: c.border }} />
              <p className="text-[10px] font-label font-bold text-slate-500 uppercase tracking-[0.2em] mb-4">{c.label}</p>
              <div className="flex items-baseline gap-2 mb-3">
                <span className="text-5xl font-headline font-bold text-slate-900">{c.count}</span>
                <span className="text-xl text-slate-400 font-label">SKUs</span>
              </div>
              <div className={`flex items-center gap-1.5 text-sm font-bold ${c.subColor}`}>
                <span className="material-symbols-outlined text-base font-fill">{c.icon}</span>
                {c.sub}
              </div>
            </div>
          ))}
        </section>

        {/* Region Tabs + SKU Table */}
        <section className="bg-white rounded-2xl border border-slate-200 card-shadow overflow-hidden">
          {/* Tabs */}
          <div className="border-b border-slate-200 px-6 pt-4 flex gap-1">
            {REGION_TABS.map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`px-4 py-2.5 text-sm font-bold rounded-t-lg transition-all ${
                  activeTab === tab
                    ? 'text-[#006b55] border-b-2 border-[#006b55] bg-white'
                    : 'text-slate-500 hover:text-slate-700'
                }`}>{tab}</button>
            ))}
          </div>

          {skusLoading ? <Spinner text="Loading SKUs…" /> : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-100">
                    {['Product Name', 'Current Stock', 'Forecasted Demand (4W)', 'Key Risk Factor', 'Recommendation', 'Action'].map(h => (
                      <th key={h} className="px-6 py-4 text-[10px] font-label font-bold text-slate-400 uppercase tracking-[0.15em] text-left">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="px-6 py-12 text-center text-slate-400 font-mono text-sm">
                        No SKUs found in this region.
                      </td>
                    </tr>
                  ) : filtered.map(sku => (
                    <tr key={sku.sku_id} className="border-b border-slate-50 hover:bg-slate-50/80 transition-colors group">
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-[#006b55]/10 flex items-center justify-center">
                            <span className="material-symbols-outlined text-[#006b55] text-base">inventory_2</span>
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 text-sm">{sku.name}</p>
                            <p className="text-[11px] text-slate-400 font-mono">{sku.category} • {sku.sku_id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5">
                        <span className="font-mono font-bold text-slate-900">{sku.current_stock.toLocaleString()}</span>
                        <span className="text-xs text-slate-400 ml-1">units</span>
                      </td>
                      <td className="px-6 py-5 min-w-[180px]">
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-1">
                          <div
                            className="h-full bg-[#006b55] rounded-full transition-all"
                            style={{ width: `${Math.min(100, (sku.reorder_qty / Math.max(sku.current_stock, 1)) * 100 + 30)}%` }}
                          />
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono">
                          {Math.round(sku.current_stock * 0.6).toLocaleString()} – {Math.round(sku.current_stock * 0.9).toLocaleString()} units
                        </p>
                      </td>
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-2 text-sm text-slate-600">
                          <span className="material-symbols-outlined text-amber-500 text-base">bolt</span>
                          {sku.key_risk_factor}
                        </div>
                      </td>
                      <td className="px-6 py-5">
                        <span className={`inline-block px-3 py-1.5 rounded font-bold text-[10px] uppercase tracking-widest ${REC_CONFIG[sku.recommendation] || 'bg-slate-100 text-slate-600'}`}>
                          {sku.recommendation}
                          {sku.reorder_qty > 0 && ` — ~${sku.reorder_qty} units`}
                        </span>
                      </td>
                      <td className="px-6 py-5">
                        <button
                          onClick={() => handleView(sku)}
                          className="text-[#006b55] font-bold text-sm hover:underline group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                          View Details
                          <span className="material-symbols-outlined text-sm">arrow_forward</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Total Demand Trend Chart — data from backend */}
        <section className="bg-white rounded-2xl border border-slate-200 p-8 card-shadow">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="font-headline font-bold text-xl text-slate-900">Total Demand Trend</h3>
              <p className="text-sm text-slate-500 mt-1">Consolidated network performance against predictive baseline</p>
            </div>
            <div className="flex items-center gap-6 text-[10px] font-bold uppercase tracking-widest text-slate-400">
              <div className="flex items-center gap-2"><div className="w-6 h-0.5 bg-slate-300" />Historical</div>
              <div className="flex items-center gap-2"><div className="w-6 h-0.5 bg-[#00D4AA] border-dashed border-t-2" />Forecast</div>
            </div>
          </div>

          {trendLoading ? (
            <Spinner text="Loading trend data…" />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={trendData} margin={{ top: 20, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#94a3b8" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#94a3b8" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="foreGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#00D4AA" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#00D4AA" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="4 4" stroke="#f1f5f9" />
                <XAxis dataKey="week" tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#94a3b8' }} />
                <YAxis tick={{ fontSize: 9, fontFamily: 'JetBrains Mono', fill: '#94a3b8' }} tickFormatter={(v)=>Number(v).toLocaleString()} />
                <Tooltip
                  contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 11, fontFamily: 'Manrope' }}
                  formatter={(value, name) => [value?.toLocaleString() ?? '—', name === 'historical' ? 'Historical' : 'Forecast']}
                />
                <Area type="monotone" dataKey="historical" stroke="#94a3b8" fill="url(#histGrad)" strokeWidth={2} dot={false} connectNulls={false} />
                <Area type="monotone" dataKey="forecast"   stroke="#00D4AA" fill="url(#foreGrad)" strokeWidth={2.5} strokeDasharray="6 3" dot={{ r: 4, fill: '#006b55' }} connectNulls={false} />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </section>

      </div>
    </AppLayout>
  )
}
