import { useNavigate } from 'react-router-dom'

const STEPS = [
  { num:'01', title:'Add Products', desc:'Sync your existing inventory and sales data in minutes. No manual entry required.' },
  { num:'02', title:'Statistical Feature Processing', desc:'Our systems process billions of data points to isolate significant trends and filter statistical noise.' },
  { num:'03', title:'Get Recommendations', desc:'Wake up to clear, actionable advice on what to stock, what to hold, and what to promote.' },
]

const FEATURES = [
  { icon:'inventory_2', title:'Know Your Demand', desc:'Our statistically trained model analyses historical data and external market signals to predict your next peak with 96% accuracy.' },
  { icon:'warning',     title:'React to Disruptions', desc:'CastAhead warns you before the impact hits your bottom line — supply chain delays, shifts in consumer behavior.' },
  { icon:'lightbulb',   title:'Clear Recommendations', desc:'No more "Wait and see." Get actionable restock numbers and pricing adjustments delivered to your dashboard daily.' },
]

const PLANS = [
  { name:'STARTER', price:'$49', period:'/mo', features:['Up to 500 SKUs','Weekly Forecasts','Inventory Health Dashboard'], cta:'Get Started', highlight:false },
  { name:'PRO',     price:'$199',period:'/mo', features:['Unlimited SKUs','Real-time Analysis','Scenario Planner','API Access'], cta:'Start 14-Day Trial', highlight:true },
  { name:'ENTERPRISE', price:'Custom', period:'', features:['Custom Models','Dedicated Consultant','On-prem Deployment'], cta:'Contact Sales', highlight:false },
]

const NAV_ITEMS = [
  { label:'Home', path:'/' },
  { label:'Inventory Dashboard', path:'/dashboard' },
  { label:'Demand Forecast Detail', path:'/forecast' },
  { label:'Scenario Planner', path:'/scenario' },
  { label:'Plans & Pricing', path:'/pricing' },
]

export default function LandingPage() {
  const navigate = useNavigate()
  return (
    <div className="min-h-screen bg-white font-body">

      {/* NAV */}
      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-slate-100 px-8 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="font-headline font-bold text-[#00D4AA] text-xl">CastAhead</span>
          <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest border border-slate-200 px-2 py-0.5 rounded">Statistical Model</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
          {NAV_ITEMS.map((item) => (
            <button key={item.label} onClick={() => navigate(item.path)}
              className="hover:text-[#00D4AA] transition-colors">{item.label}</button>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <button className="text-sm font-bold text-slate-700 hover:text-[#006b55] transition-colors">Log in</button>
          <button onClick={()=>navigate('/pricing')}
            className="px-4 py-2 bg-[#00D4AA] text-white text-sm font-bold rounded hover:opacity-90 transition-opacity">
            Pro Plan →
          </button>
        </div>
      </nav>

      {/* HERO */}
      <section className="max-w-6xl mx-auto px-8 pt-24 pb-16 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-full text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-6">
            Statistical Logistics Forecasting
          </div>
          <h1 className="font-headline text-5xl lg:text-6xl font-bold leading-tight tracking-tight text-slate-900 mb-6">
            Stop Guessing.<br/>
            <span className="text-[#00D4AA]">Start Forecasting.</span>
          </h1>
          <p className="text-slate-500 text-lg leading-relaxed mb-10 max-w-md">
            CastAhead calculates exactly how much to stock — and identifies variance before demand shifts happen. Precision data. No complex spreadsheets. Just pure statistical clarity.
          </p>
          <div className="flex flex-wrap gap-4">
            <button onClick={()=>navigate('/pricing')}
              className="flex items-center gap-2 px-8 py-3.5 bg-[#00D4AA] text-white font-bold rounded hover:opacity-90 transition-all shadow-lg shadow-[#00D4AA]/20 active:scale-95">
              Start Free Trial
              <span className="material-symbols-outlined text-lg">arrow_forward</span>
            </button>
            <button onClick={()=>document.getElementById('how').scrollIntoView({behavior:'smooth'})}
              className="px-8 py-3.5 border border-slate-200 text-slate-700 font-bold rounded hover:bg-slate-50 transition-all active:scale-95">
              See How It Works
            </button>
          </div>
        </div>

        {/* Hero chart mockup */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xl p-6 card-shadow-md">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">Predicted Demand vs. Actuals</span>
            <span className="text-xs font-bold text-[#00D4AA] bg-[#00D4AA]/10 px-2 py-1 rounded">96.2% Conf.</span>
          </div>
          {/* Simple SVG preview chart */}
          <svg viewBox="0 0 400 160" className="w-full h-32">
            <defs>
              <linearGradient id="heroGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" style={{stopColor:'#00D4AA',stopOpacity:0.15}} />
                <stop offset="100%" style={{stopColor:'#00D4AA',stopOpacity:0}} />
              </linearGradient>
            </defs>
            {[40,80,120].map(y=>(
              <line key={y} x1="0" x2="400" y1={y} y2={y} stroke="#f1f5f9" strokeWidth="1" />
            ))}
            <path d="M0,110 L50,95 L100,105 L150,80 L200,90 L250,65 L300,75 L350,55 L400,60"
                  fill="url(#heroGrad)" stroke="none" />
            <path d="M0,110 L50,95 L100,105 L150,80 L200,90 L250,65 L300,75 L350,55 L400,60"
                  fill="none" stroke="#00D4AA" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M0,115 L50,100 L100,108 L150,88 L200,96 L250,72 L300,82 L350,62 L400,68"
                  fill="none" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="5,3" />
            <circle cx="250" cy="65" r="4" fill="#006b55" />
            <text x="260" y="58" fontSize="8" fill="#006b55" fontFamily="monospace" fontWeight="bold">+12.4%</text>
          </svg>
          <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-slate-100">
            {[['Total Confidence','0.842'],['Trend Index','1.219'],['WMAPE','8.7%']].map(([k,v])=>(
              <div key={k}>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{k}</p>
                <p className="text-base font-mono font-bold text-slate-900">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRECISION INTELLIGENCE */}
      <section className="bg-slate-50 py-24 px-8">
        <div className="max-w-5xl mx-auto">
          <div className="mb-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Platform Capabilities</div>
          <h2 className="font-headline text-4xl font-bold text-slate-900 mb-3">Precision Intelligence</h2>
          <p className="text-slate-500 mb-12">Moving beyond standard grids into structured behavioral insights.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {FEATURES.map(f=>(
              <div key={f.title} className="bg-white p-8 rounded-xl border border-slate-200 card-shadow hover:shadow-md transition-shadow">
                <span className="material-symbols-outlined text-[#00D4AA] text-2xl mb-4 block">{f.icon}</span>
                <h3 className="font-headline font-bold text-slate-900 text-lg mb-3">{f.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{f.desc}</p>
                <div className="mt-6 w-12 h-1 bg-[#00D4AA] rounded-full" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="py-24 px-8 max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <h2 className="font-headline text-4xl font-bold text-slate-900 mb-10">How our Forecasting Works</h2>
          <div className="space-y-8">
            {STEPS.map((s,i)=>(
              <div key={s.num} className="flex gap-5">
                <div className="flex-shrink-0 w-8 h-8 bg-[#006b55] text-white font-mono font-bold text-xs rounded flex items-center justify-center">{String(i+1).padStart(2,'0')}</div>
                <div>
                  <h4 className="font-headline font-bold text-slate-900 uppercase tracking-widest text-xs mb-1">{s.title}</h4>
                  <p className="text-sm text-slate-500 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* Pipeline visual */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 card-shadow-md space-y-3">
          {[
            {label:'Sales + Weather + Trends',color:'bg-[#00D4AA]',w:'w-[100%]',status:'VALIDATED'},
            {label:'Feature Engineering',     color:'bg-[#0062A0]',w:'w-[80%]', status:'PROCESSING'},
            {label:'Ensemble Model Output',   color:'bg-[#006b55]',w:'w-[60%]', status:'VALIDATING'},
          ].map(r=>(
            <div key={r.label}>
              <div className="flex justify-between text-[9px] font-mono font-bold text-slate-500 uppercase tracking-widest mb-1">
                <span>{r.label}</span><span className="text-[#00D4AA]">{r.status}</span>
              </div>
              <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className={`h-full ${r.color} ${r.w} rounded-full transition-all duration-1000`} />
              </div>
            </div>
          ))}
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-100">
            {[['Total Confidence','0.842'],['Trend Index','1.219']].map(([k,v])=>(
              <div key={k}><p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{k}</p>
              <p className="text-lg font-mono font-bold text-slate-900">{v}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section className="bg-slate-900 py-24 px-8">
        <div className="max-w-5xl mx-auto text-center mb-12">
          <h2 className="font-headline text-4xl font-bold text-white mb-3">Built for Every Scale</h2>
          <p className="text-slate-400">From boutique brands to global enterprises, our forecasting systems scale with you.</p>
        </div>
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
          {PLANS.map(p=>(
            <div key={p.name}
              className={`rounded-2xl p-8 flex flex-col ${p.highlight ? 'bg-white border-2 border-[#00D4AA] shadow-2xl shadow-[#00D4AA]/20 scale-105' : 'bg-slate-800 border border-slate-700'}`}>
              {p.highlight && <div className="text-[10px] font-bold text-[#00D4AA] uppercase tracking-widest mb-4">⭐ Recommended</div>}
              <div className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${p.highlight ? 'text-slate-500' : 'text-slate-400'}`}>{p.name}</div>
              <div className={`font-headline font-bold mb-6 ${p.highlight ? 'text-slate-900' : 'text-white'}`}>
                <span className="text-4xl">{p.price}</span>
                <span className={`text-sm ${p.highlight ? 'text-slate-500' : 'text-slate-400'}`}>{p.period}</span>
              </div>
              <ul className="space-y-3 flex-1 mb-8">
                {p.features.map(f=>(
                  <li key={f} className={`flex items-center gap-2 text-sm ${p.highlight ? 'text-slate-700' : 'text-slate-300'}`}>
                    <span className="material-symbols-outlined text-[#00D4AA] text-base font-fill">check_circle</span>
                    {f}
                  </li>
                ))}
              </ul>
              <button onClick={()=>navigate('/pricing')}
                className={`py-3 rounded font-bold text-sm transition-all active:scale-95 ${p.highlight ? 'bg-[#00D4AA] text-white hover:opacity-90 shadow-lg' : 'bg-slate-700 text-white hover:bg-slate-600 border border-slate-600'}`}>
                {p.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="bg-[#006b55] py-20 px-8 text-center">
        <h2 className="font-headline text-4xl font-bold text-white mb-4">Ready to see the future of your business?</h2>
        <div className="flex justify-center gap-4 mt-8">
          <button onClick={()=>navigate('/pricing')}
            className="px-8 py-3.5 bg-[#00D4AA] text-white font-bold rounded hover:opacity-90 transition-all">
            Get Started Today
          </button>
          <button className="px-8 py-3.5 border border-white/30 text-white font-bold rounded hover:bg-white/10 transition-all">
            Speak with an Expert
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 py-12 px-8">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2">
            <h3 className="font-headline font-bold text-[#00D4AA] text-lg mb-2">CastAhead</h3>
            <p className="text-sm leading-relaxed">The Standard in Demand Forecasting Models for the modern supply chain. We turn uncertainty into strategic advantage.</p>
          </div>
          {[
            ['Platform', [
              { label:'Dashboard',    to:'/dashboard' },
              { label:'Forecasting',  to:'/forecast' },
              { label:'Scenario',     to:'/scenario' },
              { label:'Integrations', to:'/pricing' },
            ]],
            ['Company', [
              { label:'Our Story',   to:null },
              { label:'Methodology', to:null },
              { label:'Careers',     to:null },
              { label:'Contact',     href:'mailto:concierge@castahead.io' },
            ]],
            ['Legal', [
              { label:'Privacy',  to:null },
              { label:'Terms',    to:null },
              { label:'Security', to:null },
            ]],
          ].map(([title, links]) => (
            <div key={title}>
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-3">{title}</h4>
              <ul className="space-y-2">
                {links.map(l => (
                  <li key={l.label}>
                    {l.to ? (
                      <button onClick={() => navigate(l.to)}
                        className="text-sm hover:text-[#00D4AA] transition-colors text-left text-slate-400">
                        {l.label}
                      </button>
                    ) : l.href ? (
                      <a href={l.href} className="text-sm hover:text-[#00D4AA] transition-colors">
                        {l.label}
                      </a>
                    ) : (
                      <span className="text-sm text-slate-600">{l.label}</span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="max-w-5xl mx-auto mt-10 pt-6 border-t border-slate-800 flex justify-between items-center text-xs">
          <span>© 2026 CastAhead Analytics Inc. All rights reserved.</span>
          <span className="text-[#00D4AA] font-mono font-bold">● SYSTEM OPERATIONAL</span>
        </div>
      </footer>
    </div>
  )
}
