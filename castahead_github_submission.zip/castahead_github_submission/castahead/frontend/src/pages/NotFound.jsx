import { useNavigate } from 'react-router-dom'

export default function NotFound() {
  const navigate = useNavigate()
  return (
    <div className="min-h-screen bg-[#f2f4f6] flex flex-col items-center justify-center gap-6 font-body">
      <span className="font-headline font-bold text-[#00D4AA] text-2xl">CastAhead</span>
      <h1 className="text-6xl font-headline font-bold text-slate-900">404</h1>
      <p className="text-slate-500 text-lg">This page doesn't exist in the forecast.</p>
      <button onClick={() => navigate('/')}
        className="px-8 py-3 bg-[#006b55] text-white font-bold rounded-xl hover:bg-[#00513f] transition-all">
        ← Back to Home
      </button>
    </div>
  )
}
