import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ComposedChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts'
import AppLayout from '../components/AppLayout'
import Spinner from '../components/Spinner'
import { getScenarios, simulate } from '../utils/api'
import { useApp } from '../context/AppContext'

const TYPE_CONFIG = {
  SUPPLY_DISRUPTION: { badge:'bg-red-50 text-red-700 border border-red-200', bar:'bg-red-500', hover:'hover:bg-red-500 hover:text-white' },
  WEATHER_EVENT:     { badge:'bg-[#006b55]/10 text-[#006b55] border border-[#006b55]/20', bar:'bg-[#006b55]', hover:'hover:bg-[#006b55] hover:text-white' },
  MARKET_SHIFT:      { badge:'bg-amber-50 text-amber-700 border border-amber-200', bar:'bg-amber-500', hover:'hover:bg-amber-500 hover:text-white' },
}

const TYPE_ICONS = { SUPPLY_DISRUPTION:'📦', WEATHER_EVENT:'☀️', MARKET_SHIFT:'📢' }

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-slate-900 text-white p-3 rounded-lg shadow-2xl text-xs font-mono">
      <p className="text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      {payload.map(p => p.value != null && (
        <p key={p.dataKey} style={{color:p.color}}>{p.name}: <strong>{Math.round(p.value)}</strong></p>
      ))}
    </div>
  )
}

export default function ScenarioPlanner() {
  const { skuId: urlSkuId } = useParams()
  const navigate = useNavigate()
  const { selectedSku, skus, setSelectedSku } = useApp()
  const [scenarios,   setScenarios]   = useState([])
  const [activeId,    setActiveId]    = useState(null)
  const [simResult,   setSimResult]   = useState(null)
  const [simLoading,  setSimLoading]  = useState(false)
  const [initLoading, setInitLoading] = useState(true)

  // Resolve SKU from URL param, context, or first in list
  const resolvedSkuId = urlSkuId || selectedSku?.sku_id || (skus.length > 0 ? skus[0].sku_id : null)
  const currentSku = skus.find(s => s.sku_id === resolvedSkuId) || selectedSku

  useEffect(() => {
    let cancelled = false
    setInitLoading(true)
    const skuParam = resolvedSkuId || undefined
    getScenarios(skuParam)
      .then(r => {
        if (cancelled) return
        setScenarios(r.data.scenarios || [])
        setInitLoading(false)
      })
      .catch(() => {
        if (cancelled) return
        setScenarios([])
        setInitLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [resolvedSkuId])

  // Reset simulation when SKU changes
  useEffect(() => {
    setSimResult(null)
    setActiveId(null)
  }, [resolvedSkuId])

  const handleSimulate = async (scenarioId) => {
    if (!resolvedSkuId) return
    setActiveId(scenarioId)
    setSimLoading(true)
    setSimResult(null)
    try {
      const r = await simulate({ sku_id: resolvedSkuId, scenario_id: scenarioId, horizon: 12 })
      setSimResult(r.data)
    } catch { setSimResult(null) }
    setSimLoading(false)
  }

  const handleSkuChange = (newSkuId) => {
    const s = skus.find(x => x.sku_id === newSkuId)
    if (s) setSelectedSku(s)
    navigate(`/scenario/${newSkuId}`)
  }

  const chartData = simResult
    ? simResult.dates.map((d, i) => ({
        label: `W${i+1}`,
        baseline:  simResult.baseline_forecast[i],
        simulated: simResult.simulated_forecast[i],
        delta:     simResult.delta_pct?.[i],
      }))
    : []

  const sc = simResult?.scenario_meta
  const riskColor = {
    High:     'text-red-600',
    Moderate: 'text-amber-600',
    Low:      'text-green-600',
  }[simResult?.stockout_risk] || 'text-slate-900'

  return (
    <AppLayout topTitle="Scenario Planner">
      <div className="p-10 space-y-12 max-w-[1400px] mx-auto w-full">

        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-3xl">
            <h2 className="text-4xl md:text-5xl font-bold font-headline leading-tight tracking-tight text-slate-900 mb-4">
              Past Demand Shocks — Learn from History
            </h2>
            <p className="text-slate-500 text-lg leading-relaxed font-body">
              CastAhead detected these real events from your product's demand history. Select one to simulate what would happen if it occurred again today.
            </p>
          </div>
          {currentSku && (
            <div className="bg-white p-1 rounded-xl shadow-sm border border-slate-200 flex items-center gap-4 pl-4 h-fit">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Active SKU</span>
                <span className="text-sm font-bold text-[#0062A0]">{currentSku.name} · {currentSku.region} Region</span>
              </div>
              {skus.length > 1 && (
                <select
                  value={resolvedSkuId}
                  onChange={e => handleSkuChange(e.target.value)}
                  className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 font-mono text-slate-600 bg-slate-50 focus:outline-none focus:border-[#00D4AA]">
                  {skus.map(s => <option key={s.sku_id} value={s.sku_id}>{s.name}</option>)}
                </select>
              )}
            </div>
          )}
        </div>

        {/* SCENARIO CARDS */}
        <section>
          <div className="flex items-center gap-4 mb-8">
            <h3 className="text-xl font-headline font-bold text-slate-800">Events That Moved Your Demand</h3>
            <div className="h-px flex-grow bg-slate-200" />
          </div>

          {initLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[0, 1, 2].map(i => (
                <div key={i} className="bg-white rounded-xl p-8 border border-slate-200 shadow-sm animate-pulse">
                  <div className="flex justify-between items-start mb-6">
                    <div className="h-5 w-28 bg-slate-100 rounded-full" />
                    <div className="h-4 w-20 bg-slate-100 rounded-full" />
                  </div>
                  <div className="h-6 w-3/4 bg-slate-200 rounded mb-3" />
                  <div className="space-y-2 mb-8">
                    <div className="h-3 bg-slate-100 rounded w-full" />
                    <div className="h-3 bg-slate-100 rounded w-5/6" />
                    <div className="h-3 bg-slate-100 rounded w-4/6" />
                  </div>
                  <div className="h-10 bg-slate-100 rounded-lg w-full" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {scenarios.map(s => {
                const cfg = TYPE_CONFIG[s.type] || TYPE_CONFIG.MARKET_SHIFT
                const isActive = activeId === s.id
                return (
                  <div key={s.id}
                    className={`group bg-white rounded-xl p-8 border shadow-sm hover:shadow-md transition-all flex flex-col h-full relative overflow-hidden cursor-pointer
                      ${isActive ? 'border-2 border-[#006b55] shadow-lg' : 'border-slate-200'}`}
                    onClick={() => handleSimulate(s.id)}>
                    <div className={`absolute top-0 left-0 w-1.5 h-full ${cfg.bar}`} />
                    <div className="flex justify-between items-start mb-6">
                      <div className="flex items-center gap-3">
                        <span className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.15em] rounded ${cfg.badge}`}>
                          {TYPE_ICONS[s.type]} {s.label}
                        </span>
                        {s.applicable === false ? (
                          <span className="text-[10px] text-slate-400 italic">Not typical for this SKU</span>
                        ) : null}
                      </div>
                      <div className="flex items-start gap-4">
                        <span className="text-[10px] font-mono font-bold text-slate-400">{s.date_range}</span>
                        {s.accuracy_pct != null && (
                          <span className="text-[10px] font-mono font-bold text-slate-500">{s.accuracy_pct}% acc.</span>
                        )}
                      </div>
                    </div>
                    <h4 className="text-xl font-headline font-bold text-slate-900 mb-3">{s.title}</h4>
                    <p className="text-sm text-slate-500 font-body mb-8 flex-grow">{s.description}</p>
                    <button
                      className={`w-full py-3 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-2 uppercase tracking-widest
                        ${isActive
                          ? `${cfg.bar} text-white shadow-md`
                          : `bg-slate-50 border border-slate-100 text-slate-600 ${cfg.hover}`}`}>
                      {isActive && simLoading
                        ? <><div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"/><span>Simulating…</span></>
                        : isActive
                        ? <><span>Currently Simulating</span><span className="material-symbols-outlined text-sm font-fill">check_circle</span></>
                        : <><span>Simulate this impact</span><span className="material-symbols-outlined text-sm">
                            {s.type === 'SUPPLY_DISRUPTION' ? 'trending_down' : s.type === 'WEATHER_EVENT' ? 'wb_sunny' : 'analytics'}
                          </span></>}
                    </button>
                  </div>
                )
              })}
            </div>
          )}
        </section>

        {/* SIMULATION RESULTS */}
        {(simResult || simLoading) && (
          <section className="bg-white rounded-xl p-10 shadow-sm border border-slate-200 relative overflow-hidden">
            <div className="flex flex-col md:flex-row justify-between items-start mb-8 gap-4">
              <div>
                <h3 className="text-2xl font-headline font-bold text-slate-900">
                  Simulation Results: {sc?.title || '…'}
                </h3>
                <p className="text-sm text-slate-500 font-medium mt-1">
                  Statistical Forecaster projection based on detected historical pattern for <span className="font-bold text-slate-700">{currentSku?.name || resolvedSkuId}</span>.
                </p>
              </div>
              <div className="flex items-center gap-6 px-5 py-2.5 bg-slate-50 rounded-full border border-slate-100 shadow-inner">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-0.5 bg-slate-300 border-t border-dashed" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Baseline Forecast</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-1 bg-[#006b55] rounded-full" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#006b55]">Simulated Impact</span>
                </div>
              </div>
            </div>

            {simLoading
              ? <div className="h-72 flex items-center justify-center"><Spinner text="Running simulation…" /></div>
              : (
              <>
                {/* Chart */}
                <div className="w-full h-72 bg-slate-50/50 rounded-xl border border-slate-100 mb-10 overflow-hidden">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={chartData} margin={{top:20,right:20,left:-10,bottom:0}}>
                      <CartesianGrid strokeDasharray="4 4" stroke="#f1f5f9" />
                      <XAxis dataKey="label" tick={{fontSize:9,fontFamily:'JetBrains Mono',fill:'#94a3b8'}} />
                      <YAxis tick={{fontSize:9,fontFamily:'JetBrains Mono',fill:'#94a3b8'}} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="baseline"  stroke="#94a3b8" strokeWidth={2} strokeDasharray="7 3" dot={false} name="Baseline" />
                      <Line type="monotone" dataKey="simulated" stroke="#006b55" strokeWidth={3.5} dot={{r:4,fill:'#006b55'}} strokeLinecap="round" name="Simulated" />
                      {sc?.duration_weeks && (
                        <ReferenceLine x={`W${sc.duration_weeks}`} stroke="#F59E0B" strokeDasharray="4 3"
                          label={{value:'IMPACT ENDS',position:'insideTopRight',fontSize:8,fill:'#F59E0B'}} />
                      )}
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>

                {/* KPI Bento */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-slate-50/80 p-8 rounded-xl border border-slate-100 relative overflow-hidden group">
                    <div className="absolute top-0 left-0 w-1 h-full bg-[#006b55] opacity-50 group-hover:opacity-100 transition-opacity" />
                    <div className="flex items-center gap-2 mb-4">
                      <span className="material-symbols-outlined text-[#006b55] text-xl">trending_up</span>
                      <span className="font-label text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Demand Impact</span>
                    </div>
                    <div className="flex items-baseline gap-2">
                      <span className={`text-5xl font-headline font-bold ${(simResult?.demand_impact_pct||0) >= 0 ? 'text-slate-900' : 'text-red-600'}`}>
                        {(simResult?.demand_impact_pct||0) >= 0 ? '+' : ''}{simResult?.demand_impact_pct || 0}%
                      </span>
                      <span className="text-xs font-mono text-[#006b55] font-bold bg-[#006b55]/10 px-1.5 py-0.5 rounded">vs Baseline</span>
                    </div>
                  </div>

                  <div className="bg-slate-50/80 p-8 rounded-xl border border-slate-100 relative overflow-hidden group">
                    <div className={`absolute top-0 left-0 w-1 h-full opacity-50 group-hover:opacity-100 transition-opacity ${simResult?.stockout_risk === 'High' ? 'bg-red-500' : 'bg-amber-400'}`} />
                    <div className="flex items-center gap-2 mb-4">
                      <span className={`material-symbols-outlined text-xl ${simResult?.stockout_risk === 'High' ? 'text-red-600' : 'text-amber-500'}`}>warning</span>
                      <span className="font-label text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Stockout Risk</span>
                    </div>
                    <div className="flex items-baseline gap-2">
                      <span className={`text-5xl font-headline font-bold ${riskColor}`}>{simResult?.stockout_risk}</span>
                      <span className="text-xs font-medium text-slate-500 ml-2">{Math.round((simResult?.stockout_prob||0)*100)}% Prob.</span>
                    </div>
                  </div>

                  <div className="bg-white p-8 rounded-xl border-2 border-[#006b55]/20 shadow-sm flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="material-symbols-outlined text-[#0062A0] text-xl">inventory_2</span>
                      <span className="font-label text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Recommended Action</span>
                    </div>
                    <p className="text-lg font-headline font-bold text-slate-900 mb-3 leading-tight">
                      {simResult?.recommended_action}
                    </p>
                    {simResult?.safety_stock_increase > 0 && (
                      <p className="text-xs text-slate-500 font-mono mb-4">
                        +{simResult.safety_stock_increase} units safety stock buffer recommended
                      </p>
                    )}
                    <button
                      onClick={() => navigate(`/forecast/${resolvedSkuId}`)}
                      className="w-full py-2.5 bg-[#0062A0] text-white rounded font-bold text-[11px] hover:bg-[#0062A0]/90 transition-all uppercase tracking-[0.15em] shadow-sm active:scale-95">
                      Apply to Forecast
                    </button>
                  </div>
                </div>
              </>
            )}
          </section>
        )}

        {/* Statistical Note */}
        {simResult && !simLoading && (
          <div className="flex gap-5 items-start bg-white/50 p-6 rounded-xl border border-slate-200/50">
            <div className="w-10 h-10 shrink-0 bg-slate-200/50 flex items-center justify-center rounded-full text-slate-500">
              <span className="material-symbols-outlined text-xl">info</span>
            </div>
            <div>
              <h4 className="font-headline font-bold text-sm text-slate-800">Statistical Forecaster Note</h4>
              <p className="text-sm text-slate-500 max-w-4xl mt-1 leading-relaxed font-body">
                Simulation accuracy for <span className="font-bold text-slate-700">{sc?.title}</span> is rated{' '}
                <span className="font-bold">high ({simResult?.accuracy_pct}%)</span> based on prior correlations.{' '}
                {simResult?.accuracy_note}
              </p>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
