import { Routes, Route } from 'react-router-dom'
import { AppProvider } from './context/AppContext'
import LandingPage        from './pages/LandingPage'
import InventoryDashboard from './pages/InventoryDashboard'
import ForecastDetail     from './pages/ForecastDetail'
import ScenarioPlanner    from './pages/ScenarioPlanner'
import PricingPage        from './pages/PricingPage'
import NotFound           from './pages/NotFound'

export default function App() {
  return (
    <AppProvider>
      <Routes>
        <Route path="/"                  element={<LandingPage />} />
        <Route path="/dashboard"         element={<InventoryDashboard />} />
        <Route path="/forecast/:skuId?"  element={<ForecastDetail />} />
        <Route path="/scenario/:skuId?"  element={<ScenarioPlanner />} />
        <Route path="/pricing"           element={<PricingPage />} />
        <Route path="*"                  element={<NotFound />} />
      </Routes>
    </AppProvider>
  )
}
