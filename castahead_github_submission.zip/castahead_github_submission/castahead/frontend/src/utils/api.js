import axios from 'axios'

// In development, Vite proxy handles /api → http://localhost:8000
// In production, VITE_API_URL points to the deployed backend
const BASE = import.meta.env.VITE_API_URL || ''

const api = axios.create({ baseURL: BASE, timeout: 30000 })

// Response interceptor for consistent error handling
api.interceptors.response.use(
  response => response,
  error => {
    const msg = error.response?.data?.detail || error.message || 'Network error'
    console.error(`[CastAhead API] ${error.config?.method?.toUpperCase()} ${error.config?.url}: ${msg}`)
    return Promise.reject(error)
  }
)

export const getHealth      = ()              => api.get('/api/health')
export const getSkus        = ()              => api.get('/api/skus')
export const getSku         = (id)            => api.get(`/api/skus/${id}`)
export const getForecast    = (id, horizon=12)=> api.get(`/api/forecast/${id}?horizon=${horizon}`)
export const getScenarios   = (sku_id)        => api.get('/api/scenarios', { params: sku_id ? { sku_id } : {} })
export const simulate       = (body)          => api.post('/api/scenario/simulate', body)
export const narrate        = (body)          => api.post('/api/narrate', body)
export const getDemandTrend = ()              => api.get('/api/analytics/demand-trend')
export const getModelAccuracy = ()            => api.get('/api/analytics/model-accuracy')

export default api
