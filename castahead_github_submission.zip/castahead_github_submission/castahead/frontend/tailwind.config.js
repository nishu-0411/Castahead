/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary:   '#006b55',
        'primary-light': '#00D4AA',
        'primary-container': '#55fcd0',
        secondary: '#0062A0',
        tertiary:  '#8A5100',
        error:     '#BA1A1A',
        surface:   '#f8fafb',
        'surface-container': '#ffffff',
        'on-surface': '#191c1b',
      },
      fontFamily: {
        headline: ['"Space Grotesk"', 'sans-serif'],
        body:     ['Manrope', 'sans-serif'],
        label:    ['Inter', 'sans-serif'],
        mono:     ['"JetBrains Mono"', 'monospace'],
        brand:    ['"Space Grotesk"', 'sans-serif'],
      },
      borderRadius: {
        DEFAULT: '0.125rem',
        lg: '0.25rem',
        xl: '0.5rem',
        '2xl': '1rem',
        full: '1.5rem',
      },
    },
  },
  plugins: [],
}
