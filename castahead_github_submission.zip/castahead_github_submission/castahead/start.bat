@echo off
echo.
echo  CastAhead - Starting both servers...
echo.

cd backend
if not exist ".env" (
    copy .env.example .env
    echo Created backend\.env
)
start "CastAhead Backend" cmd /k "pip install -r requirements.txt && uvicorn main:app --reload --port 8000"
cd ..

cd frontend
if not exist ".env" (
    copy .env.example .env
    echo Created frontend\.env
)
if not exist "node_modules" (
    echo Installing npm packages...
    npm install
)
start "CastAhead Frontend" cmd /k "npm run dev"
cd ..

echo.
echo  Frontend  - http://localhost:5173
echo  Backend   - http://localhost:8000
echo  API Docs  - http://localhost:8000/docs
echo.
pause
