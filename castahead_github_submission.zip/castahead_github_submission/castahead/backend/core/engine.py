"""
CastAhead Prediction Engine
Simulates Prophet + LightGBM + N-BEATS ensemble output.
Replace simulate_* functions with real model calls when models are trained.
"""
from __future__ import annotations

import numpy as np
from datetime import date, timedelta
from typing import Any


np.random.seed(42)

DEMAND_SUMMARY_WEEKS = 4


def _build_demand_summary(forecast_values: list[float], planning_weeks: int = DEMAND_SUMMARY_WEEKS) -> dict[str, int]:
    if not forecast_values:
        return {
            "minimum_required": 0,
            "most_likely": 0,
            "max_capacity": 0,
            "planning_weeks": max(1, int(planning_weeks)),
        }

    window = max(1, min(int(planning_weeks), len(forecast_values)))
    vals = [max(0.0, float(v)) for v in forecast_values[:window]]

    total = sum(vals)
    return {
        "minimum_required": int(max(0, round(total * 0.85))),
        "most_likely": int(max(0, round(total))),
        "max_capacity": int(max(0, round(total * 1.15))),
        "planning_weeks": window,
    }

# ── SKU MASTER DATA ─────────────────────────────────────────────────────────
SKU_MASTER: dict[str, dict[str, Any]] = {
    "SKU_101": {
        "sku_id": "SKU_101",
        "name": "Coca-Cola 500ml",
        "category": "Beverages",
        "store": "Downtown Flagship · 402",
        "region": "North",
        "current_stock": 340,
        "base_demand": 120,
        "price": 1.99,
        "status": "AT_RISK",
        "risk_label": "Red at Risk",
        "key_risk_factor": "Heat wave forecast",
        "recommendation": "ORDER NOW",
        "reorder_qty": 120,
        "reorder_deadline": "April 21st",
        "estimated_roi": 4250,
        "factors": [
            {"name": "Weather Patterns", "impact": "HIGH IMPACT",
             "description": "Upcoming heatwave increases beverage consumption by 22%.",
             "bar_pct": 85, "color": "primary"},
            {"name": "Market Trend",     "impact": "MODERATE IMPACT",
             "description": "Steady seasonal growth in convenience retail across regions.",
             "bar_pct": 55, "color": "secondary"},
            {"name": "Fuel Costs",       "impact": "LOW-MODERATE",
             "description": "Rising logistics costs affecting marginal supply frequency.",
             "bar_pct": 35, "color": "tertiary"},
        ],
        "location_breakdown": [
            {"store": "Downtown Flagship - 402", "stock": 42,  "forecast_14d": 156, "risk": "CRITICAL",  "days": 3},
            {"store": "East Side Mall - 118",    "stock": 18,  "forecast_14d": 88,  "risk": "CRITICAL",  "days": 2},
            {"store": "Suburban Hub - 209",      "stock": 120, "forecast_14d": 140, "risk": "MODERATE",  "days": 10},
            {"store": "North Park Express - 054","stock": 160, "forecast_14d": 45,  "risk": "LOW",       "days": 30},
        ],
    },
    "SKU_202": {
        "sku_id": "SKU_202",
        "name": "Sunscreen SPF50",
        "category": "Personal Care",
        "store": "East Side Mall · 118",
        "region": "South",
        "current_stock": 85,
        "base_demand": 55,
        "price": 14.99,
        "status": "NEEDS_ATTENTION",
        "risk_label": "Needs Attention",
        "key_risk_factor": "Shipment delay (+3d)",
        "recommendation": "EXPEDITE",
        "reorder_qty": 80,
        "reorder_deadline": "April 25th",
        "estimated_roi": 2800,
        "factors": [
            {"name": "Weather Patterns", "impact": "HIGH IMPACT",
             "description": "Summer season demand peaking; rain reducing outdoor exposure.",
             "bar_pct": 78, "color": "primary"},
            {"name": "Market Trend",     "impact": "MODERATE IMPACT",
             "description": "Health & wellness category trending upward this quarter.",
             "bar_pct": 62, "color": "secondary"},
            {"name": "Supply Chain",     "impact": "HIGH IMPACT",
             "description": "Supplier delays affecting 3-day lead times.",
             "bar_pct": 80, "color": "error"},
        ],
        "location_breakdown": [
            {"store": "East Side Mall - 118",    "stock": 85,  "forecast_14d": 120, "risk": "CRITICAL",  "days": 5},
            {"store": "Downtown Flagship - 402", "stock": 40,  "forecast_14d": 60,  "risk": "MODERATE",  "days": 8},
            {"store": "North Park Express - 054","stock": 110, "forecast_14d": 55,  "risk": "LOW",       "days": 25},
        ],
    },
    "SKU_303": {
        "sku_id": "SKU_303",
        "name": "Instant Noodles 200g",
        "category": "Grocery",
        "store": "Suburban Hub · 209",
        "region": "West",
        "current_stock": 1220,
        "base_demand": 200,
        "price": 1.29,
        "status": "ON_TRACK",
        "risk_label": "On Track",
        "key_risk_factor": "Seasonal downturn",
        "recommendation": "HOLD STOCK",
        "reorder_qty": 0,
        "reorder_deadline": "May 15th",
        "estimated_roi": 600,
        "factors": [
            {"name": "Market Trend",    "impact": "LOW IMPACT",
             "description": "Category demand slightly declining with warmer weather.",
             "bar_pct": 25, "color": "tertiary"},
            {"name": "Weather Impact",  "impact": "MODERATE IMPACT",
             "description": "Rainy season can spike comfort food demand.",
             "bar_pct": 45, "color": "secondary"},
            {"name": "Fuel Costs",      "impact": "LOW-MODERATE",
             "description": "Stable fuel prices keep logistics costs in check.",
             "bar_pct": 30, "color": "primary"},
        ],
        "location_breakdown": [
            {"store": "Suburban Hub - 209",      "stock": 1220, "forecast_14d": 400, "risk": "LOW",   "days": 42},
            {"store": "Downtown Flagship - 402", "stock": 380,  "forecast_14d": 200, "risk": "LOW",   "days": 28},
            {"store": "East Side Mall - 118",    "stock": 290,  "forecast_14d": 160, "risk": "LOW",   "days": 25},
        ],
    },
}

# ── HISTORICAL DATA GENERATOR ────────────────────────────────────────────────
def generate_historical(sku_id: str, days: int = 60) -> list[dict[str, Any]]:
    sku = SKU_MASTER[sku_id]
    base = sku["base_demand"]
    records = []
    today = date.today()
    for i in range(days):
        d = today - timedelta(days=days - i)
        dow = d.weekday()
        week_mult = 1.25 if dow >= 5 else 1.0
        noise = np.random.uniform(0.88, 1.12)
        sales = int(base * week_mult * noise)
        records.append({"date": d.isoformat(), "sales": sales})
    return records

# ── PROPHET SIMULATION ────────────────────────────────────────────────────────
def simulate_prophet(sku_id: str, horizon: int = 12) -> dict[str, Any]:
    sku = SKU_MASTER[sku_id]
    base = sku["base_demand"]
    today = date.today()
    dates, yhat, lower, upper = [], [], [], []
    for w in range(1, horizon + 1):
        d = today + timedelta(weeks=w)
        trend = 1.0 + 0.008 * w
        seasonal = 1.0 + 0.12 * np.sin(2 * np.pi * w / 52)
        noise = np.random.uniform(0.92, 1.08)
        point = base * trend * seasonal * noise
        uncertainty = point * 0.18
        dates.append(d.isoformat())
        yhat.append(round(point, 1))
        lower.append(round(point - uncertainty, 1))
        upper.append(round(point + uncertainty, 1))
    wmape = round(np.random.uniform(0.09, 0.14), 4)
    return {"dates": dates, "yhat": yhat, "lower": lower, "upper": upper, "wmape": wmape}

# ── LIGHTGBM SIMULATION ───────────────────────────────────────────────────────
def simulate_lgbm(sku_id: str, horizon: int = 12) -> dict[str, Any]:
    sku = SKU_MASTER[sku_id]
    base = sku["base_demand"]
    today = date.today()
    dates, yhat = [], []
    for w in range(1, horizon + 1):
        d = today + timedelta(weeks=w)
        external_boost = 1.0 + 0.015 * w
        noise = np.random.uniform(0.90, 1.10)
        point = base * external_boost * noise
        dates.append(d.isoformat())
        yhat.append(round(point, 1))
    wmape = round(np.random.uniform(0.07, 0.12), 4)
    return {"dates": dates, "yhat": yhat, "wmape": wmape}

# ── N-BEATS SIMULATION ────────────────────────────────────────────────────────
def simulate_nbeats(sku_id: str, horizon: int = 12) -> dict[str, Any]:
    sku = SKU_MASTER[sku_id]
    base = sku["base_demand"]
    today = date.today()
    dates, yhat = [], []
    for w in range(1, horizon + 1):
        d = today + timedelta(weeks=w)
        pattern = 1.0 + 0.06 * np.sin(2 * np.pi * w / 8)
        noise = np.random.uniform(0.91, 1.09)
        point = base * pattern * noise
        dates.append(d.isoformat())
        yhat.append(round(point, 1))
    wmape = round(np.random.uniform(0.10, 0.16), 4)
    return {"dates": dates, "yhat": yhat, "wmape": wmape}

# ── ENSEMBLE ──────────────────────────────────────────────────────────────────
def run_ensemble(sku_id: str, horizon: int = 12) -> dict[str, Any]:
    p = simulate_prophet(sku_id, horizon)
    l = simulate_lgbm(sku_id, horizon)
    n = simulate_nbeats(sku_id, horizon)

    # inverse-WMAPE weighting
    wp = 1 / p["wmape"]
    wl = 1 / l["wmape"]
    wn = 1 / n["wmape"]
    total = wp + wl + wn
    wp, wl, wn = wp / total, wl / total, wn / total

    ensemble_yhat = [
        round(wp * p["yhat"][i] + wl * l["yhat"][i] + wn * n["yhat"][i], 1)
        for i in range(horizon)
    ]
    ensemble_wmape = round(wp * p["wmape"] + wl * l["wmape"] + wn * n["wmape"], 4)

    sku = SKU_MASTER[sku_id]
    stock_line = [sku["current_stock"]] * horizon

    return {
        "sku_id": sku_id,
        "dates": p["dates"],
        "forecast": ensemble_yhat,
        "lower_bound": p["lower"],
        "upper_bound": p["upper"],
        "prophet_forecast": p["yhat"],
        "lgbm_forecast": l["yhat"],
        "nbeats_forecast": n["yhat"],
        "stock_level": stock_line,
        "model_weights": {
            "prophet": round(wp, 3),
            "lgbm":    round(wl, 3),
            "nbeats":  round(wn, 3),
        },
        "metrics": {
            "wmape_prophet":   p["wmape"],
            "wmape_lgbm":      l["wmape"],
            "wmape_nbeats":    n["wmape"],
            "wmape_ensemble":  ensemble_wmape,
        },
        "demand_summary": _build_demand_summary(ensemble_yhat),
    }

# ── SCENARIO ENGINE ───────────────────────────────────────────────────────────
SCENARIO_LIBRARY: dict[str, dict[str, Any]] = {
    "port_congestion_2024": {
        "id":          "port_congestion_2024",
        "type":        "SUPPLY_DISRUPTION",
        "label":       "Supply Disruption",
        "color":       "error",
        "title":       "Port Congestion 2024",
        "date_range":  "OCT 12 - OCT 28",
        "description": "A 2-week backlog at regional ports caused a 22% drop in available stock across the network.",
        "shock_multiplier": -0.22,
        "duration_weeks":   4,
        "stockout_prob":    0.71,
        "demand_delta_pct": -19,
        "risk_level":       "Moderate",
        "recommended_action": "Expedite next shipment by 1 week",
        "safety_stock_increase": 80,
        "accuracy_pct": 84,
        "accuracy_note": "Simulation accuracy rated high (84%) based on 8 prior supply disruption events in the North region.",
    },
    "unseasonal_heatwave": {
        "id":          "unseasonal_heatwave",
        "type":        "WEATHER_EVENT",
        "label":       "Weather Event",
        "color":       "primary",
        "title":       "Unseasonal Heatwave",
        "date_range":  "AUG 05 - AUG 15",
        "description": "Sudden temperature spike led to a 40% surge in demand for cold beverages during standard periods.",
        "shock_multiplier": 0.40,
        "duration_weeks":   3,
        "stockout_prob":    0.92,
        "demand_delta_pct": +19,
        "risk_level":       "High",
        "recommended_action": "Increase stock by 120 units",
        "safety_stock_increase": 120,
        "accuracy_pct": 88,
        "accuracy_note": "Simulation accuracy for Unseasonal Heatwave is rated high (88%) based on 12 prior correlations between regional temperature spikes and SKU category 004-BEV performance.",
    },
    "competitor_promo": {
        "id":          "competitor_promo",
        "type":        "MARKET_SHIFT",
        "label":       "Market Shift",
        "color":       "tertiary",
        "title":       "Competitor Promo",
        "date_range":  "JAN 10 - JAN 20",
        "description": "Aggressive discount from a major competitor caused volatile demand shifts and consumer migration.",
        "shock_multiplier": -0.15,
        "duration_weeks":   2,
        "stockout_prob":    0.44,
        "demand_delta_pct": -12,
        "risk_level":       "Low",
        "recommended_action": "Hold stock; monitor competitor pricing weekly",
        "safety_stock_increase": 30,
        "accuracy_pct": 79,
        "accuracy_note": "Market shift simulation accuracy rated moderate (79%) based on 5 prior competitor promotional events in the beverages category.",
    },
}

def run_scenario(sku_id: str, scenario_id: str, horizon: int = 12) -> dict[str, Any]:
    base = run_ensemble(sku_id, horizon)
    sc = SCENARIO_LIBRARY[scenario_id]
    mult = sc["shock_multiplier"]
    dur = sc["duration_weeks"]

    # use sku-level properties to slightly alter the simulated outcome so results differ per SKU
    sku = SKU_MASTER.get(sku_id, {})
    current_stock = float(sku.get("current_stock", 0))
    base_demand = float(sku.get("base_demand", 1))

    # deterministic modifier from sku_id hash in [-0.12, +0.12]
    hmod = (abs(hash(sku_id)) % 25) / 100.0 - 0.12

    simulated = []
    for i, v in enumerate(base["forecast"]):
        if i < dur:
            factor = 1 + mult * (1 - i / dur)
        else:
            recovery = min(1.0, (i - dur) / 3.0)
            factor = 1 + mult * (1 - recovery) * 0.3
        # apply sku-level modifier scaled by base demand
        adj = 1.0 + hmod * min(1.0, base_demand / max(1.0, current_stock + 1.0))
        simulated.append(round(v * factor * adj, 1))

    delta_pct = [round((s - b) / b * 100, 1) if b > 0 else 0 for s, b in zip(simulated, base["forecast"])]
    baseline_total = float(sum(base["forecast"]))
    simulated_total = float(sum(simulated))
    demand_impact_pct = round((simulated_total - baseline_total) / baseline_total * 100, 1) if baseline_total > 0 else 0.0

    # tailor stockout probability and safety stock recommendation per SKU
    stockout_prob = max(0.0, min(1.0, sc.get("stockout_prob", 0.5) + hmod))
    # safety stock increase scaled by SKU volatility and current stock
    safety_increase = int(max(0, round(sc.get("safety_stock_increase", 0) * (1.0 + hmod))))

    # recommended action may change if SKU has low stock relative to near-term demand
    near_term_req = sum(simulated[:max(1, min(len(simulated), 4))])
    if current_stock < 0.5 * near_term_req:
        recommended_action = "ORDER NOW"
    elif current_stock < near_term_req:
        recommended_action = "EXPEDITE"
    else:
        recommended_action = sc.get("recommended_action", "HOLD STOCK")

    return {
        "sku_id": sku_id,
        "scenario_id": scenario_id,
        "scenario_meta": sc,
        "dates": base["dates"],
        "baseline_forecast": base["forecast"],
        "simulated_forecast": simulated,
        "delta_pct": delta_pct,
        "demand_impact_pct": demand_impact_pct,
        "historical_demand_delta_pct": sc.get("demand_delta_pct"),
        "stockout_risk": sc.get("risk_level"),
        "stockout_prob": stockout_prob,
        "recommended_action": recommended_action,
        "safety_stock_increase": safety_increase,
        "accuracy_pct": sc.get("accuracy_pct"),
        "accuracy_note": sc.get("accuracy_note"),
    }


# ---------------------------------------------------------------------------
# CSV-BACKED MODEL INTEGRATION (Prophet + NBEATS + LightGBM metrics)
# ---------------------------------------------------------------------------
from pathlib import Path
import re
import pandas as pd

_LEGACY_RUN_ENSEMBLE = run_ensemble
_LEGACY_GENERATE_HISTORICAL = generate_historical

_CSV_SKU_INDEX: dict[str, dict[str, str]] = {}
_CSV_ALIAS_INDEX: dict[str, str] = {}
_PROPHET_DF = pd.DataFrame()
_NBEATS_DF = pd.DataFrame()
_METRICS_NBEATS_DF = pd.DataFrame()
_METRICS_LGBM_DF = pd.DataFrame()
_ENSEMBLE_PRED_DF = pd.DataFrame()
_ENSEMBLE_METRICS_DF = pd.DataFrame()
_ENSEMBLE_WEIGHT_CACHE: dict[str, dict[str, float]] = {}

ENSEMBLE_W_LGBM = 0.40
ENSEMBLE_W_NBEATS = 0.40
ENSEMBLE_W_PROPHET = 0.20
ENSEMBLE_MIN_WEIGHT = 0.10


def _safe_sku_id(item_id: str) -> str:
    token = re.sub(r"[^A-Za-z0-9]+", "_", item_id).strip("_")
    return f"CSV_{token}"


def _normalize_name(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", value.lower())).strip()


def resolve_sku_identifier(sku_or_name: str) -> str | None:
    if sku_or_name in SKU_MASTER:
        return sku_or_name
    key = _normalize_name(sku_or_name)
    if not key:
        return None
    if key in _CSV_ALIAS_INDEX:
        return _CSV_ALIAS_INDEX[key]

    for alias, sku_id in _CSV_ALIAS_INDEX.items():
        if key in alias or alias in key:
            return sku_id
    return None


def _state_to_region(state: str) -> str:
    return {"CA": "West", "TX": "South", "WI": "North"}.get(state, "North")


_RISK_SIGNALS: dict[str, list[str]] = {
    "AT_RISK": [
        "Demand surge outpacing available stock",
        "Reorder threshold breached — lead time critical",
        "Stockout probability elevated this cycle",
        "Demand acceleration detected in recent weeks",
        "Supply gap vs forecast exceeds safety buffer",
        "Consumption velocity exceeds replenishment rate",
        "Model consensus flags critical inventory shortfall",
    ],
    "NEEDS_ATTENTION": [
        "Demand-supply gap narrowing — replenish soon",
        "Model divergence flags possible demand shift",
        "Lead time risk detected in supply pipeline",
        "Moderate demand volatility vs historical baseline",
        "Replenishment window tightening this period",
        "Forecasted demand approaching available stock",
        "Ensemble signals upward demand trend ahead",
    ],
    "ON_TRACK": [
        "Steady consumption rate within forecast band",
        "Seasonal demand aligning with historical pattern",
        "No near-term supply disruption detected",
        "Stock velocity normal — adequate safety buffer",
        "Demand signals consistent with model baseline",
        "Inventory coverage healthy across distribution",
        "Forward forecast stable with low model variance",
    ],
}


def _derive_key_risk_factor(sku_id: str, status: str) -> str:
    """Return a deterministic, per-SKU contextual risk signal based on operational state."""
    signals = _RISK_SIGNALS.get(status, _RISK_SIGNALS["ON_TRACK"])
    return signals[abs(hash(sku_id)) % len(signals)]


def _read_csv_safe(path: Path, parse_dates: list[str] | None = None) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, parse_dates=parse_dates or [])
    except Exception:
        return pd.DataFrame()


def _wmape(actual: np.ndarray, predicted: np.ndarray) -> float:
    denom = float(np.abs(actual).sum())
    if denom <= 1e-9:
        return 0.25
    return float(np.abs(actual - predicted).sum() / denom)


def _wmape_nonzero(actual: np.ndarray, predicted: np.ndarray) -> float:
    """WMAPE ignoring likely stockout rows where actual is zero."""
    a = np.asarray(actual, dtype=float)
    p = np.asarray(predicted, dtype=float)
    mask = np.isfinite(a) & np.isfinite(p) & (a > 0)
    if int(mask.sum()) == 0:
        return 0.25
    a = a[mask]
    p = p[mask]
    denom = float(np.abs(a).sum())
    if denom <= 1e-9:
        return 0.25
    return float(np.abs(a - p).sum() / denom)


def _optimize_ensemble_weights(
    actual: np.ndarray,
    lgbm_pred: np.ndarray,
    nbeats_pred: np.ndarray,
    prophet_pred: np.ndarray,
) -> tuple[float, float, float, float]:
    """Find non-negative weights summing to 1.0 that minimize WMAPE."""
    a = np.asarray(actual, dtype=float)
    l = np.asarray(lgbm_pred, dtype=float)
    n = np.asarray(nbeats_pred, dtype=float)
    p = np.asarray(prophet_pred, dtype=float)

    mask = np.isfinite(a) & np.isfinite(l) & np.isfinite(n) & np.isfinite(p) & (a > 0)
    if int(mask.sum()) < 3:
        wl = ENSEMBLE_W_LGBM
        wn = ENSEMBLE_W_NBEATS
        wp = ENSEMBLE_W_PROPHET
        score = _wmape_nonzero(a, wl * l + wn * n + wp * p)
        return wl, wn, wp, score

    a = a[mask]
    l = l[mask]
    n = n[mask]
    p = p[mask]

    # Coarse-to-fine grid search for robust deterministic optimization.
    best_score = float("inf")
    best = (ENSEMBLE_W_LGBM, ENSEMBLE_W_NBEATS, ENSEMBLE_W_PROPHET)

    coarse_step = 0.05
    min_w = ENSEMBLE_MIN_WEIGHT
    grid = np.arange(min_w, 1.0 - 2 * min_w + 1e-9, coarse_step)
    for wl in grid:
        for wn in grid:
            wp = 1.0 - wl - wn
            if wp < min_w:
                continue
            pred = wl * l + wn * n + wp * p
            score = _wmape_nonzero(a, pred)
            if score < best_score:
                best_score = score
                best = (float(wl), float(wn), float(wp))

    fine_step = 0.01
    wl0, wn0, _ = best
    wl_range = np.arange(max(min_w, wl0 - 0.1), min(1.0 - 2 * min_w, wl0 + 0.1) + 1e-9, fine_step)
    wn_range = np.arange(max(min_w, wn0 - 0.1), min(1.0 - 2 * min_w, wn0 + 0.1) + 1e-9, fine_step)

    for wl in wl_range:
        for wn in wn_range:
            wp = 1.0 - wl - wn
            if wp < min_w:
                continue
            pred = wl * l + wn * n + wp * p
            score = _wmape_nonzero(a, pred)
            if score < best_score:
                best_score = score
                best = (float(wl), float(wn), float(wp))

    wl, wn, wp = best
    return wl, wn, wp, float(best_score)


def _lookup_metric(df: pd.DataFrame, item_id: str, state: str, column: str = "wmape") -> float | None:
    if df.empty or column not in df.columns:
        return None
    mask = (df["sku"] == item_id) & (df["state"] == state)
    if not mask.any():
        return None
    val = df.loc[mask, column].iloc[0]
    try:
        return float(val)
    except Exception:
        return None


def _lookup_metric_product(df: pd.DataFrame, item_id: str, column: str = "wmape") -> float | None:
    if df.empty or column not in df.columns or "sku" not in df.columns:
        return None
    sub = df[df["sku"] == item_id].copy()
    if sub.empty:
        return None
    if "actual_total" in sub.columns:
        weights = sub["actual_total"].astype(float).clip(lower=0.0)
        if float(weights.sum()) > 0:
            return float((sub[column].astype(float) * weights).sum() / weights.sum())
    return float(sub[column].astype(float).mean())


def _lookup_metric_for_items(df: pd.DataFrame, item_ids: list[str], column: str = "wmape") -> float | None:
    if df.empty or not item_ids:
        return None
    sub = df[df["sku"].isin(item_ids)].copy() if "sku" in df.columns else pd.DataFrame()
    if sub.empty or column not in sub.columns:
        return None
    if "actual_total" in sub.columns:
        weights = sub["actual_total"].astype(float).clip(lower=0.0)
        if float(weights.sum()) > 0:
            return float((sub[column].astype(float) * weights).sum() / weights.sum())
    return float(sub[column].astype(float).mean())


def _weighted_lgbm_ratio_for_items(item_ids: list[str]) -> float:
    if _METRICS_LGBM_DF.empty:
        return 1.0
    sub = _METRICS_LGBM_DF[_METRICS_LGBM_DF["sku"].isin(item_ids)]
    if sub.empty or "actual_total" not in sub.columns or "pred_total" not in sub.columns:
        return 1.0
    actual_total = float(sub["actual_total"].astype(float).sum())
    pred_total = float(sub["pred_total"].astype(float).sum())
    if actual_total <= 1e-9:
        return 1.0
    return max(0.25, min(4.0, pred_total / actual_total))


def _project_forward(series: np.ndarray, horizon: int, season_len: int = 4) -> np.ndarray:
    if horizon <= 0:
        return np.array([], dtype=float)
    if series.size == 0:
        return np.zeros(horizon, dtype=float)

    n = min(len(series), 16)
    y = np.asarray(series[-n:], dtype=float)
    x = np.arange(n, dtype=float)

    if n >= 2:
        slope, intercept = np.polyfit(x, y, 1)
    else:
        slope, intercept = 0.0, float(y[-1])

    season_len = max(1, min(season_len, n))
    trend_hist = intercept + slope * x
    residual = y - trend_hist
    seasonal = residual[-season_len:]

    out = []
    for i in range(1, horizon + 1):
        x_new = (n - 1) + i
        trend_val = intercept + slope * x_new
        seasonal_val = seasonal[(i - 1) % season_len] if seasonal.size else 0.0
        out.append(max(0.0, float(trend_val + 0.35 * seasonal_val)))
    return np.array(out, dtype=float)


def _build_model_weekly_series(item_ids: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    prophet = _PROPHET_DF[_PROPHET_DF["item_id"].isin(item_ids)].copy()
    nbeats = _NBEATS_DF[_NBEATS_DF["item_id"].isin(item_ids)].copy()

    p_weekly = (
        prophet.groupby("week_start", as_index=False)[["actual", "forecast", "lower", "upper"]]
        .sum(numeric_only=True)
        .sort_values("week_start")
    )

    if "split" in nbeats.columns and (nbeats["split"] == "test").any():
        nbeats = nbeats[nbeats["split"] == "test"]
    n_weekly = (
        nbeats.groupby("week_start", as_index=False)[["actual", "predicted"]]
        .sum(numeric_only=True)
        .sort_values("week_start")
    )

    return p_weekly, n_weekly


def _build_ensemble_weekly_series(item_ids: list[str]) -> pd.DataFrame:
    pred = _ENSEMBLE_PRED_DF[_ENSEMBLE_PRED_DF["item_id"].isin(item_ids)].copy()
    if pred.empty:
        return pd.DataFrame()

    cols = [
        "actual", "ensemble_pred", "lgbm_pred", "nbeats_pred", "prophet_pred",
        "prophet_lo", "prophet_hi"
    ]
    use_cols = [c for c in cols if c in pred.columns]

    weekly = (
        pred.groupby("week_start", as_index=False)[use_cols]
        .sum(numeric_only=True)
        .sort_values("week_start")
    )
    return weekly


def _build_sku_master_from_ensemble(pred_df: pd.DataFrame) -> dict[str, dict[str, Any]]:
    sku_master: dict[str, dict[str, Any]] = {}
    _CSV_SKU_INDEX.clear()
    _CSV_ALIAS_INDEX.clear()
    brand_items: Dict[str, List[str]] = {"Lays": [], "Great Value": []}

    grouped = pred_df.groupby(["item_id"], dropna=False)
    for (item_id,), frame in grouped:
        if pd.isna(item_id):
            continue

        frame = frame.sort_values("week_start")
        product_name = str(frame["product_name"].dropna().iloc[0]) if "product_name" in frame.columns and frame["product_name"].notna().any() else str(item_id)
        state_mode = str(frame["state"].mode().iloc[0]) if "state" in frame.columns and frame["state"].notna().any() else "CA"

        weekly = (
            frame.groupby("week_start", as_index=False)[["actual", "ensemble_pred"]]
            .sum(numeric_only=True)
            .sort_values("week_start")
        )
        recent_actual = weekly["actual"].tail(4).fillna(0)
        recent_forecast = weekly["ensemble_pred"].tail(4).fillna(0)
        non_zero_actual = weekly.loc[weekly["actual"] > 0, "actual"].tail(16)

        baseline = float(non_zero_actual.median()) if not non_zero_actual.empty else float(weekly["ensemble_pred"].tail(16).mean())
        current_stock = int(max(80, round(max(baseline, 1.0) * 3.0)))
        demand_4w = float(recent_forecast.sum())
        reorder_qty = int(max(0, round(demand_4w - current_stock)))

        if reorder_qty > current_stock * 0.6:
            status = "AT_RISK"
            risk_label = "Red at Risk"
            recommendation = "ORDER NOW"
        elif reorder_qty > 0:
            status = "NEEDS_ATTENTION"
            risk_label = "Needs Attention"
            recommendation = "EXPEDITE"
        else:
            status = "ON_TRACK"
            risk_label = "On Track"
            recommendation = "HOLD STOCK"

        sku_id = _safe_sku_id(str(item_id))
        short_name = product_name.split(" ")[0] if product_name else str(item_id)
        _CSV_SKU_INDEX[sku_id] = {
            "item_id": str(item_id),
            "state": state_mode,
            "product_name": product_name,
            "short_name": short_name,
        }

        norm_product = _normalize_name(product_name)
        norm_short = _normalize_name(short_name)
        if norm_product:
            _CSV_ALIAS_INDEX[norm_product] = sku_id
        if norm_short:
            _CSV_ALIAS_INDEX[norm_short] = sku_id

        if norm_product.startswith("gv") or "great value" in norm_product:
            _CSV_ALIAS_INDEX["great value"] = sku_id
            _CSV_ALIAS_INDEX["gv"] = sku_id
            brand_items["Great Value"].append(str(item_id))
        if "lay" in norm_product:
            _CSV_ALIAS_INDEX["lays"] = sku_id
            brand_items["Lays"].append(str(item_id))

        state_rows = (
            frame.groupby("state", as_index=False)[["actual", "ensemble_pred"]]
            .sum(numeric_only=True)
            .sort_values("ensemble_pred", ascending=False)
            .head(3)
        )
        location_breakdown = []
        for _, sr in state_rows.iterrows():
            st = str(sr["state"])
            state_stock = int(max(20, round(float(sr["actual"]) / max(len(weekly), 1) * 2.5)))
            forecast_14d = int(max(1, round(float(sr["ensemble_pred"]) / max(len(weekly), 1) * 2)))
            days = max(1, int(round(state_stock / max(forecast_14d / 14.0, 0.5))))
            risk = "CRITICAL" if days <= 5 else ("MODERATE" if days <= 12 else "LOW")
            location_breakdown.append({
                "store": f"{st} Region",
                "stock": state_stock,
                "forecast_14d": forecast_14d,
                "risk": risk,
                "days": days,
            })

        sku_master[sku_id] = {
            "sku_id": sku_id,
            "name": product_name,
            "category": "Forecasted Product",
            "store": "Multi-Store",
            "region": _state_to_region(state_mode),
            "current_stock": current_stock,
            "base_demand": int(max(1, round(float(weekly["actual"].tail(12).mean())))),
            "price": 0.0,
            "status": status,
            "risk_label": risk_label,
            "key_risk_factor": _derive_key_risk_factor(sku_id, status),
            "recommendation": recommendation,
            "reorder_qty": reorder_qty,
            "reorder_deadline": "Next restock cycle",
            "estimated_roi": int(max(0, reorder_qty * 6)),
            "factors": [
                {
                    "name": "LightGBM",
                    "impact": "HIGH IMPACT",
                    "description": "Feature-driven forecast with macro/event signals.",
                    "bar_pct": int(ENSEMBLE_W_LGBM * 100),
                    "color": "secondary",
                },
                {
                    "name": "N-BEATS",
                    "impact": "HIGH IMPACT",
                    "description": "Deep temporal sequence modeling for demand shocks.",
                    "bar_pct": int(ENSEMBLE_W_NBEATS * 100),
                    "color": "tertiary",
                },
                {
                    "name": "Prophet",
                    "impact": "MODERATE IMPACT",
                    "description": "Seasonality baseline and trend stabilization layer.",
                    "bar_pct": int(ENSEMBLE_W_PROPHET * 100),
                    "color": "primary",
                },
            ],
            "location_breakdown": location_breakdown,
        }

    for brand, item_ids in brand_items.items():
        unique_ids = sorted(set(item_ids))
        if not unique_ids:
            continue

        member_rows = [sku_master[_safe_sku_id(i)] for i in unique_ids if _safe_sku_id(i) in sku_master]
        if not member_rows:
            continue

        stock_total = int(sum(r.get("current_stock", 0) for r in member_rows))
        reorder_total = int(sum(r.get("reorder_qty", 0) for r in member_rows))
        base_total = int(sum(r.get("base_demand", 0) for r in member_rows))
        roi_total = int(sum(r.get("estimated_roi", 0) for r in member_rows))

        if reorder_total > stock_total * 0.6:
            status = "AT_RISK"
            risk_label = "Red at Risk"
            recommendation = "ORDER NOW"
        elif reorder_total > 0:
            status = "NEEDS_ATTENTION"
            risk_label = "Needs Attention"
            recommendation = "EXPEDITE"
        else:
            status = "ON_TRACK"
            risk_label = "On Track"
            recommendation = "HOLD STOCK"

        brand_sku = f"CSV_BRAND_{re.sub(r'[^A-Za-z0-9]+', '_', brand).upper()}"
        _CSV_SKU_INDEX[brand_sku] = {
            "item_ids": "|".join(unique_ids),
            "product_name": f"{brand} (All)",
            "state": "CA",
        }
        _CSV_ALIAS_INDEX[_normalize_name(brand)] = brand_sku

        sku_master[brand_sku] = {
            "sku_id": brand_sku,
            "name": f"{brand} (All Products)",
            "category": "Brand Forecast",
            "store": "All Stores",
            "region": "West",
            "current_stock": stock_total,
            "base_demand": max(1, base_total),
            "price": 0.0,
            "status": status,
            "risk_label": risk_label,
            "key_risk_factor": _derive_key_risk_factor(brand_sku, status),
            "recommendation": recommendation,
            "reorder_qty": reorder_total,
            "reorder_deadline": "Next restock cycle",
            "estimated_roi": roi_total,
            "factors": member_rows[0].get("factors", []),
            "location_breakdown": member_rows[0].get("location_breakdown", []),
        }

    return sku_master


def _build_csv_sku_master(prophet_df: pd.DataFrame) -> dict[str, dict[str, Any]]:
    sku_master: dict[str, dict[str, Any]] = {}
    _CSV_SKU_INDEX.clear()
    _CSV_ALIAS_INDEX.clear()
    brand_items: dict[str, list[str]] = {"Lays": [], "Great Value": []}

    grouped = prophet_df.groupby(["item_id"], dropna=False)
    for (item_id,), frame in grouped:
        if pd.isna(item_id):
            continue

        frame = frame.sort_values("week_start")
        product_name = str(frame["product_name"].dropna().iloc[0]) if "product_name" in frame.columns and frame["product_name"].notna().any() else str(item_id)
        state_mode = str(frame["state"].mode().iloc[0]) if "state" in frame.columns and frame["state"].notna().any() else "CA"

        weekly = (
            frame.groupby("week_start", as_index=False)[["actual", "forecast"]]
            .sum(numeric_only=True)
            .sort_values("week_start")
        )
        recent_actual = weekly["actual"].tail(4).fillna(0)
        recent_forecast = weekly["forecast"].tail(4).fillna(0)
        non_zero_actual = weekly.loc[weekly["actual"] > 0, "actual"].tail(16)

        baseline = float(non_zero_actual.median()) if not non_zero_actual.empty else float(weekly["forecast"].tail(16).mean())
        current_stock = int(max(80, round(max(baseline, 1.0) * 3.0)))
        demand_4w = float(recent_forecast.sum())
        reorder_qty = int(max(0, round(demand_4w - current_stock)))

        if reorder_qty > current_stock * 0.6:
            status = "AT_RISK"
            risk_label = "Red at Risk"
            recommendation = "ORDER NOW"
        elif reorder_qty > 0:
            status = "NEEDS_ATTENTION"
            risk_label = "Needs Attention"
            recommendation = "EXPEDITE"
        else:
            status = "ON_TRACK"
            risk_label = "On Track"
            recommendation = "HOLD STOCK"

        sku_id = _safe_sku_id(str(item_id))
        short_name = product_name.split(" ")[0] if product_name else str(item_id)
        _CSV_SKU_INDEX[sku_id] = {
            "item_id": str(item_id),
            "state": state_mode,
            "product_name": product_name,
            "short_name": short_name,
        }

        norm_product = _normalize_name(product_name)
        norm_short = _normalize_name(short_name)
        if norm_product:
            _CSV_ALIAS_INDEX[norm_product] = sku_id
        if norm_short:
            _CSV_ALIAS_INDEX[norm_short] = sku_id

        if norm_product.startswith("gv") or "great value" in norm_product:
            _CSV_ALIAS_INDEX["great value"] = sku_id
            _CSV_ALIAS_INDEX["gv"] = sku_id
            brand_items["Great Value"].append(str(item_id))
        if "lay" in norm_product:
            _CSV_ALIAS_INDEX["lays"] = sku_id
            brand_items["Lays"].append(str(item_id))

        state_rows = (
            frame.groupby("state", as_index=False)[["actual", "forecast"]]
            .sum(numeric_only=True)
            .sort_values("forecast", ascending=False)
            .head(3)
        )
        location_breakdown = []
        for _, sr in state_rows.iterrows():
            st = str(sr["state"])
            state_stock = int(max(20, round(float(sr["actual"]) / max(len(weekly), 1) * 2.5)))
            forecast_14d = int(max(1, round(float(sr["forecast"]) / max(len(weekly), 1) * 2)))
            days = max(1, int(round(state_stock / max(forecast_14d / 14.0, 0.5))))
            risk = "CRITICAL" if days <= 5 else ("MODERATE" if days <= 12 else "LOW")
            location_breakdown.append({
                "store": f"{st} Region",
                "stock": state_stock,
                "forecast_14d": forecast_14d,
                "risk": risk,
                "days": days,
            })

        sku_master[sku_id] = {
            "sku_id": sku_id,
            "name": product_name,
            "category": "Forecasted Product",
            "store": "Multi-Store",
            "region": _state_to_region(state_mode),
            "current_stock": current_stock,
            "base_demand": int(max(1, round(float(weekly["actual"].tail(12).mean())))),
            "price": 0.0,
            "status": status,
            "risk_label": risk_label,
            "key_risk_factor": _derive_key_risk_factor(sku_id, status),
            "recommendation": recommendation,
            "reorder_qty": reorder_qty,
            "reorder_deadline": "Next restock cycle",
            "estimated_roi": int(max(0, reorder_qty * 6)),
            "factors": [
                {
                    "name": "Prophet Time-Series",
                    "impact": "HIGH IMPACT",
                    "description": "Captures trend and seasonality from weekly demand.",
                    "bar_pct": 84,
                    "color": "primary",
                },
                {
                    "name": "LightGBM Signal",
                    "impact": "MODERATE IMPACT",
                    "description": "Applies feature-informed scaling to baseline forecast.",
                    "bar_pct": 66,
                    "color": "secondary",
                },
                {
                    "name": "N-BEATS Pattern",
                    "impact": "HIGH IMPACT",
                    "description": "Learns non-linear temporal demand patterns.",
                    "bar_pct": 78,
                    "color": "tertiary",
                },
            ],
            "location_breakdown": location_breakdown,
        }

    # Add brand-level virtual SKUs for direct user input (e.g., "Lays", "Great Value").
    for brand, item_ids in brand_items.items():
        unique_ids = sorted(set(item_ids))
        if not unique_ids:
            continue

        member_rows = [sku_master[_safe_sku_id(i)] for i in unique_ids if _safe_sku_id(i) in sku_master]
        if not member_rows:
            continue

        stock_total = int(sum(r.get("current_stock", 0) for r in member_rows))
        reorder_total = int(sum(r.get("reorder_qty", 0) for r in member_rows))
        base_total = int(sum(r.get("base_demand", 0) for r in member_rows))
        roi_total = int(sum(r.get("estimated_roi", 0) for r in member_rows))

        if reorder_total > stock_total * 0.6:
            status = "AT_RISK"
            risk_label = "Red at Risk"
            recommendation = "ORDER NOW"
        elif reorder_total > 0:
            status = "NEEDS_ATTENTION"
            risk_label = "Needs Attention"
            recommendation = "EXPEDITE"
        else:
            status = "ON_TRACK"
            risk_label = "On Track"
            recommendation = "HOLD STOCK"

        brand_sku = f"CSV_BRAND_{re.sub(r'[^A-Za-z0-9]+', '_', brand).upper()}"
        _CSV_SKU_INDEX[brand_sku] = {
            "item_ids": "|".join(unique_ids),
            "product_name": f"{brand} (All)",
            "state": "CA",
        }
        _CSV_ALIAS_INDEX[_normalize_name(brand)] = brand_sku

        sku_master[brand_sku] = {
            "sku_id": brand_sku,
            "name": f"{brand} (All Products)",
            "category": "Brand Forecast",
            "store": "All Stores",
            "region": "West",
            "current_stock": stock_total,
            "base_demand": max(1, base_total),
            "price": 0.0,
            "status": status,
            "risk_label": risk_label,
            "key_risk_factor": _derive_key_risk_factor(brand_sku, status),
            "recommendation": recommendation,
            "reorder_qty": reorder_total,
            "reorder_deadline": "Next restock cycle",
            "estimated_roi": roi_total,
            "factors": member_rows[0].get("factors", []),
            "location_breakdown": member_rows[0].get("location_breakdown", []),
        }

    return sku_master


def _item_ids_from_key(key: dict[str, str]) -> list[str]:
    if "item_ids" in key and key["item_ids"]:
        return [x for x in key["item_ids"].split("|") if x]
    if "item_id" in key and key["item_id"]:
        return [key["item_id"]]
    return []


def _load_trained_csv_data() -> None:
    global _PROPHET_DF, _NBEATS_DF, _METRICS_NBEATS_DF, _METRICS_LGBM_DF
    global _ENSEMBLE_PRED_DF, _ENSEMBLE_METRICS_DF, _ENSEMBLE_WEIGHT_CACHE

    root = Path(__file__).resolve().parents[2]
    ensemble_dir = root / "ensemble"
    trained_dir = root / "trained csv"

    # Prefer finalized hybrid ensemble outputs when available.
    ensemble_preds = _read_csv_safe(ensemble_dir / "final_ensemble_predictions.csv", parse_dates=["week_start"])
    ensemble_metrics = _read_csv_safe(ensemble_dir / "ensemble_metrics.csv")
    if not ensemble_preds.empty:
        _ENSEMBLE_WEIGHT_CACHE = {}
        _ENSEMBLE_PRED_DF = ensemble_preds
        _ENSEMBLE_METRICS_DF = ensemble_metrics
        ens_skus = _build_sku_master_from_ensemble(ensemble_preds)
        if ens_skus:
            SKU_MASTER.clear()
            SKU_MASTER.update(ens_skus)
            return

    if not trained_dir.exists():
        return

    prophet = _read_csv_safe(trained_dir / "prophet_predictions.csv", parse_dates=["week_start"])
    nbeats = _read_csv_safe(trained_dir / "predictions_nbeats.csv", parse_dates=["week_start"])
    metrics_nbeats = _read_csv_safe(trained_dir / "metrics_nbeats.csv")
    metrics_lgbm = _read_csv_safe(trained_dir / "metrics_lightbgm.csv")

    if prophet.empty or nbeats.empty:
        return

    _PROPHET_DF = prophet
    _NBEATS_DF = nbeats
    _METRICS_NBEATS_DF = metrics_nbeats
    _METRICS_LGBM_DF = metrics_lgbm

    csv_skus = _build_csv_sku_master(prophet)
    if csv_skus:
        # Make trained CSV-backed SKUs the primary catalog.
        SKU_MASTER.clear()
        SKU_MASTER.update(csv_skus)


def _csv_actual_history(sku_id: str) -> list[dict[str, Any]]:
    key = _CSV_SKU_INDEX.get(sku_id)
    if not key:
        return []

    item_ids = _item_ids_from_key(key)
    if not _ENSEMBLE_PRED_DF.empty:
        hist = (
            _ENSEMBLE_PRED_DF[_ENSEMBLE_PRED_DF["item_id"].isin(item_ids)][["week_start", "actual"]]
            .groupby("week_start", as_index=False)["actual"]
            .sum(numeric_only=True)
            .sort_values("week_start")
        )
        out = []
        for _, row in hist.iterrows():
            out.append({
                "date": row["week_start"].date().isoformat(),
                "sales": int(max(0, round(float(row["actual"])))) if pd.notna(row["actual"]) else 0,
            })
        return out

    n_hist = _NBEATS_DF[_NBEATS_DF["item_id"].isin(item_ids)][["week_start", "actual"]].copy()
    hist = (
        n_hist.groupby("week_start", as_index=False)["actual"]
        .sum(numeric_only=True)
        .sort_values("week_start")
    )
    if hist.empty:
        p_hist = _PROPHET_DF[_PROPHET_DF["item_id"].isin(item_ids)][["week_start", "actual"]].copy()
        hist = (
            p_hist.groupby("week_start", as_index=False)["actual"]
            .sum(numeric_only=True)
            .sort_values("week_start")
        )

    out = []
    for _, row in hist.iterrows():
        out.append({
            "date": row["week_start"].date().isoformat(),
            "sales": int(max(0, round(float(row["actual"])))) if pd.notna(row["actual"]) else 0,
        })
    return out


def generate_historical(sku_id: str, days: int = 60) -> List[Dict]:
    if sku_id in _CSV_SKU_INDEX:
        hist = _csv_actual_history(sku_id)
        return hist[-days:] if days > 0 else hist
    return _LEGACY_GENERATE_HISTORICAL(sku_id, days)


def run_ensemble(sku_id: str, horizon: int = 12) -> Dict:
    if sku_id not in _CSV_SKU_INDEX:
        return _LEGACY_RUN_ENSEMBLE(sku_id, horizon)

    key = _CSV_SKU_INDEX[sku_id]
    item_ids = _item_ids_from_key(key)

    if not _ENSEMBLE_PRED_DF.empty:
        weekly = _build_ensemble_weekly_series(item_ids)
        if weekly.empty:
            return _LEGACY_RUN_ENSEMBLE(sku_id, horizon)

        actual_hist = weekly["actual"].fillna(0.0).astype(float).to_numpy()
        lgbm_hist = weekly["lgbm_pred"].fillna(0.0).astype(float).to_numpy()
        nbeats_hist = weekly["nbeats_pred"].fillna(0.0).astype(float).to_numpy()
        prophet_hist = weekly["prophet_pred"].fillna(0.0).astype(float).to_numpy()

        cache_key = "|".join(sorted(item_ids))
        cached = _ENSEMBLE_WEIGHT_CACHE.get(cache_key)
        if cached:
            wl = float(cached["lgbm"])
            wn = float(cached["nbeats"])
            wp = float(cached["prophet"])
            wmape_ensemble = float(cached["wmape_ensemble"])
        else:
            wl, wn, wp, wmape_ensemble = _optimize_ensemble_weights(
                actual_hist, lgbm_hist, nbeats_hist, prophet_hist
            )
            _ENSEMBLE_WEIGHT_CACHE[cache_key] = {
                "lgbm": wl,
                "nbeats": wn,
                "prophet": wp,
                "wmape_ensemble": wmape_ensemble,
            }

        # Build forward-looking projections from each component model.
        horizon = max(1, int(horizon))
        lgbm_vals = _project_forward(weekly["lgbm_pred"].astype(float).to_numpy(), horizon)
        nbeats_vals = _project_forward(weekly["nbeats_pred"].astype(float).to_numpy(), horizon)
        prophet_vals = _project_forward(weekly["prophet_pred"].astype(float).to_numpy(), horizon)
        ensemble_vals = wl * lgbm_vals + wn * nbeats_vals + wp * prophet_vals

        # Confidence combines model spread and average Prophet interval width.
        if "prophet_hi" in weekly.columns and "prophet_lo" in weekly.columns:
            prophet_spread = (weekly["prophet_hi"].astype(float) - weekly["prophet_lo"].astype(float)).tail(12)
            spread_baseline = float(max(0.0, prophet_spread.mean() / 2.0)) if not prophet_spread.empty else 0.0
        else:
            spread_baseline = 0.0
        disagreement = np.std(np.vstack([lgbm_vals, nbeats_vals, prophet_vals]), axis=0)
        uncertainty = np.maximum(disagreement, spread_baseline)
        lower_vals = np.maximum(0.0, ensemble_vals - uncertainty)
        upper_vals = ensemble_vals + uncertainty

        last_week = weekly["week_start"].max()
        future_dates = [(last_week + timedelta(weeks=i)).date().isoformat() for i in range(1, horizon + 1)]

        wmape_lgbm = _wmape_nonzero(actual_hist, lgbm_hist) if actual_hist.size else 0.0
        wmape_nbeats = _wmape_nonzero(actual_hist, nbeats_hist) if actual_hist.size else 0.0
        wmape_prophet = _wmape_nonzero(actual_hist, prophet_hist) if actual_hist.size else 0.0

        sku = SKU_MASTER[sku_id]
        forecast = [round(float(v), 1) for v in ensemble_vals.tolist()]
        h = max(len(forecast), 1)
        return {
            "sku_id": sku_id,
            "dates": future_dates,
            "forecast": forecast,
            "lower_bound": [round(float(v), 1) for v in lower_vals.tolist()],
            "upper_bound": [round(float(v), 1) for v in upper_vals.tolist()],
            "prophet_forecast": [round(float(v), 1) for v in prophet_vals.tolist()],
            "lgbm_forecast": [round(float(v), 1) for v in lgbm_vals.tolist()],
            "nbeats_forecast": [round(float(v), 1) for v in nbeats_vals.tolist()],
            "stock_level": [int(sku["current_stock"])] * h,
            "model_weights": {
                "prophet": round(float(wp), 3),
                "lgbm": round(float(wl), 3),
                "nbeats": round(float(wn), 3),
            },
            "metrics": {
                "wmape_prophet": round(float(wmape_prophet), 4),
                "wmape_lgbm": round(float(wmape_lgbm), 4),
                "wmape_nbeats": round(float(wmape_nbeats), 4),
                "wmape_ensemble": round(float(wmape_ensemble), 4),
            },
            "demand_summary": _build_demand_summary(forecast),
        }

    p_weekly, n_weekly = _build_model_weekly_series(item_ids)

    if p_weekly.empty:
        return _LEGACY_RUN_ENSEMBLE(sku_id, horizon)

    # Historical overlap for metric calibration.
    overlap = p_weekly[["week_start", "actual", "forecast"]].merge(
        n_weekly[["week_start", "predicted"]], on="week_start", how="left"
    )
    overlap["predicted"] = overlap["predicted"].fillna(overlap["forecast"])

    actual_vals = overlap["actual"].fillna(0.0).astype(float).to_numpy()
    prophet_hist = overlap["forecast"].astype(float).to_numpy()
    nbeats_hist = overlap["predicted"].astype(float).to_numpy()

    lgbm_ratio = _weighted_lgbm_ratio_for_items(item_ids)
    lgbm_hist = prophet_hist * lgbm_ratio

    wmape_prophet = _wmape(actual_vals, prophet_hist)
    wmape_nbeats = _lookup_metric_for_items(_METRICS_NBEATS_DF, item_ids, "wmape")
    if wmape_nbeats is None:
        wmape_nbeats = _wmape(actual_vals, nbeats_hist)
    wmape_lgbm = _lookup_metric_for_items(_METRICS_LGBM_DF, item_ids, "wmape")
    if wmape_lgbm is None:
        wmape_lgbm = _wmape(actual_vals, lgbm_hist)

    eps = 1e-6
    wp = 1.0 / max(wmape_prophet, eps)
    wl = 1.0 / max(wmape_lgbm, eps)
    wn = 1.0 / max(wmape_nbeats, eps)
    total = wp + wl + wn
    wp, wl, wn = wp / total, wl / total, wn / total

    # True forecast: project each model forward beyond the last available week.
    horizon = max(1, int(horizon))
    prophet_vals = _project_forward(p_weekly["forecast"].astype(float).to_numpy(), horizon)
    nbeats_source = n_weekly["predicted"].astype(float).to_numpy() if not n_weekly.empty else p_weekly["forecast"].astype(float).to_numpy()
    nbeats_vals = _project_forward(nbeats_source, horizon)
    lgbm_vals = prophet_vals * lgbm_ratio

    ensemble_vals = wp * prophet_vals + wl * lgbm_vals + wn * nbeats_vals
    ensemble = [round(float(v), 1) for v in ensemble_vals.tolist()]

    # Confidence band combines Prophet interval spread and model disagreement.
    recent_spread = 0.0
    if "upper" in p_weekly.columns and "lower" in p_weekly.columns:
        spread_series = (p_weekly["upper"].astype(float) - p_weekly["lower"].astype(float)).tail(12)
        recent_spread = float(max(0.0, spread_series.mean() / 2.0)) if not spread_series.empty else 0.0
    disagreement = np.std(np.vstack([prophet_vals, nbeats_vals, lgbm_vals]), axis=0)
    uncertainty = np.maximum(disagreement, recent_spread)
    lower_vals = np.maximum(0.0, ensemble_vals - uncertainty)
    upper_vals = ensemble_vals + uncertainty

    last_week = p_weekly["week_start"].max()
    future_dates = [(last_week + timedelta(weeks=i)).date().isoformat() for i in range(1, horizon + 1)]

    sku = SKU_MASTER[sku_id]
    stock_line = [int(sku["current_stock"])] * len(ensemble)
    # Compute ensemble WMAPE as actual performance on historical overlap,
    # NOT as a weighted average of individual model WMAPEs (which is incorrect).
    ensemble_hist_pred = wp * prophet_hist + wl * lgbm_hist + wn * nbeats_hist
    ensemble_wmape = round(float(_wmape_nonzero(actual_vals, ensemble_hist_pred)), 4)

    return {
        "sku_id": sku_id,
        "dates": future_dates,
        "forecast": ensemble,
        "lower_bound": [round(float(v), 1) for v in lower_vals.tolist()],
        "upper_bound": [round(float(v), 1) for v in upper_vals.tolist()],
        "prophet_forecast": [round(float(v), 1) for v in prophet_vals.tolist()],
        "lgbm_forecast": [round(float(v), 1) for v in lgbm_vals.tolist()],
        "nbeats_forecast": [round(float(v), 1) for v in nbeats_vals.tolist()],
        "stock_level": stock_line,
        "model_weights": {
            "prophet": round(float(wp), 3),
            "lgbm": round(float(wl), 3),
            "nbeats": round(float(wn), 3),
        },
        "metrics": {
            "wmape_prophet": round(float(wmape_prophet), 4),
            "wmape_lgbm": round(float(wmape_lgbm), 4),
            "wmape_nbeats": round(float(wmape_nbeats), 4),
            "wmape_ensemble": ensemble_wmape,
        },
        "demand_summary": _build_demand_summary(ensemble),
    }


def _weighted_wmape(df: pd.DataFrame, wmape_col: str, weight_col: str | None = None) -> float | None:
    if df.empty or wmape_col not in df.columns:
        return None

    wmape_vals = pd.to_numeric(df[wmape_col], errors="coerce")
    if weight_col and weight_col in df.columns:
        weights = pd.to_numeric(df[weight_col], errors="coerce")
    else:
        weights = pd.Series([1.0] * len(df), index=df.index)

    mask = wmape_vals.notna() & weights.notna() & (weights > 0)
    if not mask.any():
        return None

    wm = wmape_vals[mask]
    wt = weights[mask]
    denom = float(wt.sum())
    if denom <= 0:
        return None
    return float((wm * wt).sum() / denom)


def _fmt_iso_day(value: Any) -> str:
    if pd.isna(value):
        return date.today().isoformat()
    if hasattr(value, "date"):
        return value.date().isoformat()
    return str(value)


def get_model_accuracy_summary() -> dict[str, Any]:
    """Return real model accuracy metadata for the account details modal."""
    wm_lgbm = None
    wm_nbeats = None
    wm_prophet = None
    last_refreshed = date.today().isoformat()
    data_points = 0

    if not _ENSEMBLE_METRICS_DF.empty:
        wm_lgbm = _weighted_wmape(_ENSEMBLE_METRICS_DF, "wmape_lgbm", "total_actual")
        wm_nbeats = _weighted_wmape(_ENSEMBLE_METRICS_DF, "wmape_nbeats", "total_actual")
        wm_prophet = _weighted_wmape(_ENSEMBLE_METRICS_DF, "wmape_prophet", "total_actual")
        if "total_actual" in _ENSEMBLE_METRICS_DF.columns:
            totals = pd.to_numeric(_ENSEMBLE_METRICS_DF["total_actual"], errors="coerce")
            data_points = int(max(0, totals.fillna(0).sum()))

    if not _ENSEMBLE_PRED_DF.empty and "week_start" in _ENSEMBLE_PRED_DF.columns:
        last_refreshed = _fmt_iso_day(_ENSEMBLE_PRED_DF["week_start"].max())

    # Fallback to trained-csv metrics when ensemble-level metrics are unavailable.
    if wm_lgbm is None and not _METRICS_LGBM_DF.empty:
        wm_lgbm = _weighted_wmape(_METRICS_LGBM_DF, "wmape", "actual_total")
    if wm_nbeats is None and not _METRICS_NBEATS_DF.empty:
        wm_nbeats = _weighted_wmape(_METRICS_NBEATS_DF, "wmape", "actual_total")

    # Prophet fallback from its prediction table if no explicit metric column exists.
    if wm_prophet is None and not _PROPHET_DF.empty and {"actual", "forecast"}.issubset(_PROPHET_DF.columns):
        actual_vals = pd.to_numeric(_PROPHET_DF["actual"], errors="coerce").to_numpy()
        pred_vals = pd.to_numeric(_PROPHET_DF["forecast"], errors="coerce").to_numpy()
        wm_prophet = _wmape_nonzero(actual_vals, pred_vals)
        if "week_start" in _PROPHET_DF.columns:
            last_refreshed = _fmt_iso_day(_PROPHET_DF["week_start"].max())
        if data_points <= 0:
            data_points = int(np.isfinite(actual_vals).sum())

    def _to_model_payload(model_id: str, label: str, wmape_val: float | None) -> Dict[str, Any]:
        if wmape_val is None:
            return {
                "id": model_id,
                "name": label,
                "accuracy": None,
                "wmape": None,
                "confidence": None,
                "status": "Unavailable",
                "last_refreshed": last_refreshed,
                "data_points": int(data_points),
            }

        acc = max(0.0, min(99.9, (1.0 - float(wmape_val)) * 100.0))
        conf = max(0.0, min(0.99, 1.0 - float(wmape_val)))
        return {
            "id": model_id,
            "name": label,
            "accuracy": round(acc, 3),
            "wmape": round(float(wmape_val), 6),
            "confidence": round(conf, 4),
            "status": "Active",
            "last_refreshed": last_refreshed,
            "data_points": int(data_points),
        }

    return {
        "generated_at": date.today().isoformat(),
        "models": [
            _to_model_payload("lgbm", "LightGBM Demand Engine", wm_lgbm),
            _to_model_payload("nbeats", "N-BEATS Seasonality Engine", wm_nbeats),
            _to_model_payload("prophet", "Prophet Trend Engine", wm_prophet),
        ],
    }


_load_trained_csv_data()
