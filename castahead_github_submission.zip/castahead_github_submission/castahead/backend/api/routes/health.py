from fastapi import APIRouter
router = APIRouter()

@router.get("/health")
def health():
    return {"status": "ok", "models_loaded": True,
            "active_models": ["prophet", "lgbm", "nbeats"], "version": "1.0.0"}
