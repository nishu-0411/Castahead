from fastapi import APIRouter
from pydantic import BaseModel
import os

router = APIRouter()

class NarrateRequest(BaseModel):
    sku_id: str
    sku_name: str
    wmape_ensemble: float
    trend_direction: str = "stable"
    dominant_model: str = "ensemble"
    reorder_qty: int = 0
    reorder_deadline: str = ""
    estimated_roi: float = 0

def _fallback_narration(req: NarrateRequest) -> str:
    direction_map = {
        "increasing": "an upward demand trend",
        "decreasing": "a declining demand trend",
        "stable":     "stable demand patterns",
    }
    trend_phrase = direction_map.get(req.trend_direction, "stable demand patterns")
    action = (
        f"Reorder {req.reorder_qty} units by {req.reorder_deadline}."
        if req.reorder_qty > 0
        else "Hold current stock levels and monitor weekly."
    )
    roi_phrase = (
        f" Following this recommendation could recover an estimated ${req.estimated_roi:,} in revenue."
        if req.estimated_roi > 0 else ""
    )
    return (
        f"{req.sku_name} is showing {trend_phrase} with a forecast accuracy "
        f"of {(1-req.wmape_ensemble)*100:.0f}%. {action}{roi_phrase}"
    )

@router.post("/narrate")
def narrate(req: NarrateRequest):
    api_key = os.getenv("GEMINI_API_KEY", "")
    narration = ""
    if api_key:
        try:
            import google.generativeai as genai
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel("gemini-1.5-flash")
            prompt = (
                f"You are a supply chain advisor for a retail business. "
                f"Write exactly 2 sentences in plain English (no jargon, no model names) "
                f"explaining the demand outlook for '{req.sku_name}'. "
                f"Key facts: demand is {req.trend_direction}, forecast accuracy is "
                f"{(1-req.wmape_ensemble)*100:.0f}%, recommended action is to "
                f"{'reorder ' + str(req.reorder_qty) + ' units by ' + req.reorder_deadline if req.reorder_qty > 0 else 'hold current stock'}. "
                f"Estimated revenue impact: ${req.estimated_roi:,}. "
                f"Start with the product name."
            )
            resp = model.generate_content(prompt)
            narration = resp.text.strip()
        except Exception:
            narration = _fallback_narration(req)
    else:
        narration = _fallback_narration(req)

    return {"narration": narration, "source": "gemini" if api_key and narration else "fallback"}
