from fastapi import APIRouter
from core.engine import SKU_MASTER, generate_historical

router = APIRouter()

@router.get("/skus")
def get_skus():
    result = []
    for sku_id, sku in SKU_MASTER.items():
        result.append({
            "sku_id":       sku["sku_id"],
            "name":         sku["name"],
            "category":     sku["category"],
            "store":        sku["store"],
            "region":       sku["region"],
            "current_stock": sku["current_stock"],
            "status":       sku["status"],
            "risk_label":   sku["risk_label"],
            "key_risk_factor": sku["key_risk_factor"],
            "recommendation":  sku["recommendation"],
            "reorder_qty":  sku["reorder_qty"],
        })
    return {"skus": result}

@router.get("/skus/{sku_id}")
def get_sku(sku_id: str):
    if sku_id not in SKU_MASTER:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="SKU not found")
    sku = SKU_MASTER[sku_id]
    history = generate_historical(sku_id, 60)
    return {**sku, "history": history}
