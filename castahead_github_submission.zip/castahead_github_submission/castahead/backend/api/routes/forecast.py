from fastapi import APIRouter, HTTPException
from core.engine import run_ensemble, SKU_MASTER, resolve_sku_identifier

router = APIRouter()

@router.get("/forecast/{sku_id}")
def get_forecast(sku_id: str, horizon: int = 12):
    resolved = resolve_sku_identifier(sku_id)
    if not resolved or resolved not in SKU_MASTER:
        raise HTTPException(status_code=404, detail="SKU not found")
    return run_ensemble(resolved, horizon)
