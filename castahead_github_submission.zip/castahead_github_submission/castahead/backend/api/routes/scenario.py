from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from core.engine import run_scenario, SCENARIO_LIBRARY, SKU_MASTER, resolve_sku_identifier

router = APIRouter()

class ScenarioRequest(BaseModel):
    sku_id: str
    scenario_id: str
    horizon: int = 12

@router.get("/scenarios")
def list_scenarios(sku_id: str | None = None):
    """Return scenarios. If `sku_id` is provided and exists, tailor applicability and a per-SKU accuracy hint.

    This endpoint remains backward-compatible: callers that don't pass `sku_id` get the global library.
    """
    base = list(SCENARIO_LIBRARY.values())
    if not sku_id:
        return {"scenarios": base}

    resolved_sku_id = resolve_sku_identifier(sku_id) if sku_id else None
    sku = SKU_MASTER.get(resolved_sku_id or "")
    if not sku:
        # If SKU unknown, return global list unchanged
        return {"scenarios": base}

    # Heuristic applicability rules per scenario type and SKU category
    cat = (sku.get("category") or "").upper()
    sku_name = sku.get("name") or resolved_sku_id or sku_id
    base_demand = float(sku.get("base_demand") or 0)
    current_stock = float(sku.get("current_stock") or 0)

    def applicable_for(s):
        t = s.get("type")
        if t == "SUPPLY_DISRUPTION":
            return True
        if t == "WEATHER_EVENT":
            return any(k in cat for k in ["BEV", "BEVERAGE", "GROCERY", "FOOD"])
        if t == "MARKET_SHIFT":
            return True
        return True

    def sku_hint_for(s):
        t = s.get("type")
        if t == "WEATHER_EVENT":
            if any(k in cat for k in ["BEV", "BEVERAGE"]):
                return "Temperature swings historically amplify hydration demand spikes for this SKU."
            if any(k in cat for k in ["GROCERY", "FOOD"]):
                return "Weather volatility tends to shift pantry-load timing for this SKU."
            return "Weather sensitivity is weaker for this category, so this event is lower confidence."
        if t == "SUPPLY_DISRUPTION":
            if current_stock > 0 and base_demand > 0:
                cover_weeks = current_stock / base_demand
                if cover_weeks < 2:
                    return "Current coverage is tight; even short disruptions can trigger stock pressure."
                if cover_weeks < 4:
                    return "Inventory coverage is moderate; disruption risk is present but manageable."
            return "Current coverage is healthy, so disruption effects are expected to be dampened."
        if t == "MARKET_SHIFT":
            if any(k in cat for k in ["PERSONAL", "CARE"]):
                return "Promotion-led switching behavior is common in this category during seasonal windows."
            return "Price and channel shifts can re-route demand, especially for substitutable SKUs."
        return ""

    tailored = []
    for s in base:
        s_copy = dict(s)
        applicable = bool(applicable_for(s))
        s_copy["applicable"] = applicable

        # deterministic per-SKU adjustment so cards vary by item
        adj = (abs(hash(f"{resolved_sku_id}:{s.get('id')}")) % 9) - 4  # -4..+4
        acc_base = int(s_copy.get("accuracy_pct", 80)) + adj
        if not applicable:
            acc_base -= 8
        s_copy["accuracy_pct"] = max(1, min(99, acc_base))

        # personalize visible card content to the selected SKU
        type_label = (s_copy.get("label") or "Scenario").title()
        s_copy["title"] = f"{type_label}: {sku_name}"
        hint = sku_hint_for(s)
        if hint:
            s_copy["description"] = f"{s_copy.get('description', '')} {hint}".strip()

        demand_bias = 0
        if base_demand > 0 and current_stock > 0:
            demand_bias = int(round((base_demand / current_stock) * 12))
        historical_delta = int(s_copy.get("demand_delta_pct", 0))
        adjusted_delta = historical_delta + adj // 2 + max(-4, min(4, demand_bias))
        s_copy["demand_delta_pct"] = max(-45, min(45, adjusted_delta))

        tailored.append(s_copy)
    return {"scenarios": tailored}

@router.post("/scenario/simulate")
def simulate_scenario(req: ScenarioRequest):
    resolved_sku_id = resolve_sku_identifier(req.sku_id)
    if not resolved_sku_id or resolved_sku_id not in SKU_MASTER:
        raise HTTPException(status_code=404, detail="SKU not found")
    if req.scenario_id not in SCENARIO_LIBRARY:
        raise HTTPException(status_code=404, detail="Scenario not found")
    return run_scenario(resolved_sku_id, req.scenario_id, req.horizon)
