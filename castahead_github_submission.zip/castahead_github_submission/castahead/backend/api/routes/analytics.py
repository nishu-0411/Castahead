from fastapi import APIRouter
from collections import defaultdict
from datetime import date, timedelta
from core.engine import SKU_MASTER, generate_historical, get_model_accuracy_summary, _ENSEMBLE_PRED_DF
import pandas as pd

router = APIRouter()


@router.get("/analytics/demand-trend")
def get_demand_trend():
    """Aggregate weekly demand trend across all SKUs for the dashboard chart.

    Returns 8 historical weekly totals + 4 forecast weeks.
    """
    today = date.today()

    # Aggregate weekly historical actuals. Prefer ensemble/CSV-backed actuals when available,
    # otherwise fall back to generated historicals.
    weekly_hist: dict[int, int] = defaultdict(int)
    if not _ENSEMBLE_PRED_DF.empty and "week_start" in _ENSEMBLE_PRED_DF.columns:
        # Use ensemble predictions table which may contain historical 'actual' per week_start
        df = _ENSEMBLE_PRED_DF.copy()
        if "actual" in df.columns and float(pd.to_numeric(df["actual"], errors="coerce").sum()) > 0:
            df = df.groupby("week_start", as_index=False)[["actual"]].sum(numeric_only=True)
            for _, row in df.iterrows():
                d = row["week_start"].date() if hasattr(row["week_start"], "date") else row["week_start"]
                offset = (today - d).days // 7
                if 0 <= offset <= 7:
                    weekly_hist[offset] += int(max(0, round(float(row["actual"]))))
        else:
            # ensemble table lacks actuals; try prophet / nbeats tables for historicals
            try:
                from core.engine import _PROPHET_DF, _NBEATS_DF
                if not _PROPHET_DF.empty and "week_start" in _PROPHET_DF.columns and "actual" in _PROPHET_DF.columns:
                    p = _PROPHET_DF.groupby("week_start", as_index=False)[["actual"]].sum(numeric_only=True)
                    for _, row in p.iterrows():
                        d = row["week_start"].date() if hasattr(row["week_start"], "date") else row["week_start"]
                        offset = (today - d).days // 7
                        if 0 <= offset <= 7:
                            weekly_hist[offset] += int(max(0, round(float(row["actual"]))))
                elif not _NBEATS_DF.empty and "week_start" in _NBEATS_DF.columns and "actual" in _NBEATS_DF.columns:
                    n = _NBEATS_DF.groupby("week_start", as_index=False)[["actual"]].sum(numeric_only=True)
                    for _, row in n.iterrows():
                        d = row["week_start"].date() if hasattr(row["week_start"], "date") else row["week_start"]
                        offset = (today - d).days // 7
                        if 0 <= offset <= 7:
                            weekly_hist[offset] += int(max(0, round(float(row["actual"]))))
            except Exception:
                pass
    else:
        # Fallback: generate historical per-SKU
        for sku_id in SKU_MASTER:
            for rec in generate_historical(sku_id, 60):
                d = date.fromisoformat(rec["date"])
                offset = (today - d).days // 7
                if 0 <= offset <= 7:
                    weekly_hist[offset] += rec["sales"]

    # If historical aggregation returned all zeros, fall back to generated legacy historicals
    if sum(weekly_hist.values()) == 0:
        # No historicals available from CSVs — synthesize a reasonable demo series
        total_base = sum(s.get("base_demand", 0) for s in SKU_MASTER.values())
        # create slight increasing trend from W-7 -> TODAY
        for offset in range(7, -1, -1):
            factor = 0.9 + 0.02 * (7 - offset)
            weekly_hist[offset] = int(round(total_base * 7 * factor))

    # Forecast: prefer to derive per-SKU short-term forecast from ensemble table when available
    trend = []

    # Historical from oldest (W-7) to current week (TODAY)
    for offset in range(7, -1, -1):
        label = "TODAY" if offset == 0 else f"W-{offset}"
        trend.append({
            "week": label,
            "historical": weekly_hist.get(offset, 0),
            "forecast": 0,
        })

    # Forecast: estimate W+1..W+4 by summing a short-term per-SKU forecast.
    # If ensemble table is available, use last few ensemble_pred rows to compute a recent weekly baseline per SKU.
    total_forecasts = []
    if not _ENSEMBLE_PRED_DF.empty and {"item_id", "ensemble_pred", "week_start"}.issubset(_ENSEMBLE_PRED_DF.columns):
        # For each SKU, take the mean of its last 4 ensemble_pred values as weekly expected demand
        df = _ENSEMBLE_PRED_DF.copy()
        df_sorted = df.sort_values(["item_id", "week_start"]) if "item_id" in df.columns else df
        per_sku = df_sorted.groupby("item_id").tail(4).groupby("item_id")["ensemble_pred"].mean()
        weekly_baseline = per_sku.sum()
        # Make small upward trend across forecast weeks
        for w in range(1, 5):
            total_forecasts.append(int(round(weekly_baseline * (1.0 + 0.01 * w))))
    else:
        # Fallback: use base_demand as proxy (weekly * 7 days)
        total_base = sum(s["base_demand"] for s in SKU_MASTER.values())
        for w in range(1, 5):
            total_forecasts.append(int(round(total_base * (1.0 + 0.01 * w) * 7)))

    for w, fval in enumerate(total_forecasts, start=1):
        trend.append({"week": f"W+{w}", "historical": 0, "forecast": int(fval)})

    return {"trend": trend}


@router.get("/analytics/model-accuracy")
def get_model_accuracy():
    """Return real accuracy metadata for each production forecasting model."""
    return get_model_accuracy_summary()
