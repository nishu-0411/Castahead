from core.engine import SKU_MASTER
print('num', len(SKU_MASTER))
print('sum', sum(s.get('base_demand',0) for s in SKU_MASTER.values()))
print(list(SKU_MASTER.items())[:5])
