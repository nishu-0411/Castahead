# CastAhead Final GitHub Submission Package

This folder is a **clean, upload-ready package** containing only the files needed for the final GitHub submission of the CastAhead project.

Path:
- `castahead_github_submission/castahead/`

The package intentionally excludes local-only artifacts (virtual environments, installed dependencies, build cache, screenshots, temporary logs, and IDE metadata).

## 1. Project Summary

CastAhead is a full-stack demand forecasting platform for inventory decisions.

Core capabilities:
- Forecasts per SKU using an ensemble of Prophet, LightGBM, and N-BEATS outputs.
- Scenario simulation (`/api/scenario/simulate`) for demand shocks.
- Inventory recommendation signals (risk, reorder guidance, demand summary).
- Frontend dashboard + forecast detail + scenario planner.

## 2. What Is Included (and Why)

Inside `castahead/` this package includes:

- `backend/`
  - FastAPI app code and API routes.
  - Forecast/scenario engine in `core/engine.py`.
  - Deployment config (`Procfile`, `railway.json`).
  - `requirements.txt` and `.env.example`.

- `frontend/`
  - React + Vite + Tailwind source (`src/`) and build configs.
  - `package.json`, lockfile, and `.env.example`.

- `ensemble/`
  - `final_ensemble_predictions.csv`
  - `ensemble_metrics.csv`
  - Ensemble generation script reference.

- `trained csv/`
  - Model output/metrics CSVs used as fallback input by backend logic.

- `tools/`
  - `inspect_skus.py` utility script.

- Root start scripts
  - `start.bat`, `start.sh`

## 3. What Is Excluded on Purpose

The following are intentionally NOT included in this package:
- `.venv/`, `venv/`
- `node_modules/`
- `frontend/dist/`
- `__pycache__/`, `*.pyc`
- Local `.env` files (secrets)
- Screenshots/images and generated dashboard PNGs
- Workspace/editor metadata and logs

These should not be committed in final GitHub submissions.

## 4. Runtime Behavior Notes

Backend forecast engine checks for data in this order:
1. `ensemble/final_ensemble_predictions.csv` + `ensemble/ensemble_metrics.csv`
2. `trained csv/` fallback outputs
3. Legacy simulation fallback (if trained CSVs are unavailable)

This package includes both (1) and (2), so forecast behavior remains data-driven.

## 5. Local Run Instructions

Prerequisites:
- Python 3.10+
- Node.js 18+

### Backend setup

```bash
cd castahead/backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # optional values
uvicorn main:app --reload --port 8000
```

### Frontend setup

```bash
cd castahead/frontend
npm install
cp .env.example .env
npm run dev
```

Frontend dev URL: `http://localhost:5173`
Backend API URL: `http://localhost:8000`

### Single-server mode (backend serves frontend build)

```bash
cd castahead/frontend
npm install
npm run build

cd ../backend
uvicorn main:app --reload --port 8000
```

Then open `http://localhost:8000`.

## 6. API Surface (Primary)

- `GET /api/health`
- `GET /api/skus`
- `GET /api/skus/{sku_id}`
- `GET /api/forecast/{sku_id}`
- `GET /api/scenarios`
- `POST /api/scenario/simulate`
- `POST /api/narrate`
- `GET /api/analytics/demand-trend`
- `GET /api/analytics/model-accuracy`

## 7. Suggested GitHub Repository Layout

Push the **contents of `castahead/`** as your repository root.

Recommended repo root after upload:
- `backend/`
- `frontend/`
- `ensemble/`
- `trained csv/`
- `tools/`
- `start.bat`
- `start.sh`
- `README.md` (you can copy/adapt this file)

## 8. Final Submission Checklist

- [ ] No `.env` secrets committed
- [ ] No `venv/.venv` committed
- [ ] No `node_modules` committed
- [ ] No `dist` committed unless explicitly required
- [ ] Backend starts at port 8000
- [ ] Frontend connects correctly via `VITE_API_URL`
- [ ] `/api/forecast/{sku}` and `/api/scenario/simulate` return valid responses

---

Prepared package location:
- `C:\Users\Aadi\Desktop\DAU\castahead_github_submission\castahead`
